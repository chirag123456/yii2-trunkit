<?php
namespace frontend\components;
use Yii;
use yii\helpers\Url;
use yii\web\Controller;

class CustController extends Controller {


    public function beforeAction($action)
    {
        if (!parent::beforeAction($action)) {
            return false;
        }
        
        if(Yii::$app->user->isGuest){
            $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
            return false; //not run the action
        }else{
            return true;
        }
        return true; // continue to run action
    }

    public function base64_to_image($imageData, $type) {
        $basePath = dirname(\Yii::$app->basePath);
        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;
        $file = $basePath . DIRECTORY_SEPARATOR . 'media'  . DIRECTORY_SEPARATOR . $type . DIRECTORY_SEPARATOR . $imagename;
        //echo $file;exit;
        file_put_contents($file, $image_base64);

        return $imagename;
    }

    public function getDistanceBetweenPointsWithTime($lat1, $lat2, $lon1, $lon2,$key) {
        $api = "https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=" . $lat1 . ',' . $lon1 . "&destinations=" . $lat2 . ',' . $lon2 . "&mode=driving&region=CA&key=".$key;
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $api);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $response_a = json_decode($api, true);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        curl_close($ch);

        $response_a = json_decode($response, true);      
           
        if (isset($response_a['rows'][0]['elements'][0]['status']) && !empty($response_a['rows'][0]['elements'][0]['status']) && $response_a['rows'][0]['elements'][0]['status'] == 'OK') {
            $time = $response_a['rows'][0]['elements'][0]['duration']['value'];
            $dist = $response_a['rows'][0]['elements'][0]['distance']['value'];
            $dist = round($dist / 1000, 2);
            $time = round($time / 60, 0);

            return ['distance' => trim($dist), 'time' => trim($time)];
        } else {
            return ['distance' => 0, 'time' => 0];
        }
    }
}