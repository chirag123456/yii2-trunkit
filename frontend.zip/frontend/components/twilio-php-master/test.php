<?php

	require __DIR__ . '/Twilio/autoload.php';
	$sid = "ACb9584326c0bd0fa3675e88dda6c95e72"; // Your Account SID from www.twilio.com/console
    $token = "9add870d8da3582e96e147e04c24201d"; // Your Auth Token from www.twilio.com/console
	$client = new Twilio\Rest\Client($sid, $token);
echo'<pre>';
	print_r($client);die;
	$message = $client->messages->create(
			'+918112297884', // Text this number
			array(
		'from' => '+19197525338', // From a valid Twilio number
		'body' => 'Hello from Twilio!'
			)
	);
	print_r($message);
    die;
?>