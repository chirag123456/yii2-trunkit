<?php

$config = array(
  "environment" => "sandbox", # or live
  "userid" => "demo.xceltec_api1.gmail.com",
  "password" => "8QBHXM2DBGFJ22FS",
  "signature" => "AvbrjyLw8e2V9PGT974X6JmrYVo9AtHOcto5SElebDmOX-ZuF82nfe1c",
  // "appid" => "", # You can set this when you go live
);
