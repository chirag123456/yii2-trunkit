<?php
/**
 * Created by PhpStorm.
 * User: rohan
 * Date: 16/2/16
 * Time: 4:30 PM
 */

namespace frontend\components;

use Yii;
use common\models\Menus;
use common\models\Campaign;
use common\models\Charity;
use common\models\CharityDonation;
use common\models\Devices;
use common\models\user\User;
use common\models\Order;
use yii\base\Component;
use yii\base\InvalidConfigException;
use yii\helpers\Html;
use yii\helpers\Url;

class CommonFunctions extends Component
{
    public function welcome()
    {
        echo "Hello..Welcome to MyComponent";
    }
 
    public static function base64ToImage($data1,$output_file_without_extentnion ,$path) {
        //$full_path = Yii::getAlias('@frontend') . "/web/uploads/".$path;
        $full_path = dirname(\Yii::$app->basePath). DIRECTORY_SEPARATOR . 'media'  . DIRECTORY_SEPARATOR . $path . DIRECTORY_SEPARATOR; 
        $splited = explode(',', substr($data1 , 5 ) , 2);
        $data = str_replace('data:image/png;base64,', '', $data1);
        $mime=$splited[0];
        $data=$splited[1];
        $mime_split_without_base64=explode(';', $mime,2);
        $mime_split=explode('/', $mime_split_without_base64[0],2);
        $extension=$mime_split[1];
        $output_file=str_replace(' ', '_', $output_file_without_extentnion).'.'.$extension;        
        $final_file = $full_path.$output_file;       
        //$success = file_put_contents($final_file,base64_decode($data));
        $success = self::resize_image($data1, $extension,350, 350);
            // save the image on the given filename
            imagepng($success, $final_file);
        if($success){
            $media = [$final_file,$path];
            // $source = $data1;
            // $quality = 50;

            // $info = getimagesize($source);
            // if ($info['mime'] == 'image/jpeg') 
            //     $image = imagecreatefromjpeg($source);
            // elseif ($info['mime'] == 'image/gif') 
            //     $image = imagecreatefromgif($source);
            // elseif ($info['mime'] == 'image/png') 
            //     $image = imagecreatefrompng($source);
            // imagejpeg($image, $final_file, $quality);

            // return $media;
            
        }else{
            return false;
        }
    } 

    public static function base64ToImage1($data1,$output_file_without_extentnion ,$path) {
        //$full_path = Yii::getAlias('@frontend') . "/web/uploads/".$path;
        $basePath = dirname(\Yii::$app->basePath). DIRECTORY_SEPARATOR . 'media'  . DIRECTORY_SEPARATOR . $path . DIRECTORY_SEPARATOR; 
        $full_path = dirname(\Yii::$app->basePath). DIRECTORY_SEPARATOR . 'media'  . DIRECTORY_SEPARATOR . $path . DIRECTORY_SEPARATOR;
        $image_parts = explode(";base64,", $data1);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;   
        $output_file=str_replace(' ', '_', $output_file_without_extentnion).'.'.$image_type;        
        $final_file = $full_path.$output_file;       
       // $final_file = $full_path.$output_file;       
        //$success = file_put_contents($final_file,base64_decode($data));
        $success = self::resize_image($data1, $image_type,350, 350);
            // save the image on the given filename
            imagepng($success, $final_file);
        if($success){
            $media = [$final_file,$path];
            // $source = $data1;
            // $quality = 50;

            // $info = getimagesize($source);
            // if ($info['mime'] == 'image/jpeg') 
            //     $image = imagecreatefromjpeg($source);
            // elseif ($info['mime'] == 'image/gif') 
            //     $image = imagecreatefromgif($source);
            // elseif ($info['mime'] == 'image/png') 
            //     $image = imagecreatefrompng($source);
            // imagejpeg($image, $final_file, $quality);

            // return $media;
            
        }else{
            return false;
        }
    }
    
    public static function returnExtension($icon) {
            $splited = explode(',', substr($icon , 5 ) , 2);
            $icon = str_replace('data:image/png;base64,', '', $icon);
            $mime=$splited[0];
            $icon=$splited[1];

            $mime_split_without_base64=explode(';', $mime,2);
            $mime_split=explode('/', $mime_split_without_base64[0],2);
            $extension=$mime_split[1];
            return '.'.$extension;
    }

    public function getConfigureValueByKey( $key ){
        
            $model = \common\models\siteconfiguration\SiteConfiguration::findOne(['config_key'=> $key]);
            if( $model != null ){
                return $model->config_value;
            }else{
                return 'Undefine Key';
            }
    }
	
	 public function getDashboardDetails() {

        $total_order = Order::find()->Where(['is_delete' => NOT_DELETED])->andWhere(['is_active' => 'Y'])->count('id');
		$total_restant = User::find()->Where(['role' => '2'])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['is_active' => 'Y'])->count('id');
		$total_rider = User::find()->Where(['role' => '3'])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['is_active' => 'Y'])->count('id');
		
	
		
        //$total_waiting = PassengersOrders::find()->where(['order_status' => ['New', 'Confirmed', 'Accepted']])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['=', 'date(order_date)', date("Y-m-d")])->count('id');
     //   $total_intrip = PassengersOrders::find()->where(['order_status' => 'In Trip'])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['=', 'date(order_date)', date("Y-m-d")])->count('id');

        return [
            'details' => [
                'total_order' => isset($total_order) ? $total_order : '0',
                'total_restant' => isset($total_restant) ? $total_restant : '0',
				'total_rider' => isset($total_rider) ? $total_rider : '0',
                //'total_intrip' => isset($total_intrip) ? $total_intrip : '0',
            ]
        ];
    }


public function sendPushNotification($message){
        //$message = $this->input->post("message");
        //$user_id = $this->input->post("user_id");
        $content = array(
            "en" => "$message"
        );
        $fields = array(
            'app_id' => "a64c82b0-6c7e-4255-85b4-9ea3f53143cb",            
            'filters' => array(array("field" => "tags", 
                                    "key" => "userId", 
                                    "relation" => "=", 
                                    "value" => 65)),            
            'contents' => $content
        );

        $fields = json_encode($fields);
        print("\nJSON sent:\n");
        print($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
            'Authorization: Basic NGQ2M2FiZGEtMzgyOC00ODY1LTg5ZjMtYjQ5NjkxZjg4OWFj'));//NGM0Mzk5YjMtNTQzMi00OTkwLTkyY2EtMTI1MzNhODBmZjgz
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        $response = curl_exec($ch);
        curl_close($ch);
       return $response;
    }
    public function addUser(){
        
       $fields = array( 
'app_id' => "995e81f8-44c8-42c6-9ded-af2d98fe6a84", 
'identifier' => "65", 
// 'identity'=>'9f04592a09632750cc106e1158a148353d51c2a7f536b7e289dc49aba0bfad15a%3A2%3A%7Bi%3A0%3Bs%3A17%3A%22',
'language' => "en", 
'notification_types'=>1,
'timezone' => "-28800", 
'game_version' => "1.1", 
'device_os' => "Windows NT 10.0;", 
'device_type' => "5", 
'device_model'=>'',
'country'=>'IN',
'notification_types'=>1,
'tags' => array("user_id" => "1") 
); 

$fields = json_encode($fields); 
print("\nJSON sent:\n"); 
print($fields); 

$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/players"); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
curl_setopt($ch, CURLOPT_HEADER, FALSE); 
curl_setopt($ch, CURLOPT_POST, TRUE); 
curl_setopt($ch, CURLOPT_POSTFIELDS, $fields); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 

$response = curl_exec($ch); 
curl_close($ch); 

$return["allresponses"] = $response; 
$return = json_encode( $return); 

print("\n\nJSON received:\n"); 
print($return); 
print("\n");


    }

/**
 * Resize image given a height and width and return raw image data.
 *
 * Note : You can add more supported image formats adding more parameters to the switch statement.
 *
 * @param type $file filepath
 * @param type $w width in px
 * @param type $h height in px
 * @param type $crop Crop or not
 * @return type
 */
public static function resize_image($file, $extension,$w, $h, $crop=false) {

    list($width, $height) = getimagesize($file);
    $r = $width / $height;
    // if ($crop) {
    //     if ($width > $height) {
    //         $width = ceil($width-($width*abs($r-$w/$h)));
    //     } else {
    //         $height = ceil($height-($height*abs($r-$w/$h)));
    //     }
    //     $newwidth = $w;
    //     $newheight = $h;
    // } else {
    //     if ($w/$h > $r) {
    //         $newwidth = $h*$r;
    //         $newheight = $h;
    //     } else {
    //         $newheight = $w/$r;
    //         $newwidth = $w;
    //     }
    // }
    $xscale=$width/$w;
    $yscale=$height/$h;
     
    //NEW DIMENSIONS WITH SAME SCALE
    if ($yscale > $xscale) 
    {
        $newwidth = round($width * (1/$yscale));
        $newheight = round($height * (1/$yscale));
    }
    else
    {
        $newwidth = round($width * (1/$xscale));
        $newheight = round($height * (1/$xscale));
    }
    
    //Get file extension
    // $exploding = explode(".",$file);
    // $ext = $extension;
    
    // switch($ext){
    //     case "png":
    //         $src = imagecreatefrompng($file);
    //     break;

    //     case "jpg":
    //         $src = imagecreatefromjpeg($file);
    //     break;
    //     case "gif":
    //         $src = imagecreatefromgif($file);
    //     break;
    //     default:
    //         $src = imagecreatefromjpeg($file);
    //     break;
    // }
    
    // $dst = imagecreatetruecolor($newwidth, $newheight);
    // imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
    $exploding = explode(".",$file);
    $ext = $extension;
    
    switch($ext){
        case "png":
            $src = imagecreatefrompng($file);
        break;

        case "jpg":
            $src = imagecreatefromjpeg($file);
        break;
        case "gif":
            $src = imagecreatefromgif($file);
        break;
        default:
            $src = imagecreatefromjpeg($file);
        break;
    }
    
    $dst = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

    return $dst;
}
    
}