<?php
namespace frontend\assets;
use yii\web\AssetBundle;
/**
 * Main frontend application asset bundle.
 */
class AppAsset extends AssetBundle {
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/site.css',
        // 'bootstrap/dist/css/bootstrap.min.css',
        //'font/font-awesonme/css/fontawesome-all.css',
        
        'js/app/includes/chatcss/chat.css',
        'css/style.css',
        'css/responsive.css',
        'css/krunal.css',
        'css/sp.css',
        'css/cropping/style-example.css',
        'css/cropping/jquery.Jcrop.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css',        
        'css/flexslider.css',
        'css/ken-burns.css'
    ];
    public $js = [
        'js/custom.js',
		'js/jssor.slider-27.4.0.min.js',
        'js/cropping/jquery.Jcrop.js',
        'js/cropping/jquery.SimpleCropper.js',
      /*start*/
        'js/app/plugins/smiley/js/emojione.min.js',
        'js/app/plugins/smiley/smiley.js',
        'js/app/includes/chatjs/lightbox.js',
		
      //'js/app/includes/chatjs/chat.js',
        'js/app/includes/chatjs/custom.js',
        /*end*/
      /*'js/app/plugins/smiley/js/emojione.min.js',
        'js/app/plugins/smiley/smiley.js',
        'js/app/includes/chatjs/lightbox.js',
        'js/app/includes/chatjs/chat.js',
        'js/app/includes/chatjs/custom.js'*/
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
        'yii\bootstrap\BootstrapPluginAsset',
    ];
}