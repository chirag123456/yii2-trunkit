<?php

require(__DIR__ . '/constant.php');
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=192.168.1.100;dbname=trunkit1', //192.168.1.100
            'username' => 'root',
            'password' => 'Admin@123', //Admin@123,xCeLtEC$123
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            'useFileTransport' => false, //set this property to false to send mails to real email addresses
            //comment the following array to send mail using php's mail function
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.gmail.com',
                'username' => 'demo.xceltec1@gmail.com',
                //'username' => 'Trunkit.info@gmail.com',
                'password' => 'xceltec@demo',
                //'password' => 'trunkit5970',
                'port' => '587',
                'encryption' => 'tls',
            ],
        ],
        'Paypal' => array(
            'class' => 'frontend\components\Paypal',
            'username' => 'demo.xceltec_api1.gmail.com', //APP User Name required
            'password' => '8QBHXM2DBGFJ22FS', //APP Password required
            'signature'=>'AvbrjyLw8e2V9PGT974X6JmrYVo9AtHOcto5SElebDmOX-ZuF82nfe1c', //APP Signature required
            'appid' => 'APP-80W284485P519543T', //APP Id required
            'sandbox' => true, // live or sandbox mode
            'returnUrl' => '', //regardless of url management component
            'cancelUrl' => '', //regardless of url management component
            // Default currency to use, if not set USD is the default
            'currencyCode' => 'USD', // currencyCode Required
        ),
        'Yii2Twilio' => array(
            'class' => 'filipajdacic\yiitwilio\YiiTwilio',
            'account_sid' => TWILIO_SID,
            'auth_key' => TWILIO_TOKEN, 
        ),
    ],
];
