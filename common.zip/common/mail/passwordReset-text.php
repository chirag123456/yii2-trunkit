<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */

/*$resetLink = Yii::$app->urlManager->createAbsoluteUrl(['site/reset-password', 'token' => $user->password_reset_token]);*/
//$resetLink =Yii::$app->request->hostInfo.'/site/reset-password?token='.$user->password_reset_token;
?>

Hello User,

Below the details your username and password:

Useranme: <?php echo $user['username'];?>
Email: <?php echo $user['email'];?>
Password: <?php echo $user['password'];?>
