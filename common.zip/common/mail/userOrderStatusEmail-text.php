<?php
    $resetLink = Yii::$app->urlManager->createAbsoluteUrl(['account-setting/notification']);

    if($user['first_name']=='' && $user['last_name']==''){
        $fname = $user['username'];
    }else{ 
        $fname = $user['first_name'].' '.$user['last_name'];
    } 
?>
                                                                
Hello <?= $fname ?>,

Title: <?php echo $user['title']; ?>

Order Details: <?php echo $user['description']; ?>

<?= Html::a('Click here to view notification details', $resetLink, ['target' => '_blank','class'=>'link','style' => 'color: #ffffff;']) ?>