<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\country;

use yii\base\Model;
use common\models\country\Country;

class CountryForm extends Model {

    public $country_name;
    public $id;

    public function rules() {

        return [
            [['country_name'], 'required'],
            [['country_name'], 'string', 'max' => 50],
            [['country_name'], 'custom_country_unique'],
        ];
    }

    public function getUpdateModel($model) {

        $this->country_name = $model->country_name;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'country_name' => 'Country Name',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'date_created' => 'Date Created',
            'date_updated' => 'Date Updated',
        ];
    }

    public function custom_country_unique($attribute, $params) {


        if (isset($_GET['id']) && !empty($_GET['id'])) {


            $check = Country::find()->where(['id' => $_GET['id']])->one();


            if ($check) {
                $cmp = ((strcasecmp(trim($check->country_name), trim($this->$attribute))));

                if ($cmp == 0) {


                    $check = true;
                } else {

                    $check = Country::find()->where(['country_name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();

                    if ($check) {

                        $this->addError($attribute, 'This Country' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Country::find()->where(['country_name' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();

            if ($check) {
                $this->addError($attribute, 'This Counrty' . ALREADY);
            }
        }
    }

}
