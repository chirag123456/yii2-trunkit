<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\userrole;

use yii\base\Model;
use common\models\userrole\UserRole;

class UserRoleForm extends Model {

    //public $id;
    public $name;
    //public $type;
    //public $description;
    //public $rule_name;
    //public $is_admin;
    //public $access;
    public $action;

    public function rules() {

        return [
            [['name'], 'required'],
            //[['name', 'state_id', 'country_id'], 'custom_city_unique'],
            [['name'], 'custom_role_unique'],
            [['name'], 'string', 'max' => 100],
            //[['type', 'description', 'rule_name', 'created_at', 'updated_at'], 'safe'],
            [['created_at', 'updated_at'], 'safe'],
        ];
    }

    public function getUpdateModel($model) {

        $this->name = $model->name;
        //$this->type = $model->type;
        //$this->description = $model->description;
        //$this->rule_name = $model->rule_name;
        return $this;
    }

    public function attributeLabels() {
        return [
            //'id' => 'ID',
            'name' => 'Role Name',
            //'type' => 'Type',
            //'description' => 'Description',
            'rule_name' => 'Rule Name',
            
            'created_at' => 'Date Created',
            'updated_at' => 'Date Updated',
        ];
    }

    public function custom_role_unique($attribute, $params) {
    
        if (isset($_GET['id']) && !empty($_GET['id'])) {

            $check = UserRole::find()->where(['name' => $_GET['id']])->one();


            if ($check) {
		//$cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))) && (strcasecmp($check->country_id, $_POST['CityForm']['country_id'])) && (strcasecmp($check->state_id, $_POST['CityForm']['state_id'])));                             
		$cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))));

                if ($cmp == 0) {
                    

                    $check = true;
                } else {                   

                   //$check = Area::find()->where(['name' => trim($this->$attribute)])->andWhere(['country_id' => $_POST['CityForm']['country_id']])->andWhere(['state_id' => $_POST['CityForm']['state_id']])->andWhere(['is_deleted' => NOT_DELETED])->one();
                   $check = UserRole::find()->where(['name' => trim($this->$attribute)])->one();

                  if ($check) {

                        $this->addError($attribute, 'This User Role Name' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = UserRole::find()->where(['name' => trim($this->$attribute)])
                            //->andWhere(['country_id' => $_POST['CityForm']['country_id']])
                            //->andWhere(['state_id' => $_POST['CityForm']['state_id']])
                            ->one();

            if ($check) {
                $this->addError($attribute, 'This User Role Name' . ALREADY);
            }
        }
    }

}