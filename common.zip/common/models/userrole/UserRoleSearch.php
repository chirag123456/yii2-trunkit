<?php

namespace common\models\userrole;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\userrole\UserRole;

/**
 * AreaSearch represents the model behind the search form about `common\models\Area`.
 */
class UserRoleSearch extends UserRole {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            //[['id'], 'integer'],
            [['name', 'type', 'description', 'rule_name', 'created_at', 'updated_at'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        //$query = UserRole::find()->where(['auth_item.is_delete' => NOT_DELETED]);
       //$query = UserRole::find()->where(['is_delete'=>NOT_DELETED , 'role'=> $role]);
        $query = UserRole::find();
        // add conditions that should always apply here

        $settings = \common\models\Settings::find()->one();
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
        $query->joinWith(['useraccess']);
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            //'sort' => ['defaultOrder' => ['name' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        //$query->joinWith(['state', 'country']);

        $query->andFilterWhere([
            //'id' => $this->id,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ]);
    
        $query->andFilterWhere(['like', 'user_access.name', $this->name]); //auth_item.name
                //->andFilterWhere(['like', 'auth_item.type', $this->type])
                //->andFilterWhere(['like', 'auth_item.description', $this->description]);
                
		//->andFilterWhere(['like', 'user_access.access', $this->name]);
                
		//->andFilterWhere(['like', 'schools_branches.school_name', $this->school_id])
                //->andFilterWhere(['like', 'auth_item.is_active', $this->is_active]);

        return $dataProvider;
    }

}