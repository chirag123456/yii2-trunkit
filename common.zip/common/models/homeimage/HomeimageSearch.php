<?php

namespace common\models\homeimage;
use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;


/**
 * CitySearch represents the model behind the search form about `common\models\City`.
 */
class HomeimageSearch extends Homeimage {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
           [['id','image_name','created_by','created_date','updated_by','updated_date','is_active','is_delete'],'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = Homeimage::find()->where(['is_delete' => NOT_DELETED]);
        // add conditions that should always apply here

        $pagesize=10;

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);
        

        $this->load($params);

        if (!$this->validate()) {
            
            return $dataProvider;
        }
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'image_name', $this->image_name])                
                ->andFilterWhere(['like', 'is_active', $this->is_active]);
        return $dataProvider;
    }

}
