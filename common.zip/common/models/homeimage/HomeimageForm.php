<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace common\models\homeimage;
use yii\base\Model;
use common\models\city\City;

class HomeimageForm extends Model {
    
    public $id;
    public $name;
    public $image_name;   
    public $created_by;
    public $created_date;
    public $updated_by;
    public $updated_date;
    public $is_active;
    public $is_delete;

    public function rules() {        
        return [
            [['name'],'required'],
            [['id','image_name','created_by','created_date','updated_by','updated_date','is_active','is_delete'],'safe']
        ];
    }

    public function getUpdateModel($model){
        $this->id=$model->id;
        $this->name=$model->name;
        $this->image_name=$model->image_name;
        $this->created_by=$model->created_by;
        $this->created_date=$model->created_date;
        $this->updated_by=$model->updated_by;
        $this->updated_date=$model->updated_date;
        return $this;        
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name'=>'Name',
            'image_name'=>'Image Name',            
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'is_delete' => 'Is Delete',
        ];
    }
}
