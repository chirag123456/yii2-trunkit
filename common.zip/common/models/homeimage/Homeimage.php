<?php
namespace common\models\homeimage;
use Yii;
/**
 * This is the model class for table "city".
 *
 * @property integer $id
 * @property string $name
 * @property integer $state_id
 * @property integer $country_id
 * @property string $is_active
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $date_created
 * @property string $date_updated
 * @property string $is_delete
 *
 * @property State $state
 * @property Country $country
 * @property User $createdBy
 * @property User $updatedBy
 * @property User[] $users
 */
class Homeimage extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'home_image';
    }
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'],'required'],
            [['id','image_name','created_by','created_date','updated_by','updated_date','is_active','is_delete'],'safe']
        ];
    }
    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'image_name' => 'Image Name',            
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'is_delete' => 'Is Delete',
        ];
    }
}
