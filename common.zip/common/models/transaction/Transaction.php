<?php

namespace common\models\transaction;

use common\models\user\User;
use Yii;
use yii\db\Query;

/**
 * This is the model class for table "Transaction History".
 *
 * @property int $id
 * @property int $user_id
 * @property string $origin
 * @property string $destination
 * @property string $post_date
 * @property int $year
 * @property string $post_type
 * @property string $routes_via
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class Transaction extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    
    
    public static function tableName() {
        return 'transactions_history';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['post_order_id', 'total_amount','paykey','transaction_id', 'transaction_datetime', 'transaction_type', 'from_user_id','to_user_id','to_user_paypal_email_id','admin_user_amt','to_user_amt','payment_status','transaction_status', 'created_by','created_date', 'updated_by', 'updated_date', 'ip_address','is_active','is_delete'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'post_order_id' => 'Post Order ID',
            'total_amount' => 'Total Amount',
            'paykey' => 'Paykey',
            'from_user_id' => 'From User',
            'to_user_id' => 'To User',
            'admin_user_amt' => 'Admin Commision', 
            'to_user_paypal_email_id' => 'To User Paypal Email Id',
            'to_user_amt' => 'To User Amount',
            'transaction_id' => 'Transaction ID',
            'transaction_datetime' => 'Transaction Date',
            'transaction_type' => 'Transaction Type',
            'payment_status' => 'Payment Status',
            'transaction_status' => 'Transaction Status',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' =>'IP Address',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getUser() {
        return $this->hasOne(User::className(), ['id' => 'from_user_id']);
    }

    public function getToUser() {
        return $this->hasOne(User::className(), ['id' => 'to_user_id']);
    }

    public function getQuantity() {
        return $this->hasMany(PostRequestItems::className(), ['post_id' => 'id'])->count();
    }

    /*public function getItemsize() {
        return $this->hasOne(PostTripVehicle::className(), ['post_id' => 'id']);
    }*/
    
    /*public function getItemrequest() {
        return $this->hasOne(PostRequestItems::className(), ['post_id' => 'id']);
    }*/
    
    /*public function getsize() {
        return $this->hasOne(PostTripAccept::className(), ['post_id' => 'id']);
    }*/
    
    public function getImageurl() {
        return Yii::$app->request->BaseUrl . '/uploads/users/' . $this->user->image;
    }

    public function getSpeaceSize() {
        return 0;//$this->hasOne(Post::className(), ['id' => 'post_request_id']);
    }

    public function getTransactionData($ids) {
        
        $query = new \yii\db\Query;;
        $query  ->select(['transactions_history.id', 'transactions_history.transaction_id', 'transactions_history.to_user_id', 'transactions_history.to_user_amt', 'users.id', 'users.first_name', 'users.last_name', 'users.paypal_email_id'])  
                ->from('transactions_history')
                ->join( 'INNER JOIN', 
                    'users',
                    'users.id =transactions_history.to_user_id'
                )
                ->where(['transactions_history.is_delete' => NOT_DELETED])
                ->andWhere(['transactions_history.is_exported' => NOT_DELETED])
                ->where(['IN','transactions_history.id', explode(',',$ids)]); 
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }

    public function getTransactionDetail($id)
    {
        $query = new Query;
        $query->select([
            'from_user.username as from_user_name',
            'to_user.username as to_user_name',
            'to_user.paypal_email_id as to_user_paypal_email_id', 
            'transactions_history.total_amount as total_amount',
            'transactions_history.transaction_id as transaction_id',
            'transactions_history.admin_user_amt as admin_user_amt',
            'transactions_history.to_user_amt as to_user_amt',
            'transactions_history.transaction_datetime as transaction_datetime',
        ])  
        ->from('transactions_history')->where(['transactions_history.id' => $id])
        ->join('LEFT OUTER JOIN', 'users from_user',
            'transactions_history.from_user_id = from_user.id') 
        ->join('LEFT OUTER JOIN', 'users to_user',
            'transactions_history.to_user_id = to_user.id');
        $command = $query->createCommand();
        $data = $command->queryOne();
        return $data;
    }
}
