<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\vehicletype;

use yii\base\Model;
use common\models\vehicletype\VehicleType;

class VehicleTypeForm extends Model {

    public $name;
    public $modifier;
    //public $parent_id;
    public $id;

    public function rules() {
        return [
            [['name','modifier'], 'required'],
            [['modifier'], 'double', 'message' => 'Modifier Must be Numeric'],
            [['name'], 'custom_vehicle_type_name_unique'],
        ];
    }

    public function getUpdateModel($model) {
        $this->name = $model->name;
        $this->modifier = $model->modifier;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'modifier' => 'Modifier',
            'name' => 'Vehicle Type Name',
            'is_active' => 'Status',
        ];
    }

    public function custom_vehicle_type_name_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = VehicleType::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {

                    $check = VehicleType::find()->where(['name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();

                    if ($check) {

                        $this->addError($attribute, 'This Vehicle Type Name' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = VehicleType::find()->where(['name' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Vehicle Type Name ' . ALREADY);
            }
        }
    }

}
