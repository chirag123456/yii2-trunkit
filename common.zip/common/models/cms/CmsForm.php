<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\cms;

use yii\base\Model;
use common\models\cms\Cms;

class CmsForm extends Model {

    public $name;
    public $content;
    public $slug;

    public function rules() {

        return [
            [['name'], 'required'],
            [['slug'], 'safe'],
            ['name' , 'custom_name_unique'],
        ];
    }

    public function getUpdateModel($model) {

        $this->name = $model->name;
        $this->content = $model->content;
        $this->slug = $model->slug;

        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'content' => 'Content ',
            'slug' => 'Slug ',
        ];
    }

    public function custom_name_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {

            $check = Cms::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {

                    $check = Cms::find()->where(['name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();

                    if ($check) {

                        $this->addError($attribute, NAME);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
           $check = Cms::find()->where(['name' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, NAME);
            }
        }
    }
}
