<?php

namespace common\models\cms;

use Yii;

/**
 * This is the model class for table "cms".
 *
 * @property integer $id
 * @property string $name
 * @property string $content
 * @property string $is_active
 * @property string $is_delete
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $date_created
 * @property string $date_updated
 */
class Cms extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cms';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['content','is_active', 'is_delete'], 'string'],
            [['created_by', 'updated_by'], 'integer'],
            [['date_created','date_updated','slug'], 'safe'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'content' => 'Content',
			'slug' => 'Slug',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'date_created' => 'Date Created',
            'date_updated' => 'Date Updated',
        ];
    }
}
