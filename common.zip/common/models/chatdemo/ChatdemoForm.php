<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\chatdemo;

/**
 * Description of Chatdemoform
 *
 * @author xceltec35
 */
class ChatdemoForm extends Model{
    
     public function rules() {
        return [
            [['from_id','to_id','from_uname','message_content'],'string'],
            [['recd','seen','message_type'],'safe'],
        ];
    }
    
    public function attributeLabels() {
       return[
           'message_id'=>'Message ID',
           'from_id'=>'From ID',
           'to_id'=>'To ID',
           'from_uname'=>'From UserName',
           'to_uname'=>'To_User Name',
           'message_content'=>'',
           'recd'=>'recd',
           'seen'=>'Seen',
           'message_type'=>'Message Type'
       ];
    }
}