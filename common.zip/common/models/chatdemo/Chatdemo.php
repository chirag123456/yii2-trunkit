<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Checkdemo
 *
 * @author xceltec35
 */
namespace common\models\chatdemo;
use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
class Chatdemo extends ActiveRecord implements IdentityInterface{
    
    public static function tableName() {
        return 'test_messages';
    }
    public function rules() {
        return [
            [['from_id','to_id','from_uname','message_content'],'safe'],            
            [['seen','message_type'],'safe'],
            [['recd'],'integer']
        ];
    }
    public function attributeLabels() {
       return[
           'message_id'=>'Message ID',
           'from_id'=>'From ID',
           'to_id'=>'To ID',
           'from_uname'=>'From UserName',
           'to_uname'=>'To_User Name',
           'message_content'=>'',
           'recd'=>'recd',
           'seen'=>'Seen',
           'message_type'=>'Message Type'
       ];
    }

    public function getAuthKey(): string {
        
    }

    public function getId() {
          return $this->getPrimaryKey();
    }

    public function validateAuthKey($authKey): bool {
        
    }

    public static function findIdentity($id): IdentityInterface {
        return static::findOne(['message_id' => $id]);
    }

    public static function findIdentityByAccessToken($token, $type = null): IdentityInterface {
        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    }
    function timeAgo($timestamp){
        
        $datetime1=date_create(date('d-m-Y H:i:s'));
        $datetime2=date_create($timestamp);
        $diff=date_diff($datetime1, $datetime2);
        $timemsg='';
        if($diff->y > 0){
            $timemsg = $diff->y .' year'. ($diff->y > 1?"s":'');

        }
        else if($diff->m > 0){
            $timemsg = $diff->m . ' month'. ($diff->m > 1?"s":'');
        }
        else if($diff->d > 0){
            $timemsg = $diff->d .' day'. ($diff->d > 1?"s":'');
        }
        else if($diff->h > 0){
            $timemsg = $diff->h .' hour'.($diff->h > 1 ? "s":'');
        }
        else if($diff->i > 0){
            $timemsg = $diff->i .' minute'. ($diff->i > 1?"s":'');
        }
        else if($diff->s > 0){
            $timemsg = $diff->s .' second'. ($diff->s > 1?"s":'');
        }
        if($timemsg == "")
            $timemsg = "Just now";
        else
            $timemsg = $timemsg.' ago';

        return $timemsg;
    }
     
}