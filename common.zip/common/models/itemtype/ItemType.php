<?php

namespace common\models\itemtype;

use Yii;

/**
 * This is the model class for table "item_type".
 *
 * @property int $id
 * @property string $name
 * @property int $status
 * @property string $is_active
 * @property string $is_delete
 */
class ItemType extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'item_type';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name','is_active', 'is_delete'], 'required'],
            //[['status'], 'integer'],
            [['is_active', 'is_delete'], 'string'],
            [['name'], 'string', 'max' => 20],
            [['name'], 'custom_make_model_name_unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Item Type',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function custom_make_model_name_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = ItemType::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {

                    $check = ItemType::find()->where(['name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->andWhere('id !='.$_GET['id'])->one();

                    if ($check) {

                        $this->addError($attribute, 'This Item Type' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = ItemType::find()->where(['name' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Item Type' . ALREADY);
            }
        }
    }
}
