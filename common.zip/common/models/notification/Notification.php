<?php

namespace common\models\notification;

use Yii;
use yii\db\ActiveRecord;
use common\models\user\User;
use common\models\post\Post;
//use common\models\siteconfiguration\SiteConfiguration;

class Notification extends ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return '{{%notification}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['from_user_id', 'to_user_id', 'post_id', 'type', 'title', 'description', 'created_by', 'updated_by', 'created_date', 'updated_date', 'is_active', 'is_delete', 'is_seen', 'order_id'], 'safe']
        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'from_user_id' => 'From User',
            'to_user_id' => 'To User',
            'title' => 'Title',
            'description' => 'Description',
            'type' => 'Type',
            'order_id' => 'Order',
            'is_active' => 'Status',
        ];
    }

    public function getFromuser() {
        return $this->hasOne(User::className(), ['id' => 'from_user_id']);
    }

    public function getTouser() {
        return $this->hasOne(User::className(), ['id' => 'to_user_id']);
    }

    public function getPost() {
        return $this->hasOne(Post::className(), ['id' => 'post_id']);
    }

    public function getNotification($id)
    { 
        $connection = Yii::$app->getDb();
            $command3 = $connection->createCommand(
                    "SELECT po.*,
                p.id as post_request_id, 
                p.origin as post_request_origin,
                p.destination as post_request_destination,
                p1.routes_via as post_accept_routes_via,
                p.departure_date as post_request_departure_date,
                p.post_type as post_request_post_type,
                p.user_id as post_request_user_id,
                p1.id as post_accept_id, 
                p1.origin as post_accept_origin,
                p1.origin_lat as post_accept_origin_lat,
                p1.origin_long as post_accept_origin_long,
                p1.destination as post_accept_destination,
                p1.destination_lat as post_accept_destination_lat,
                p1.destination_long as post_accept_destination_long,
                p1.departure_date as post_accept_departure_date, 
                p1.post_type as post_accept_post_type,
                p1.user_id as post_accept_user_id,
                p1.post_date as p1_post_date,
                p1.departure_date as departure_date,
                ptv.year as pte_year,
                ptv.plate_number as pte_plate_number,
                vmm.make_model_name as vmm_make_model_name,
                vt.name as vt_name,
                vc.name as vc_name,
                
                n.to_user_id as n_to_user_id

                FROM post_order as po 
                INNER JOIN post p1 ON po.post_accept_id  = p1.id 
                INNER JOIN post p ON po.post_request_id = p.id
                INNER JOIN post_trip_vehicle ptv ON ptv.post_id  = p1.id 
                INNER JOIN vehicle_make_model vmm ON vmm.id  = ptv.model_id 
                INNER JOIN vehicle_type vt ON vt.id  = ptv.vehicle_type 
                INNER JOIN vehicle_color vc ON vc.id  = ptv.color
                
                INNER JOIN notification n ON po.traking_number  = n.order_id
                INNER JOIN post_request_items pri ON pri.post_id  = p.id
                INNER JOIN item_type it ON it.id  = pri.item_type_id

                WHERE po.is_active = 'Y' 
                AND po.is_delete = 'N'  
                AND po.traking_number = " . $id . " 
                ");
            $details1 = $command3->queryAll();
            return $details1;
    }

    public function getPostRequestItems($id)
    {
        $connection = Yii::$app->getDb();
        $commanditems = $connection->createCommand(
                "SELECT 
            pri.description as pri_description,
            pri.item_weight as pri_item_weight, 
            pri.image1 as pri_image1,
            pri.image2 as pri_image2,
            it.name as it_name,
            its.name as is_name

            FROM post_request_items as pri
            INNER JOIN item_type it ON it.id  = pri.item_type_id
            INNER JOIN item_size its ON its.id  = pri.space_size_id

            WHERE pri.post_id =  " . $id . "
        ");
        $detailsitems = $commanditems->queryAll();
        return $detailsitems;
    }

    public function sendUserOrderStatusEmail($notification) {
   
        //$fromEmail = SiteConfiguration::getConfigureValueByKey('demo.xceltec4@gmail.com');
        $fromEmail = 'demo.xceltec4@gmail.com';
             
        $id = $notification['to_user_id'];
        $user = User::findOne(['id' => $id]);
        if($user->username!='')
            $notification['username'] = $user->username;
        else
            $notification['username'] = '';
        $notification['first_name'] = $user->first_name;
        $notification['last_name'] =  $user->last_name;
   
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'userOrderStatusEmail-html'], ['user' => $notification]
                        )
                        ->setFrom($fromEmail)
                        ->setTo($user->email)
                        ->setSubject('Item Status')
                        //->setSubject('User Order Status')
                        ->send();
    }

    public function sendTripDriverEmail($notification) {
   
        //$fromEmail = SiteConfiguration::getConfigureValueByKey('demo.xceltec4@gmail.com');
        $fromEmail = 'demo.xceltec4@gmail.com';
             
        $id = $notification['to_user_id'];
        $user = User::findOne(['id' => $id]);
        if($user->username!='')
            $notification['username'] = $user->username;
        else
            $notification['username'] = '';
        $notification['first_name'] = $user->first_name;
        $notification['last_name'] =  $user->last_name;
        
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'tripDriverEmail-html'], ['user' => $notification]
                        )
                        ->setFrom($fromEmail)
                        ->setTo($user->email)
                        ->setSubject('Item owner is interested in trip')
                        //->setSubject('User Order Status')
                        ->send();
    }

    
}
