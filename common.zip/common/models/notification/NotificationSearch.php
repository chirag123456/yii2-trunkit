<?php

namespace common\models\notification;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\notification\Notification;

/**
 * AreaSearch represents the model behind the search form about `common\models\Area`.
 */
class NotificationSearch extends Notification {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['from_user_id', 'to_user_id', 'post_id', 'type', 'title','description', 'created_by', 'updated_by', 'created_date','updated_date', 'is_active','is_delete','is_seen'], 'safe']
        ];
    }


    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = Notification::find()->where(['notification.is_delete' => NOT_DELETED,'to_user_id' => Yii::$app->user->identity->id]);

        // add conditions that should always apply here

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        

        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'title', $this->title])
                ->andFilterWhere(['like', 'description', $this->description])
                ->andFilterWhere(['like', 'is_active', $this->is_active]);

        return $dataProvider;
    }
      public function search1($params) {
        $query = Notification::find()->where(['notification.is_delete' => NOT_DELETED]);

        // add conditions that should always apply here
        
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
        
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);
        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        

        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'updated_by' => $this->updated_by,
            'created_date' => $this->created_date,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'title', $this->title])
                ->andFilterWhere(['like', 'description', $this->description])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'is_seen', $this->is_seen]);

        return $dataProvider;
    }

}
