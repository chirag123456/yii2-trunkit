<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\notification;

use yii\base\Model;
use common\models\notification\Notification;

class NotificationForm extends Model {

    public $id;
    public $title;
    public $description;

    public function rules() {

        return [
            [['title'], 'required'],
            [['title'], 'custom_title_unique'],
            [['title'], 'string', 'max' => 100],
            [['description', 'is_active', 'created_by', 'updated_by', 'created_date', 'is_delete', 'updated_date'], 'safe'],
           ];
    }

    public function getUpdateModel($model) {

        $this->title = $model->title;
        $this->description = $model->description;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'description' => 'Description',
            'is_active' => 'Is Active',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
        ];
    }

    public function custom_title_unique($attribute, $params) {

        if (isset($_GET['id']) && !empty($_GET['id'])) {

            $check = Notification::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->title), trim($this->$attribute))));

                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = Notification::find()->where(['title' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This Notification Title' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = Notification::find()->where(['title' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();

            if ($check) {
                $this->addError($attribute, 'This Notification Title' . ALREADY);
            }
        }
    }

}
