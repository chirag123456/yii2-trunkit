<?php

namespace common\models\relation;

use common\models\user\User;

use Yii;

/**
 * This is the model class for table "trip_request_relation".
 *
 * @property int $id
 * @property int $trip_user_id
 * @property int $request_user_id
 * @property int $trip_post_id
 * @property int $request_post_id
 * @property string $trip_origin
 * @property string $trip_destination
 * @property string $request_origin
 * @property string $request_destination
 */
class TripRequestRelation extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'trip_request_relation';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['trip_user_id', 'request_user_id', 'trip_post_id', 'request_post_id'], 'integer'],
            [['trip_origin', 'trip_destination', 'request_origin', 'request_destination'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'trip_user_id' => 'Trip User ID',
            'request_user_id' => 'Request User ID',
            'trip_post_id' => 'Trip Post ID',
            'request_post_id' => 'Request Post ID',
            'trip_origin' => 'Trip Origin',
            'trip_destination' => 'Trip Destination',
            'request_origin' => 'Request Origin',
            'request_destination' => 'Request Destination',
        ];
    }

    public function getTripuser() {
        return $this->hasOne(User::className(), ['id' => 'trip_user_id']);
    }

    public function getRequestuser() {
        return $this->hasOne(User::className(), ['id' => 'request_user_id']);
    }

}
