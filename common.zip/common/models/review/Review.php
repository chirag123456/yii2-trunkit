<?php

namespace common\models\review;

use common\models\user\User;
use Yii;

class Review extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    
    
    public static function tableName() {
        return 'review';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['user_id','to_user_id', 'post_id', 'rating', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            [['user_id',  'created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date', 'comments'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
            
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'user_id' => 'From User ID',
            'to_user_id' => 'To User ID',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getFromUser() {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public function getToUser() {
        return $this->hasOne(User::className(), ['id' => 'to_user_id']);
    }

	public function getRatingHtml($rate){
		$html = '';
		for( $i=1;$i<=5;$i++ ){
			if( $i <= $rate ){
				$html .= '<i class="fa fa-star" style="color: orange;"></i>';
			}else{
				$html .= '<i class="fa fa-star"></i>';
			}
		}
		return $html;
	}

}
