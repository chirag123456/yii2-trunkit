<?php

namespace common\models\review;

use Yii;
use yii\base\Model;
use common\models\review\Review;
use common\models\post\Post;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;

/**
 * PostSearch represents the model behind the search form of `common\post\Post`.
 */
class ReviewSearch extends Review {

    public $user_name;

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['rating','to_user_id', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'safe'],
            [['user_id', 'created_by', 'updated_by'], 'integer'],
            [['user_id', 'post_id', 'order_status', 'created_date', 'updated_date',], 'safe'],
            [['is_active', 'is_delete', 'comments'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = Review::find()->where(['is_delete' => NOT_DELETED])->andWhere(['!=', 'rating', 0]);
        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);

         

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'rating' => $this->rating,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'comments', $this->comments])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'user.email', $this->to_user_id])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

    
}
