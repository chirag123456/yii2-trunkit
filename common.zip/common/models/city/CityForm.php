<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\city;

use yii\base\Model;
use common\models\city\City;

class CityForm extends Model {

    public $name;
    public $state_id;
    public $country_id;
    public $id;
    public $state_name;
    public $position;

    public function rules() {

        return [
            [['name', 'state_id', 'country_id'], 'required'],
            [['name', 'state_id', 'country_id'], 'custom_city_unique'],
            [['position'],'safe'],
            [['state_id'], 'exist', 'skipOnError' => true, 'targetClass' => \common\models\state\State::className(), 'targetAttribute' => ['state_id' => 'id']],
            [['country_id'], 'exist', 'skipOnError' => true, 'targetClass' => \common\models\country\Country::className(), 'targetAttribute' => ['country_id' => 'id']],
        ];
    }

    public function getUpdateModel($model) {

        $this->name = $model->name;
        $this->country_id = isset($model->country_id) ? $model->country_id : 'N\A';
        $this->state_id = isset($model->state_id) ? $model->state_id : 'N\A';

        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'name' => 'City',
            'state_id' => 'State',
            'country_id' => 'Country',
            'is_active' => 'Is Active',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
        ];
    }

    public function custom_city_unique($attribute, $params) {


        if (isset($_GET['id']) && !empty($_GET['id'])) {

            $check = City::find()->where(['id' => $_GET['id']])->one();


            if ($check) {
       $cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))) && (strcasecmp($check->country_id, $_POST['CityForm']['country_id'])) && (strcasecmp($check->state_id, $_POST['CityForm']['state_id'])));                             

                if ($cmp == 0) {
                    

                    $check = true;
                } else {                   

                   $check = City::find()->where(['name' => trim($this->$attribute)])->andWhere(['country_id' => $_POST['CityForm']['country_id']])->andWhere(['state_id' => $_POST['CityForm']['state_id']])->andWhere(['is_delete' => NOT_DELETED])->one();

                  if ($check) {

                        $this->addError($attribute, 'This City' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = City::find()->where(['name' => trim($this->$attribute)])
                            ->andWhere(['country_id' => $_POST['CityForm']['country_id']])
                            ->andWhere(['state_id' => $_POST['CityForm']['state_id']])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();

            if ($check) {
                $this->addError($attribute, 'This City' . ALREADY);
            }
        }
    }

}
