<?php

namespace common\models\vehiclemakemodel;

use Yii;

/**
 * This is the model class for table "vehicle_make_model".
 *
 * @property integer $id
 * @property string $make_model_name
 * @property integer $created_by
 * @property string $created_date
 * @property integer $updated_by
 * @property string $updated_date
 * @property string $ip_address
 * @property string $is_active
 * @property string $is_delete
 *
 * @property Drivers[] $drivers
 * @property PassengersOrders[] $passengersOrders
 * @property AdminUser $createdBy
 * @property AdminUser $updatedBy
 */
class VehicleMakeModel extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'vehicle_make_model';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['make_model_name', 'parent_id'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date', 'parent_id'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
            [['make_model_name'], 'string', 'max' => 60],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'make_model_name' => 'Vehicle Make/Model Name',
            'parent_id' => 'Parent Make/Model',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' => 'Ip Address',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVehicleMakeModelData() {
        $dataArr = self::find()->select(['id', 'make_model_name'])->where(['is_active' => ACTIVE, 'is_delete' => NOT_DELETED])->all();
        if ($dataArr != null) {
            return $dataArr;
        } else {
            return 'No data!';
        }
    }

    public function getModelName($id) {
        $dataArr = self::find()->select(['make_model_name'])->where(['is_active' => ACTIVE, 'is_delete' => NOT_DELETED,'id'=>$id])->one();
        if ($dataArr != null) {
            return $dataArr->make_model_name;
        } else {
            return 'No data!';
        }
    }

}
