<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\vehiclemakemodel;

use yii\base\Model;
use common\models\vehiclemakemodel\VehicleMakeModel;

class VehicleMakeModelForm extends Model {

    public $make_model_name;
    public $slug;
    public $parent_id;
    public $id;

    public function rules() {
        return [
            [['make_model_name', 'parent_id'], 'required'],
            [['make_model_name'], 'custom_make_model_name_unique'],
        ];
    }

    public function getUpdateModel($model) {
        $this->make_model_name = $model->make_model_name;
        $this->slug = $model->slug;
        $this->parent_id = $model->parent_id;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'make_model_name' => 'Vehicle Make/Model Name',
            'parent_id' => 'Parent Make/Model Name',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'date_created' => 'Date Created',
            'date_updated' => 'Date Updated',
        ];
    }

    public function custom_make_model_name_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = VehicleMakeModel::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->make_model_name), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {

                    $check = VehicleMakeModel::find()->where(['make_model_name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();

                    if ($check) {

                        $this->addError($attribute, 'This Vehicle Make Model' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = VehicleMakeModel::find()->where(['make_model_name' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Vehicle Make Model' . ALREADY);
            }
        }
    }

}
