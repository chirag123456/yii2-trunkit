<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "settings".
 *
 * @property integer $id
 * @property integer $paging
 * @property string $from_email
 * @property string $to_email
 * @property string $cc_email
 * @property string $bcc_email
 * @property string $smtp_host
 * @property string $smtp_port
 * @property string $smtp_username
 * @property string $smtp_password
 * @property integer $created_by
 * @property integer $updated_by
 * @property string $date_created
 * @property string $date_updated
 *
 * @property User $createdBy
 * @property User $updatedBy
 */
class Settings extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'site_configuration';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['paging', 'from_email', 'to_email', 'cc_email', 'bcc_email', 'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password', 'created_by', 'updated_by', 'date_created', 'date_updated'], 'required'],
            [['paging', 'created_by', 'updated_by'], 'integer'],
            [['date_created', 'date_updated'], 'safe'],
            [['from_email', 'to_email', 'cc_email', 'bcc_email', 'smtp_host', 'smtp_port', 'smtp_username', 'smtp_password'], 'string', 'max' => 255],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'paging' => 'Paging',
            'from_email' => 'From Email',
            'to_email' => 'To Email',
            'cc_email' => 'Cc Email',
            'bcc_email' => 'Bcc Email',
            'smtp_host' => 'Smtp Host',
            'smtp_port' => 'Smtp Port',
            'smtp_username' => 'Smtp Username',
            'smtp_password' => 'Smtp Password',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'date_created' => 'Date Created',
            'date_updated' => 'Date Updated',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }
}
