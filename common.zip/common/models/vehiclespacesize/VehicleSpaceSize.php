<?php

namespace common\models\vehiclespacesize;

use Yii;

/**
 * This is the  model class for table "item_size".
 *
 * @property int $id
 * @property string $name
 * @property int $status
 * @property string $is_active
 * @property string $is_delete
 */ 
class VehicleSpaceSize extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'vehicle_spacesize';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'is_active', 'is_delete'], 'required'],
            [['is_active', 'is_delete'], 'string'],
            [['name'], 'string', 'max' => 20],
            [['name'], 'custom_space_size_unique'],

        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Vehicle Space Size',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function custom_space_size_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = VehicleSpaceSize::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = ((strcasecmp(trim($check->name), trim($this->$attribute))));
                if ($cmp == 0) {
                    $check = true;
                } else {

                    $check = VehicleSpaceSize::find()->where(['name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->andWhere('id !='.$_GET['id'])->one();

                    if ($check) {

                        $this->addError($attribute, 'This Vehicle Space Size' . ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = VehicleSpaceSize::find()->where(['name' => trim($this->$attribute)])
                            ->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Vehicle Space Size' . ALREADY);
            }
        }
    }
}
