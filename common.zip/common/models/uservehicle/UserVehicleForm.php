<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\uservehicle;

use Yii;
use yii\base\Model;
use common\models\uservehicle\UserVehicle;

class UserVehicleForm extends Model {

    public $id;
    public $model_id;
    public $type_id;
    public $plate_number;
    public $year;
    public $user_id;
    public $image_1;
    public $image_2;
    public $color;
    public $capacity;
    public $description;
    public $vehicle_count;
    public $space_available;

    public $hidden_vehicle_type;
    public $hidden_model;
    public $hidden_plate_number;
    public $hidden_color;
    public $hidden_space_available;
    public $hidden_image1;
    public $hidden_image2;

    public function rules() {
        return [
            [['id', 'model_id', 'user_id', 'type_id', 'plate_number', 'year', 'color', 'vehicle_count','space_available'], 'required'],
            [['description', 'capacity', 'image_1', 'image_2'], 'safe'],
            [['hidden_vehicle_type','hidden_model','hidden_plate_number','hidden_color','hidden_space_available'],'safe'],
            ['plate_number', 'custom_plate_number_unique'],
            ['plate_number', 'match', 'pattern' => '/^[a-zA-Z0-9]+$/', 'message' => 'Plate Number can only contain alphanumeric characters.']
        ];
    }

    public function getUpdateModel($model) {
        $this->model_id = $model->model_id;
        $this->type_id = $model->type_id;
        $this->image_1 = $model->image_1;
        $this->image_2 = $model->image_2;
        $this->plate_number = $model->plate_number;
        $this->year = $model->year;
        $this->color = $model->color;
        $this->capacity = $model->capacity;
        $this->description = $model->description;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'model_id' => 'Vehicle Make',
            'plate_number' => 'Plate Number',
            'type_id' => 'Vehicle Type',
            'year' => 'Vehicle Year',
            'description' => 'Description (Optional)',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' => 'Ip Address',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
        ];
    }

    public function custom_plate_number_unique($attribute, $params) {
        $details = UserVehicle::find()->where(['is_delete' => INACTIVE])->andWhere(['plate_number' => $this->plate_number])->one();
        if(isset($this->id) && $this->id!=''){
            $is_change = UserVehicle::find()->where(['plate_number' => $this->plate_number])->andWhere(['is_delete' => NOT_DELETED])->andWhere('id != ' .$this->id)->one();
            if(!empty($is_change)){
                $this->addError($attribute, PLATE_NO);    
            }
        }else{
            if(!empty($details)){
                $this->addError($attribute, PLATE_NO);
            }
        }
    }

}