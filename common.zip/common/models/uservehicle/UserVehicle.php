<?php

namespace common\models\uservehicle;

use Yii;
use common\models\vehicletype\VechicleType;
use common\models\vehiclemakemodel\VehicleMakeModel;

class UserVehicle extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'user_vehicle';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['model_id','year','type_id','plate_number','image_1','image_2','color','vehicle_count','space_available'], 'required'],
            [['created_by', 'updated_by'], 'integer'],
            [['created_date', 'updated_date', 'user_id','description','capacity'], 'safe'],
            [['is_active', 'is_delete'], 'string'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'model_id' => 'Vehicle Make',
            'plate_number' => 'Plate Number',
            'type_id' => 'Vehicle Type',
            'year' => 'Vehicle Year',
            'color' => 'Vehicle Color',
            'description' => 'Description',
            'vehicle_count' => 'Vehicle Count',
            'capacity' => 'Vehicle Capacity',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' => 'Ip Address',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUserVehicleData() {
        $dataArr = self::find()->select(['id', 'model_id'])->where(['is_active' => ACTIVE, 'is_delete' => NOT_DELETED])->all();
        if ($dataArr != null) {
            return $dataArr;
        } else {
            return 'No data!';
        }
    }

    /*public function getType() {
        return $this->hasOne(VechicleType::className(), ['id' => 'type_id']);
    }*/

    public function getType() {
        return $this->hasOne(VehicleMakeModel::className(), ['id' => 'model_id']);
    }
}
