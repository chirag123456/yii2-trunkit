<?php

namespace common\models;

use Yii;
use yii\base\Model;
use common\models\user\User;

/**
 * Login form
 */
class LoginForm extends Model {

    public $email;
    public $password;
    public $fb_id;
    public $rememberMe = true;
    private $_user;

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['email', 'password'], 'required'],
            ['email', 'email', 'message' => 'Please enter valid email address.'],
            ['email', 'exist',
                'targetClass' => '\common\models\user\User',
                'filter' => ['is_active' => User::STATUS_ACTIVE,'is_delete'=> User::NOT_DELETED],
                'message' => 'There is no user found with this email address.'
            ],
            
            ['rememberMe', 'boolean'],
            ['password', 'validatePassword'],
            
        ];
    }

    /**
     * Validates the password.
     * This method serves as the inline validation for password.
     *
     * @param string $attribute the attribute currently being validated
     * @param array $params the additional name-value pairs given in the rule
     */
    public function validatePassword($attribute, $params) {
        if (!$this->hasErrors()) {
            $user = $this->getUser();
            if (!$user || !$user->validatePassword($this->password)) {
                $this->addError($attribute, 'Incorrect email or password.');
            }
        }
    }

    /**
     * Logs in a user using the provided username and password.
     *
     * @return bool whether the user is logged in successfully
     */
    public function login() {
        if ($this->validate()) {
            return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600 * 24 * 30 : 0);
        } else {
            return false;
        }
    }

    public function sign_up_email_verify($attribute, $params) {       
            $check = User::find()->where(['email' => trim($this->$attribute)])->andWhere(['is_email_verify' => NOT_DELETED,'is_active' => ACTIVE ])->one();
            if ($check) {
                $this->addError($attribute, 'Please confirm your email address using the verification link sent to you.');
            }
    }
    
    public function adminLogin() {
        if ($this->validate()) {
            return Yii::$app->user->login($this->getAdmin(), $this->rememberMe ? 3600 * 24 * 30 : 0);
        } else {
            return false;
        }
    }

    public function loginAdmin() {

        if ($this->validate() && User::isUserAdmin($this->email)) {

            return Yii::$app->user->login($this->getUser(), $this->rememberMe ? 3600 * 24 * 30 : 0);
        } else {
            return false;
        }
    }

    /**
     * Finds user by [[username]]
     * @return User|null
     */
    protected function getUser() {
        if ($this->_user === null) {
            $this->_user = User::findByUsername($this->email);
        }
        return $this->_user;
    }

    protected function getAdmin() {
        if (User::findByAdmin($this->email)) {
            $this->_user = User::findByAdmin($this->email);
        } else {
            return false;
        }
        return $this->_user;
    }

}
