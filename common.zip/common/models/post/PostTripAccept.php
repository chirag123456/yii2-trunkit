<?php

namespace common\models\post;

use Yii;

/**
 * This is the model class for table "post_trip_accept".
 *
 * @property int $id
 * @property int $post_id
 * @property string $small_item
 * @property string $medium_item
 * @property string $large_item
 * @property string $xlarge_item
 * @property string $two
 */
class PostTripAccept extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'post_trip_accept';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['post_id'], 'required'],
            [['post_id'], 'integer'],
            [['is_active', 'is_delete','xlarge_item_qty','large_item_qty','medium_item_qty','small_item_qty','two_qty','small_item_suggested_price','medium_item_suggested_price','large_item_suggested_price','xlarge_item_suggested_price'], 'safe'],
            [['small_item', 'medium_item', 'large_item', 'xlarge_item', 'two'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'post_id' => 'Post ID',
            'small_item' => 'Small Item',
            'medium_item' => 'Medium Item',
            'large_item' => 'Large Item',
            'xlarge_item' => 'Xlarge Item',
            'two' => 'Two',
        ];
    }

}
