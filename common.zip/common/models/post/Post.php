<?php

namespace common\models\post;

use common\models\user\User;
use common\models\vehiclecolor\VehicleColor;
use yii\db\Query;
//use common\models\uservehicle\UserVehicle;
use common\models\itemtype\ItemType;

//use common\models\post\PostRequestItems;
use common\models\vehicletype\VechicleType;
use common\models\post\PostOrder;
use common\models\post\PostTripAccept; 
use common\models\vehiclemakemodel\VehicleMakeModel;
use common\models\itemsize\ItemSize;
use Yii;

/**
 * This is the model class for table "post".
 *
 * @property int $id
 * @property int $user_id
 * @property string $origin
 * @property string $destination
 * @property string $post_date
 * @property int $year
 * @property string $post_type
 * @property string $routes_via
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class Post extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */

    public static function tableName() {
        return 'post';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['user_id', 'origin', 'destination', 'post_date', 'post_type', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'required'],
            [['user_id', 'year', 'created_by', 'updated_by'], 'integer'],
            [['post_date', 'departure_date','make_model_new','created_date', 'updated_date', 'routes_via', 'year'], 'safe'],
            [['post_type', 'is_active', 'is_delete'], 'string'],
            [['origin', 'destination'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'origin' => 'Origin',
            'destination' => 'Destination',
            'post_date' => 'Post Date',
            'year' => 'Year',
            'post_type' => 'Post Type',
            'routes_via' => 'Routes Via',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }

    public function getUser() {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public function getQuantity() {
        return $this->hasMany(PostRequestItems::className(), ['post_id' => 'id'])->count();
    }

    public function getItemsiz() {
        return $this->hasOne(PostTripVehicle::className(), ['post_id' => 'id']);
    }
    
    public function getItemrequest() {
        return $this->hasOne(PostRequestItems::className(), ['post_id' => 'id']);
    }
    
    public function getsize() {
        return $this->hasOne(PostTripAccept::className(), ['post_id' => 'id']);
    }
    
    public function getImageurl() {
        return Yii::$app->request->BaseUrl . '/uploads/users/' . $this->user->image;
    }

    public function getSpeaceSize() {
        return 0;//$this->hasOne(Post::className(), ['id' => 'post_request_id']);
    } 
    
    public function getDetails($id){
        $connection = Yii::$app->getDb();
        $command3 = $connection->createCommand(
                "SELECT po.*,
            p.id as post_request_id, 
            p.origin as post_request_origin,
            p.destination as post_request_destination,
            p1.routes_via as post_accept_routes_via,
            p.departure_date as post_request_departure_date,
            p.post_type as post_request_post_type,
            p.user_id as post_request_user_id,
            p1.id as post_accept_id, 
            p1.origin as post_accept_origin,
            p1.origin_lat as post_accept_origin_lat,
            p1.origin_long as post_accept_origin_long,
            p1.destination as post_accept_destination,
            p1.destination_lat as post_accept_destination_lat,
            p1.destination_long as post_accept_destination_long,
            p1.departure_date as post_accept_departure_date, 
            p1.post_type as post_accept_post_type,
            p1.user_id as post_accept_user_id,
            p1.post_date as p1_post_date,
            ptv.year as pte_year,
            ptv.plate_number as pte_plate_number,
            vmm.make_model_name as vmm_make_model_name,
            vt.name as vt_name,
            vc.name as vc_name,
            
            n.to_user_id as n_to_user_id

            FROM post_order as po 
            INNER JOIN post p1 ON po.post_accept_id  = p1.id 
            INNER JOIN post p ON po.post_request_id = p.id
            INNER JOIN post_trip_vehicle ptv ON ptv.post_id  = p1.id 
            INNER JOIN vehicle_make_model vmm ON vmm.id  = ptv.model_id 
            INNER JOIN vehicle_type vt ON vt.id  = ptv.vehicle_type 
            INNER JOIN vehicle_color vc ON vc.id  = ptv.color
            
            INNER JOIN notification n ON po.traking_number  = n.order_id
            INNER JOIN post_request_items pri ON pri.post_id  = p.id
            INNER JOIN item_type it ON it.id  = pri.item_type_id

            WHERE po.is_active = 'Y' 
            AND po.is_delete = 'N'  
            AND po.traking_number = " . $id . " 
            ");
        return $details1 = $command3->queryOne();
    }

    public function getVehicle() {

        return $this->hasOne(VehicleColor::className(), ['name' => 'id']);
    }

    public function getPostrequestitem() {

        return $this->hasOne(PostRequestItems::className(), ['post_id' => 'id']);
    }

    public function getItemname()
    {
        return ItemType::find()->where(['item_type.is_delete' => INACTIVE, 'id'=>$this->postrequestitem->item_type_id])->one();
    }

    public function getItemsize()
    {
        return $this->hasOne(PostTripVehicle::className(), ['post_id' => 'id']);
    }

    public function getPosttripimageurl1() {
        $basePath = dirname(\yii\helpers\Url::base(true));
        $url=$basePath . '/media/post-trip/' . $this->itemsize->image_1;
        return '<img src="'.$url.'">';
    }

    public function getPosttripimageurl2() {
        $basePath = dirname(\yii\helpers\Url::base(true));
        $url=$basePath . '/media/post-trip/' . $this->itemsize->image_2;
        return '<img src="'.$url.'">';
    }

    public function getAllitemsize()
    {
        return ItemSize::find()->where(['item_size.is_delete' => INACTIVE, 'id'=>$this->postrequestitem->space_size_id])->one();
        
        //return $this->hasOne(PostTripVehicle::className(), ['post_id' => 'id']);
    }

    public function getPosttripvehicle() {

        return $this->hasOne(PostTripVehicle::className(), ['post_id' => 'id']);
    }

    public function getVehiclecolor()
    {
        return VehicleColor::find()->where(['vehicle_color.is_delete' => INACTIVE, 'id'=>$this->posttripvehicle->color])->one(); 
    }

    public function getVehicletype()
    {
        return VechicleType::find()->where(['vehicle_type.is_delete' => INACTIVE, 'id'=>$this->posttripvehicle->vehicle_type])->one();
    }
	public function getVehiclemodel()
    {
		
        return VehicleMakeModel::find()->where(['vehicle_make_model.is_delete' => INACTIVE, 'id'=>$this->posttripvehicle->model_id])->one();
    }
    public function getVehicleprice() {

        return $this->hasOne(PostOrder::className(), ['post_request_id' => 'id']);
    }
	 public function getQtyprice() {

        return $this->hasOne(PostTripAccept::className(), ['post_id' => 'id']);
    }

    public function getRequestItems($id)
    {
        $query = new Query;
        $query->select([
        'item_type.id as item_type_id',
        'item_type.name as item_type_name',
        'vehicle_spacesize.id as vehicle_spacesize_id',
        'vehicle_spacesize.name as vehicle_spacesize_name',
        'post_request_items.item_weight as post_request_items_item_weight',
        'post_request_items.image1 as post_request_items_image1', 
        'post_request_items.image2 as post_request_items_image2',
        'post_request_items.qty as post_request_items_qty'
        ])  
        ->from('post_request_items')->where(['post_request_items.post_id' => $id])
        
        ->join('LEFT OUTER JOIN', 'item_type',
                        'post_request_items.item_type_id = item_type.id')      
        ->join('LEFT OUTER JOIN', 'vehicle_spacesize', 
                        'post_request_items.space_size_id = vehicle_spacesize.id')
        ;
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }

    public function getTotalIncomeUserWise()
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT  SUM(price) as totalprice  FROM post p LEFT JOIN post_order po ON po.post_accept_id = p.id WHERE p.user_id = '" . Yii::$app->user->identity->id . "' AND p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' ");
        $totalincome = $command->queryAll();
        return $totalincome;
    }

    public function getTotalExpenseUserWise()
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT  SUM(price) as totalprice  FROM post p LEFT JOIN post_order po ON po.post_request_id = p.id WHERE p.user_id = '" . Yii::$app->user->identity->id . "' AND p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' ");
        $totalincome = $command->queryAll();
        return $totalincome;
    }

    public function getUpcommingTripDetails()
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT  po.traking_number,p.post_type,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_accept_id WHERE p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.order_status IN ('ACCEPT') ");
        $upcomingtripdetails = $command->queryAll();
        return $upcomingtripdetails;
    }

    public function getUpcommingRequestDetails()
    {
        $connection = Yii::$app->getDb();
        $command1 = $connection->createCommand("SELECT  po.traking_number,p.post_type,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_request_id WHERE p.post_type = 'REQUEST' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.order_status IN ('ACCEPT') ");
        $upcomingrequestdetails = $command1->queryAll();
        return $upcomingrequestdetails;
    }

    public function getOngoingTripDetails()
    {
        $connection = Yii::$app->getDb();
        $command2 = $connection->createCommand("SELECT  po.traking_number, p.post_type,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_accept_id WHERE p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.order_status IN ('IN_TRIP','DELIVERED','PAID','RATED') ");
        $ongoingtripdetails = $command2->queryAll();
        return $ongoingtripdetails;
    }

    public function getOngoingRequestDetails()
    {
        $connection = Yii::$app->getDb();
        $command3 = $connection->createCommand("SELECT po.traking_number, p.post_type,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_request_id WHERE p.post_type = 'REQUEST' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.order_status IN ('IN_TRIP','DELIVERED','PAID','RATED') ");
        $ongoingrequestdetails = $command3->queryAll();
        return $ongoingrequestdetails;
    }

    public function getAllMyTripDetails()
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT p.id, p.post_type, u.first_name, u.image, p.origin, p.destination, p.departure_date, po.order_status FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_accept_id WHERE p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' ORDER BY p.id DESC"); // AND p.order_status IN ('INITILISED')
        $upcomingtripdetails = $command->queryAll();
        return $upcomingtripdetails;
    }

    public function getAllMyRequestDetails()
    {
        $connection = Yii::$app->getDb();
        $command1 = $connection->createCommand("SELECT  p.id,p.post_type,u.first_name,u.image,p.origin,p.destination,p.departure_date, p.order_status FROM users u LEFT JOIN post p ON u.id = p.user_id WHERE p.post_type = 'REQUEST' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' ORDER BY p.id DESC"); //AND p.order_status IN ('INITILISED')
        $upcomingrequestdetails = $command1->queryAll();
        return $upcomingrequestdetails;
    }

    public function getHistoryTripDetail()
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT  p.post_type,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_accept_id WHERE p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.order_status IN ('DELIVERED','FINISHED') ");
        $historytripdetails = $command->queryAll();
        return $historytripdetails;
    }

    public function getHistoryRequestDetail()
    {
        $connection = Yii::$app->getDb();
        $command1 = $connection->createCommand("SELECT  p.post_type,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_request_id WHERE p.post_type = 'REQUEST' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.order_status IN ('DELIVERED','FINISHED') ");
        $historyrequestdetails = $command1->queryAll();
        return $historyrequestdetails;
    }

    public function getHistoryPaymentDetail()
    {
        $connection = Yii::$app->getDb();
        $command2 = $connection->createCommand("SELECT  p.post_type,po.price,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_accept_id WHERE p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.payment_status IN ('COMPLETED') ");
        $historypaymentdetails = $command2->queryAll();
        return $historypaymentdetails;
    }

    public function getHistoryEarningDetail()
    {
        $connection = Yii::$app->getDb();
        $command3 = $connection->createCommand("SELECT p.post_type,po.price,u.first_name,u.image,p.origin,p.destination,p.departure_date FROM users u LEFT JOIN post p ON u.id = p.user_id LEFT JOIN post_order po ON p.id = po.post_request_id WHERE p.post_type = 'REQUEST' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.user_id = '" . Yii::$app->user->identity->id . "' AND po.payment_status IN ('COMPLETED') ");
        $historyearningdetails = $command3->queryAll();
        return $historyearningdetails;
    }

    public function getDriverStatus($id)
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT  p.id as post_id,pt.year,pt.plate_number,po.order_status,pt.color,pt.size,u.first_name,u.id as user_id,u.image,po.traking_number,p.post_type,p.origin,p.destination,p.departure_date FROM post p LEFT JOIN post_order po ON p.id = po.post_accept_id LEFT JOIN users u ON p.user_id = u.id LEFT JOIN post_trip_vehicle pt ON pt.post_id = p.id WHERE p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND po.traking_number = '" . $id . "'");
        $driverstatus = $command->queryAll();
        return $driverstatus;
    }

    public function getTripDetails($id)
    {
        $connection = Yii::$app->getDb(); 

        $command1 = $connection->createCommand("
            SELECT  p.id as post_id,
            pt.item_weight,
            po.order_status,
            pt.description,
            u.first_name,
            u.id,
            u.image,
            po.traking_number,
            p.post_type,
            p.origin,
            p.destination,
            p.departure_date 
            FROM post p LEFT JOIN post_order po ON p.id = po.post_request_id 
            LEFT JOIN users u ON p.user_id = u.id 
            LEFT JOIN post_request_items pt ON pt.post_id = p.id 
            WHERE p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND po.traking_number = '" . $id . "'");
        $tripstatus = $command1->queryAll();
        return $tripstatus;
    }

    public function getViewTrip($id)
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT  p.id as post_id, pt.year, pt.space_available, pt.image_1, pt.plate_number, pt.color, pt.size, u.first_name, u.id as user_id, u.image, p.post_type, p.origin, p.destination,p.departure_date, vc.name as vehicle_color_name, vt.name as vehicle_name, vm.make_model_name FROM post p LEFT JOIN users u ON p.user_id = u.id LEFT JOIN post_trip_vehicle pt ON pt.post_id = p.id LEFT JOIN vehicle_color as vc ON vc.id=pt.color LEFT JOIN vehicle_type as vt ON vt.id=pt.vehicle_type LEFT JOIN vehicle_make_model as vm ON vm.id=pt.model_id WHERE p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "' AND p.id = '" . $id . "'");
        $driverstatus = $command->queryOne();
        return $driverstatus;
    }

    public function getViewRequest($id)
    {
        $query = new Query;
        $query->select(['p.id', 'p.post_type', 'p.origin', 'p.destination', 'p.departure_date', 'p.order_status',
        'item_type.id as item_type_id',
        'item_type.name as item_type_name',
        'vehicle_spacesize.id as vehicle_spacesize_id',
        'vehicle_spacesize.name as vehicle_spacesize_name',
        'post_request_items.id as pr_id','post_request_items.item_weight as post_request_items_item_weight',
        'post_request_items.image1 as post_request_items_image1', 
        'post_request_items.image2 as post_request_items_image2',
        'post_request_items.qty as post_request_items_qty',
        'post_request_items.description',
        'u.image', 'u.first_name'
        ])  
        ->from('post as p')->where(['p.id' => $id])
        ->join('LEFT OUTER JOIN', 'post_request_items',
                        'post_request_items.post_id = p.id')
        ->join('LEFT OUTER JOIN', 'item_type',
                        'post_request_items.item_type_id = item_type.id')
        ->join('LEFT OUTER JOIN', 'vehicle_spacesize', 
                        'post_request_items.space_size_id = vehicle_spacesize.id')
        ->join('LEFT OUTER JOIN', 'users as u',
                        'u.id = p.user_id')
        ;
        //echo $query->createCommand()->getRawSql();
        $command = $query->createCommand();
        $data = $command->queryAll();

        return $data;
    }

    public function getSearchData($field_lat, $field_long, $lat, $long, $post_type=''){
        $query = new Query();
        if(isset($post_type) && $post_type!=''){
            $query->select(['id,(3956 * 2 * ASIN(SQRT( POWER(SIN((' . $lat . ' - '.$field_lat.') *  PI()/180 / 2), 2) +COS(' . $lat . ' * PI()/180) * COS('.$field_lat.' * PI()/180) * POWER(SIN((' . $long . '- '.$field_long.') * PI()/180 / 2), 2) ))) as distance'])
                ->from('post')
                ->andWhere(['post_type' => $_POST['PostSearch']['post_type']])
                ->having('distance <= 5');
        }else{
            $query->select(['id,(3956 * 2 * ASIN(SQRT( POWER(SIN((' . $lat . ' - '.$field_lat.') *  PI()/180 / 2), 2) +COS(' . $lat . ' * PI()/180) * COS('.$field_lat.' * PI()/180) * POWER(SIN((' . $long . '- '.$field_long.') * PI()/180 / 2), 2) ))) as distance'])
                ->from('post')
                ->having('distance <= 5');
        }
        $data = $query->createCommand()->queryAll();
        //echo $query->createCommand()->getRawSql();die;
        return $data;
    }

    public function getLoadSearchData($field_lat, $field_long, $lat, $long, $post_type=''){
        $query = new Query();
        if(isset($post_type) && $post_type!=''){
            $query->select(['id,(3956 * 2 * ASIN(SQRT( POWER(SIN((' . $lat . ' - '.$field_lat.') *  PI()/180 / 2), 2) +COS(' . $lat . ' * PI()/180) * COS('.$field_lat.' * PI()/180) * POWER(SIN((' . $long . '- '.$field_long.') * PI()/180 / 2), 2) ))) as distance'])
                ->from('post')
                ->andWhere(['post_type' => $post_type])
                ->having('distance <= 5');
        }else{
            $query->select(['id,(3956 * 2 * ASIN(SQRT( POWER(SIN((' . $lat . ' - '.$field_lat.') *  PI()/180 / 2), 2) +COS(' . $lat . ' * PI()/180) * COS('.$field_lat.' * PI()/180) * POWER(SIN((' . $long . '- '.$field_long.') * PI()/180 / 2), 2) ))) as distance'])
                ->from('post')
                ->having('distance <= 5');
        }
        $data = $query->createCommand()->queryAll();
        //echo $query->createCommand()->getRawSql();die;
        return $data;
    }

    public function getSearchStatusDetails()
    {
        $connection = Yii::$app->getDb();
        $command = $connection->createCommand("SELECT p.id FROM post p INNER JOIN post_order po ON p.id = po.post_accept_id WHERE p.post_type = 'TRIP' AND p.is_active = '" . ACTIVE . "' AND p.is_delete = '" . NOT_DELETED . "'");
        $statusdetail = $command->queryAll();
        return $statusdetail;
    }

    public function sendRequestDeleteEmail($orderdetail,$title,$desc,$requestorderdetail) {

        $fromEmail = 'demo.xceltec4@gmail.com';
             
        $id = $requestorderdetail['user_id'];
        $user = User::findOne(['id' => $id]);
        
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'requestDeleteEmail-html'], 
                                [
                                    'user' => $user,
                                    'title'=>$title,
                                    'desc'=>$desc
                                ]
                        )
                        ->setFrom($fromEmail)
                        ->setTo($user->email)
                        ->setSubject('Request Deleted')
                        ->send();
    }

} 