<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\post;

use yii\base\Model;
use common\models\post\Post;

class PostForm extends Model {

    public $origin;
    public $destination;
    public $post_date;
    public $year;
    public $routes_via;
    public $user_id;
    public $post_type;
    public $created_by;
    public $created_date;
    public $is_active;
    public $is_delete;
    public $updated_by;
    public $updated_date;

    public function rules() {
            return [
            [['user_id', 'origin', 'destination', 'post_date', 'year', 'post_type', 'is_active', 'is_delete'], 'required'],
            [['user_id', 'year', 'created_by', 'updated_by'], 'integer'],
            [['post_date', 'departure_date', 'created_date', 'updated_date', 'created_by', 'created_date', 'updated_by', 'updated_date'], 'safe'],
            [['post_type', 'is_active', 'is_delete'], 'string'],
            [['origin', 'destination', 'routes_via'], 'string', 'max' => 250],
        ];
    }

    public function getUpdateModel($model) {
        $this->origin = $model->origin;
        $this->destination = $model->destination;
        $this->year = $model->year;
        $this->post_type = $model->post_type;
        $this->routes_via = $model->routes_via;
        return $this;
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'origin' => 'Origin',
            'destination' => 'Destination',
            'routes_via' => 'Via route ?',
            'post_date' => 'Select date',
            'departure_date' => 'Departure Date',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' => 'Ip Address',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
        ];
    }
}
