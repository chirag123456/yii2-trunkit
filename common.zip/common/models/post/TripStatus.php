<?php

namespace common\models\post;

use Yii;

/**
 * This is the model class for table "post_request_items".
 *
 * @property int $id
 * @property int $post_id
 * @property int $item_type_id
 * @property int $item_weight
 * @property string $description
 * @property string $image1
 * @property string $image2
 * @property int $space_size_id
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class TripStatus extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    
     //public $xlarge_item;
    
    public static function tableName() {
        return 'trip_status';
    }

    /**
     * @inheritdoc
     */
	 
    public function rules() {
        return [
           
            [['post_id', 'post_type', 'small_item','medium_item','large_item','xlarge_item', 'size'], 'safe'],
      
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'post_id' => 'Post ID',
            'post_type' => 'Post Type',
            'small_item' => 'Small Item',
			'medium_item' => 'Medium item',
			'large_item' => 'Large Item',
			'xlarge_item' => 'Extra Large Item'
            
        ];
    }
    
 

}
