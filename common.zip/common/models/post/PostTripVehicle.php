<?php

namespace common\models\post;

use Yii;

/**
 * This is the model class for table "post_trip_vehicle".
 *
 * @property int $id
 * @property int $post_id
 * @property int $model_id
 * @property int $vehicle_type
 * @property int $year
 * @property string $plate_number
 * @property int $color
 * @property string $size
 * @property string $image_1
 * @property string $image_2
 * @property string $image_3
 * @property string $payment_policy
 * @property string $cancellation_policy
 * @property int $updated_by
 * @property string $is_active
 * @property string $created_date
 * @property string $is_delete
 * @property string $updated_date
 * @property int $created_by
 */
class PostTripVehicle extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'post_trip_vehicle';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['post_id', 'model_id', 'vehicle_type', 'plate_number', 'color', 'image_1','image_2', 'payment_policy', 'cancellation_policy', 'updated_by', 'is_active', 'created_date', 'is_delete', 'updated_date', 'created_by'], 'required'],
            [['post_id', 'model_id', 'vehicle_type', 'year', 'color', 'updated_by', 'created_by'], 'integer'],
            [['payment_policy', 'cancellation_policy', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date', 'size', 'year','space_available'], 'safe'],
            [['plate_number', 'size'], 'string', 'max' => 50],
            [['image_1', 'image_2', 'image_3'], 'string', 'max' => 100]
            //['plate_number', 'match', 'pattern' => '/^[a-zA-Z0-9]+$/', 'message' => 'Plate Number can only contain alphanumeric characters.']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'post_id' => 'Post ID',
            'model_id' => 'Model ID',
            'vehicle_type' => 'Vehicle Type',
            'year' => 'Year',
            'plate_number' => 'Plate Number',
            'color' => 'Color',
            'size' => 'Size',
            'image_1' => 'Image 1',
            'image_2' => 'Image 2',
            'image_3' => 'Image 3',
            'payment_policy' => 'Payment Policy',
            'cancellation_policy' => 'Cancellation Policy',
            'updated_by' => 'Updated By',
            'is_active' => 'Is Active',
            'created_date' => 'Created Date',
            'is_delete' => 'Is Delete',
            'updated_date' => 'Updated Date',
            'created_by' => 'Created By',
        ];
    }

}
