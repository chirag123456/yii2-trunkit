<?php

namespace common\models\post;

use Yii;

/**
 * This is the model class for table "post_request_items".
 *
 * @property int $id
 * @property int $post_id
 * @property int $item_type_id
 * @property int $item_weight
 * @property string $description
 * @property string $image1
 * @property string $image2
 * @property int $space_size_id
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class PostRequestItems extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    
   
    
    public static function tableName() {

        return 'post_request_items';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['post_id', 'item_type_id', 'item_weight','qty', 'space_size_id'], 'required'],
            [['post_id', 'item_type_id', 'space_size_id', 'created_by', 'updated_by'], 'integer'],
            [['description', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date', 'image2', 'description','space_available_other','space_available'], 'safe'],
            [['image1', 'image2'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'post_id' => 'Post ID',
            'item_type_id' => 'Item Type ID',
            'item_weight' => 'Item Weight',
            'description' => 'Description',
            'qty' => 'Quantity',
            'space_available'=>'Space Available',
            'image1' => 'Image1',
            'image2' => 'Image2',
            'space_size_id' => 'Space Size ID',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }
    

    public function getPostdetail() {

        return $this->hasOne(Post::className(), ['id' => 'post_id']);
    }
 

}
