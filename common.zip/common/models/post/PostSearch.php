<?php

namespace common\models\post;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\post\Post;
use common\models\relation\TripRequestRelation;

/**
 * PostSearch represents the model behind the search form of `common\post\Post`.
 */
class PostSearch extends Post {

    public $user_name;
    public $image;
    public $latitude_orig;
    public $longitude_orig;
    public $latitude_dest;
    public $longitude_dest;

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['post_date', 'year', 'post_type', 'created_by', 'created_date', 'updated_by', 'updated_date', 'is_active', 'is_delete'], 'safe'],
            [['user_id', 'origin', 'destination', 'user_id', 'year', 'created_by', 'updated_by'], 'string'],
            [['post_date', 'image', 'created_date', 'updated_date','latitude_orig','longitude_orig','latitude_dest','longitude_dest'], 'safe'],
            [['post_type', 'is_active', 'is_delete'], 'string'],
            [['origin', 'destination', 'routes_via'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function searchtrip($params) {
        $query = Post::find()->joinWith('user','post')->where(['post.is_delete' => NOT_DELETED, 'post_type' => 'TRIP']);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => 10, //\backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),//$params['per-page'],
                'pageSizeLimit' => [1, 100],
            ],
            
        ]);


         $dataProvider->sort->attributes['user_id'] = [
            'asc' => ['first_name' => SORT_ASC],
            'desc' => ['first_name' => SORT_DESC],
        ];

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'first_name', $this->user_id]) 
                ->andFilterWhere(['like', 'origin', $this->origin])
                ->andFilterWhere(['like', 'destination', $this->destination])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

    public function searchtrip1($params) {
        $query = Post::find()->where(['is_delete' => NOT_DELETED, 'post_type' => 'TRIP'])->limit(5);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => false,
        ]);
		
		
        $this->load($params);
        if (!$this->validate()) {
            return $dataProvider;
        }
        return $dataProvider;
    }

    public function searchrequest($params) {
        $query = Post::find()->joinWith('user','post')->where(['post.is_delete' => NOT_DELETED, 'post_type' => 'REQUEST']);
		//$query = Post::find()->joinWith('user','post')->where(['post.is_delete' => NOT_DELETED, 'post_type' => 'TRIP']);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => 10, //\backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),//$params['per-page'],
                'pageSizeLimit' => [1, 100],
            ],
        ]);
		
		$dataProvider->sort->attributes['user_id'] = [
            'asc' => ['first_name' => SORT_ASC],
            'desc' => ['first_name' => SORT_DESC],
        ];

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'first_name', $this->user_id]) 
                ->andFilterWhere(['like', 'origin', $this->origin])
                ->andFilterWhere(['like', 'destination', $this->destination])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

       public function searchrequest1($params) {
        $query = TripRequestRelation::find()->limit(5);
        // $query = Post::find()->where(['is_delete' => NOT_DELETED, 'post_type' => 'REQUEST'])->limit(5);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
             'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => false,
        ]);
        
        $this->load($params);
        if (!$this->validate()) {
            return $dataProvider;
        }
        return $dataProvider;
    }
    
    public function search($params) {

        $query = Post::find()->where(['is_delete' => NOT_DELETED]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

        $query->andFilterWhere(['like', 'user_id', $this->user_id])
                ->andFilterWhere(['like', 'origin', $this->origin])
                ->andFilterWhere(['like', 'destination', $this->destination])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

}
