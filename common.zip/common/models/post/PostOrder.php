<?php

namespace common\models\post;

use Yii;
use common\models\user\User;

/**
 * This is the model class for table "post_order".
 *
 * @property int $id
 * @property int $user_id
 * @property int $post_request_id
 * @property int $post_accept_id
 * @property string $order_status
 * @property string $order_date
 * @property string $total_price
 * @property int $traking_number
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $is_active
 * @property string $is_delete
 */
class PostOrder extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'post_order';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['user_id', 'post_request_id', 'post_accept_id', 'traking_number', 'created_by', 'updated_by'], 'integer'],
            [['order_status', 'is_active', 'is_delete'], 'string'],
            [['order_date', 'created_date', 'updated_date', 'departure_date', 'total_price', 'price','add_tip', 'tax', 'discount', 'payment_status'], 'safe'],
            [['total_price', 'price', 'tax', 'discount'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'user_id' => 'User',
            'post_request_id' => 'Post Request',
            'post_accept_id' => 'Post Trip',
            'order_status' => 'Order Status',
            'order_date' => 'Order Date',
            'price' => 'Price',
            'tax' => 'Tax Price',
            'discount' => 'Discount Price',
            'total_price' => 'Total Price',
            'traking_number' => 'Traking Number',
            'payment_status' => 'Payment Status',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
            'departure_date' => 'Departure Date',
        ];
    }

    public function getUser() {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public function getItemSize() {
        return $this->hasMany(PostRequestItems::className(), ['post_id' => 'post_request_id'])->count();
    }

    public function getImageurl() {

        return Yii::$app->request->BaseUrl . '/uploads/users/' . $this->post->user->image;
    }

    public function getSpeaceSize() {
        return 0; //$this->hasOne(Post::className(), ['id' => 'post_request_id']);
    }

    public function getPost() {
        return $this->hasOne(Post::className(), ['id' => 'post_accept_id']);
    }

    public function getRequest() {
        return $this->hasOne(PostRequestItems::className(), ['id' => 'post_request_id']);
    }
    public function getRequest1() {
        return $this->hasOne(Post::className(), ['id' => 'post_request_id']);
    }

    public function getPostOrderData($tracking_num) {
        /*$data = PostOrder::find()
                    ->select('traking_number,price')
                    ->where(['is_delete' => NOT_DELETED])
                    ->where(['IN','traking_number', explode(',',$tracking_num)])
                    ->all();*/

        $query = new \yii\db\Query;;
        $query  ->select(['post_order.traking_number', 'post_order.price', 'users.id', 'users.first_name', 'users.last_name', 'users.email'])  
                ->from('post_order')
                ->join( 'INNER JOIN', 
                    'users',
                    'users.id =post_order.user_id'
                )
                ->where(['is_delete' => NOT_DELETED])
                ->where(['IN','traking_number', explode(',',$tracking_num)]); 
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }

    public function sendTripDeleteEmail($orderdetail,$title,$desc,$to = '') {
   
        $fromEmail = 'demo.xceltec4@gmail.com';
             
        //$id = $orderdetail['user_id'];
        $user = User::findOne(['id' => $to]);

        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'tripDeleteEmail-html'], 
                                [
                                    'user' => $user,
                                    'title'=>$title,
                                    'desc'=>$desc
                                ]
                        )
                        ->setFrom($fromEmail)
                        ->setTo($user->email)
                        ->setSubject('Trip Deleted')
                        ->send();
    }

    public function sendRequestDeleteEmail($orderdetail,$title,$desc,$to = '') {

        $fromEmail = 'demo.xceltec4@gmail.com';
        //$id = $orderdetail['user_id'];
        $user = User::findOne(['id' => $to]);
        
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'requestDeleteEmail-html'], 
                                [
                                    'user' => $user,
                                    'title'=>$title,
                                    'desc'=>$desc
                                ]
                        )
                        ->setFrom($fromEmail)
                        ->setTo($user->email)
                        ->setSubject('Request Deleted')
                        ->send();
    }
    public function getChatListUser($id){
        $row = Yii::$app->db->createCommand("SELECT a.user_id as user_id_1,b.user_id as user_id_2,c.user_id as user_id_3
            FROM post_order AS a 
            LEFT JOIN post AS b ON a.post_request_id=b.id
            LEFT JOIN post AS c ON a.post_accept_id=c.id
            WHERE (b.user_id='$id' OR c.user_id='$id') AND a.order_status='ACCEPT'
            GROUP BY 1,2,3")->queryAll();
        return $row;
    }
}
