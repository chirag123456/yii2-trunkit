<?php

namespace common\models\post;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\post\PostOrder;
use common\models\transaction\Transaction;
/**
 * PostOrderSearch represents the model behind the search form of `common\models\post\Post`.
 */
class PostOrderSearch extends PostOrder {

    public $origin;
    public $destination;
    public $sale_by_date;
    public $sale_by_month;
    public $sale_by_year;

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['destination', 'origin', 'post_request_id', 'post_accept_id', 'order_status', 'payment_status', 'order_date', 'total_price', 'price', 'tax', 'discount'], 'safe'],
            [['order_status', 'is_active', 'is_delete'], 'string'],
            [['user_id', 'post_request_id', 'post_accept_id', 'traking_number', 'order_date', 'created_date', 'updated_date', 'departure_date'], 'safe'],
            [['total_price', 'price', 'tax', 'discount'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {
        $query = PostOrder::find()->where(['is_delete' => NOT_DELETED]);
        //$query = PostOrder::find();
        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => 10, //\backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),//$params['per-page'],
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

          $query->andFilterWhere(['like', 'origin', $this->post_accept_id])
                ->andFilterWhere(['like', 'traking_number', $this->traking_number])
                ->andFilterWhere(['like', 'destination', $this->post_accept_id])
                ->andFilterWhere(['like', 'order_status', $this->order_status])
                ->andFilterWhere(['like', 'payment_status', $this->payment_status])
                ->andFilterWhere(['like', 'total_price', $this->total_price])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

    public function search1($params) {
        $query = PostOrder::find()->where(['is_delete' => NOT_DELETED])->limit(5);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'pagination' => false
        ]);


        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        return $dataProvider;
    }

    public function searchorder($params) {
        $order = $_GET['order'];

        //$query = PostOrder::find()->where(['is_delete' => NOT_DELETED]);

        if($order == 'daily'){
            $date =  Yii::$app->formatter->asDate('now', 'yyyy-MM-dd');
            $query = PostOrder::find()->where(['is_delete' => NOT_DELETED])->andWhere(['order_status' => 'FINISHED', 'order_date' => $date]);
        }elseif ($order == 'monthly') {
            $yourMonth = date('m');
            $data = PostOrder::find()->select('order_date')->where(['MONTH(order_date)'=> $yourMonth ])->orderBy(['order_date'=>SORT_DESC])->all();         
            $query = PostOrder::find()->where(['is_delete' => NOT_DELETED])->andWhere(['order_status' => 'FINISHED','order_date' => $data]);
        }elseif ($order == 'yearly') {
            $year =  date('Y');
            $data = PostOrder::find()->select('order_date')->where(['YEAR(order_date)'=> $year])->orderBy(['order_date'=>SORT_DESC])->all(); 
            $query = PostOrder::find()->where(['is_delete' => NOT_DELETED])->andWhere(['order_status' => 'FINISHED','order_date' => $data]);
        }else {
            $query = PostOrder::find()->where(['is_delete' => NOT_DELETED])->andWhere(['order_status' => 'FINISHED']);
        }
                
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => 10, //\backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),//$params['per-page'],
                'pageSizeLimit' => [1, 100],
            ],
            //'pagination' => false
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }
        return $dataProvider;
    }

    //Function to get Pending Payment in Backend
    public function searchpendingpay($params, $is_exported) {
        $query = Transaction::find()->where(['is_delete' => NOT_DELETED, 'transactions_history.is_exported' => $is_exported, 'payment_status' => 'Y', 'transaction_status' => 'Completed']);
        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => 10, //\backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),//$params['per-page'],
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

          $query->andFilterWhere(['like', 'origin', $this->post_accept_id])
                ->andFilterWhere(['like', 'traking_number', $this->traking_number])
                ->andFilterWhere(['like', 'destination', $this->post_accept_id])
                ->andFilterWhere(['like', 'order_status', $this->order_status])
                ->andFilterWhere(['like', 'payment_status', $this->payment_status])
                ->andFilterWhere(['like', 'total_price', $this->total_price])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

    //Function to get Pending Payment in Backend
    public function searchpendingpayment($params, $is_exported) {
        $postdata = $_POST;
        if(isset($postdata['PostOrderSearch']['transaction_datetime'])){
            if(isset($postdata['PostOrderSearch']['sale_by_date']) && $postdata['PostOrderSearch']['sale_by_date']!=''){
                    $sale_by_date = $postdata['PostOrderSearch']['sale_by_date'];
                    $sale_by_date_arr = explode(' ', $sale_by_date);
                    $from_date = $sale_by_date_arr[0].' 00:00:01';
                    $to_date = $sale_by_date_arr[2].' 23:59:59'; 
        
                    $where = [ 'between', 'transaction_datetime', $from_date, $to_date];
            } else if(isset($postdata['PostOrderSearch']['sale_by_month']) && $postdata['PostOrderSearch']['sale_by_month']!=''){
                $d = explode( '-',$postdata['PostOrderSearch']['sale_by_month'] );
                $m = [ 'January'=>'01','February'=>'02','March'=>'03','April'=>'04','May'=>'05',
                                'June'=>'06','July'=>'07','August'=>'08','September'=>'09','October'=>'10',
                                'November'=>'11','December'=>'12'];

                if( is_array($d) && COUNT($d) > 1 ){
                        $where = [ 'YEAR(transaction_datetime)' => $d[0] , 'MONTH(transaction_datetime)' => $d[1] ]; //$m[$d[1]]
                }else{
                        $where = [ '>', 'transaction_datetime', new Expression('DATE_SUB(NOW(), INTERVAL 1 YEAR)') ];
                }
            } else if(isset($postdata['PostOrderSearch']['sale_by_year']) && $postdata['PostOrderSearch']['sale_by_year']!=''){
                $year = $postdata['PostOrderSearch']['sale_by_year'];
                $where = [ 'YEAR(transaction_datetime)' => $year ];
            }
            $andWhere = [
                        'transactions_history.is_delete' => NOT_DELETED,
                        'transactions_history.is_active' => ACTIVE,
                        'transactions_history.is_exported' => $is_exported,
                        'transactions_history.payment_status' => 'Y',
                        'transactions_history.transaction_status' => 'Completed',
                    ];
            $query = Transaction::find()->where($where)->andWhere($andWhere);
            //echo $query->createCommand()->getRawSql(); exit();
        } else {
            $query = Transaction::find()->where(['is_delete' => NOT_DELETED, 'transactions_history.is_exported' => $is_exported, 'payment_status' => 'Y', 'transaction_status' => 'Completed']);
        }
        //$query = Transaction::find()->where(['is_delete' => NOT_DELETED, 'transactions_history.is_exported' => $is_exported, 'payment_status' => 'Y', 'transaction_status' => 'Completed']);
        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => 10, //\backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE'),//$params['per-page'],
                'pageSizeLimit' => [1, 100],
            ],
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'created_by' => $this->created_by,
            'created_date' => $this->created_date,
            'updated_by' => $this->updated_by,
            'updated_date' => $this->updated_date,
        ]);

          $query->andFilterWhere(['like', 'origin', $this->post_accept_id])
                ->andFilterWhere(['like', 'traking_number', $this->traking_number])
                ->andFilterWhere(['like', 'destination', $this->post_accept_id])
                ->andFilterWhere(['like', 'order_status', $this->order_status])
                ->andFilterWhere(['like', 'payment_status', $this->payment_status])
                ->andFilterWhere(['like', 'total_price', $this->total_price])
                ->andFilterWhere(['like', 'is_active', $this->is_active])
                ->andFilterWhere(['like', 'is_delete', $this->is_delete]);

        return $dataProvider;
    }

}
