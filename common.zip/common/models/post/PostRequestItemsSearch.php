<?php

namespace common\models\post;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\post\PostRequestItems;
use common\models\post\Post;

/**
 * UserSearch represents the model behind the search form about `common\models\User`.
 */
class PostRequestItemsSearch extends PostRequestItems {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['post_id', 'item_type_id', 'item_weight','space_available','qty', 'space_size_id'], 'safe'],
            [['post_id', 'item_type_id', 'space_size_id', 'created_by', 'updated_by'], 'integer'],
            [['description', 'is_active', 'is_delete'], 'string'],
            [['created_date', 'updated_date', 'image2', 'description','space_available_other'], 'safe'],
            [['image1', 'image2'], 'string', 'max' => 250],
        ];
    }


    public function attributeLabels() {
        return [
            'id' => 'ID',
            'post_id' => 'Post ID',
            'item_type_id' => 'Item Type ID',
            'item_weight' => 'Item Weight',
            'description' => 'Description',
            'qty' => 'Quantity',
            'space_available'=>'Space Available',
            'image1' => 'Image1',
            'image2' => 'Image2',
            'space_size_id' => 'Space Size ID',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'is_active' => 'Is Active',
            'is_delete' => 'Is Delete',
        ];
    }
    

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params) {

        $q1 = PostRequestItems::find()->select('post_id')->where(['is_delete' => NOT_DELETED]);
        //echo '<pre>';print_r($q1);die;
        $query = Post::find()->where(['is_delete' => NOT_DELETED])->andwhere(['id' => $q1])->limit(5);
      
      $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['created_date' => SORT_DESC]],
            'pagination' => false
        ]);


        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        return $dataProvider;

        }

}
