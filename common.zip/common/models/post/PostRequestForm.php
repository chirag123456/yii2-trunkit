<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\post;

use yii\base\Model;
use common\models\post\PostRequestItems;
use common\models\post\Post;

class PostRequestForm extends Model {

    public $origin;
    public $destination;
    public $post_date;
    public $year;
    public $routes_via;
    public $item_type_id;
    public $item_weight;
    public $space_size_id;
    public $description;
    public $post_id;
    public $image1_name1;
    public $image1_name2;
    public $image1_name3;
    public $image1_name4;
    public $image1_name5;
    public $image1_name6;
    public $user_id;
    public $post_type;
    public $departure_date;
    public $latitude_orig;
    public $longitude_orig;
    public $latitude_dest;
    public $longitude_dest;
	public $qty;
    public $item_type;
    public $space_available;
    public $space_available_other;


    public function rules() {
        return [
            [['origin', 'destination', 'post_date', 'post_type','post_id', 'item_weight', 
                 'space_available','space_size_id','routes_via'], 'required'],
            [[ 'description','image1_name1','image1_name2','image1_name3','image1_name4','image1_name5','image1_name6','latitude_orig','longitude_orig','latitude_dest','longitude_dest','qty','item_type', 'item_type_id', 'space_available_other'], 'safe'],
            [['user_id','qty', 'year', 'post_id', 'item_type_id', 'space_size_id', 'created_by', 'updated_by'], 'integer'],
            [['is_active', 'is_delete'], 'string'],
        ];
    }

    public function getUpdateModel($model) {
        $this->origin = $model->origin;
        $this->destination = $model->destination;
        $this->year = $model->year;
        $this->post_type = $model->post_type;
        $this->routes_via = $model->routes_via;
        $this->post_id = $model->post_id;
        $this->space_available = $model->space_availble;
        $this->space_available_other = $model->space_available_other;
        $this->item_type_id = $model->item_type_id;
	    $this->qty = $model->qty;
        $this->item_weight = $model->item_weight;
        $this->description = $model->description;
        $this->space_size_id = $model->space_size_id;
        $this->image1 = $model->image1;
        $this->image2 = $model->image2;
        return $this;
    }

    public function attributeLabels() {
        return [
            'origin' => 'Origin',
            'destination' => 'Destination',
            'routes_via' => 'Trip Via route',
            'post_date' => 'Select date',
            'item_type_id' => 'Item Type',
            'item_weight' => 'Item Weight (Lbs)',
            'description' => 'Item Description',
            'space_size_id' => 'Item Size',
            'space_available'=>'Space Available',
            'space_available_other' => 'space_available_other',
            'image1_name1' => 'Item 1 Image1',
            'image1_name2' => 'Item 1 Image2',
            'image1_name3' => 'Item 2 Image1',
            'image1_name4' => 'Item 2 Image2',
            'image1_name5' => 'Item 3 Image1',
            'image1_name6' => 'Item 3 Image2',
    
        ];
    }

}
