<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\post;

use yii\base\Model;
use common\models\post\PostRequestItems;
use common\models\post\Post;
use common\models\post\PostTripVehicle;

class PostTripForm extends Model {

    public $origin;
    public $destination;
    public $post_date;
    public $departure_date;
    public $year;
    public $routes_via;
    public $plate_number;
    public $vehicle_type;
    public $model;
    public $color;
    public $size;
    public $image1;
    public $image2;
    public $image3;
    public $description;
    public $payment_policy;
    public $cancellation_policy;
    public $small_item;
    public $medium_item;
    public $large_item;
    public $xlarge_item;
    public $two;
    public $small_item_check;
    public $medium_item_check;
    public $large_item_check;
    public $xlarge_item_check;
    public $two_check;
    public $latitude_orig;
    public $longitude_orig;
    public $latitude_dest;
    public $longitude_dest;
    public $xlarge_item_qty;
    public $large_item_qty;
    public $medium_item_qty;
    public $small_item_qty;
    public $two_qty;
    public $routes_via_lat,$routes_via_lat1,$routes_via_lat2,$routes_via_lat3,$routes_via_lat4;
    public $routes_via_long,$routes_via_long1,$routes_via_long2,$routes_via_long3,$routes_via_long4;
    public $space_available;
    public $small_item_suggested_price = 0,$medium_item_suggested_price,$large_item_suggested_price,$xlarge_item_suggested_price = 0, $insurance_check;
    //public $model_id;

    public function rules() {
        return [
            [['model', 'vehicle_type', 'origin', 'destination', 'plate_number', 'color',
             'plate_number', 'routes_via'], 'required'],
            [['small_item', 'xlarge_item', 'large_item', 'two', 'medium_item',
            'image3', 'is_active', 'is_delete', 'routes_via','latitude_orig','longitude_orig','latitude_dest','longitude_dest', 'size', 'year', 'departure_date'], 'safe'],
            [['small_item_check', 'xlarge_item_check', 'large_item_check', 'two_check', 'medium_item_check','xlarge_item_qty','large_item_qty','medium_item_qty','small_item_qty','two_qty','space_available', 'post_date',
            'cancellation_policy', 'payment_policy','description','image1', 'image2'], 'safe'],
            [['small_item', 'xlarge_item', 'large_item', 'two', 'medium_item'],  'number', 'numberPattern' => '/^\s*[-+]?[0-9]*[.,]?[0-9]+([eE][-+]?[0-9]+)?\s*$/'],
            [['xlarge_item_qty','large_item_qty','medium_item_qty','small_item_qty','two_qty'],'number'],
            //['plate_number', 'custom_plate_number_unique'],
//            [['xlarge_item_qty','xlarge_item'], 'required', 'when' => function($model) {
//                return $this->xlarge_item_check == 1;
//            }],
//            [['small_item_qty','small_item'], 'required', 'when' => function($model) {
//                return $model->small_item_check == 1;
//            }],
            [['routes_via_lat','routes_via_long','routes_via_lat1','routes_via_long1','routes_via_lat2','routes_via_long2','routes_via_lat3','routes_via_long3','routes_via_lat4','routes_via_long4','small_item_suggested_price','medium_item_suggested_price','large_item_suggested_price','xlarge_item_suggested_price'],'safe'],
            //['plate_number', 'match', 'pattern' => '/^[a-zA-Z0-9]+$/', 'message' => 'Plate Number can only contain alphanumeric characters.']
        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'origin' => 'Origin',
            'destination' => 'Destination',
            'routes_via' => 'Via route',
            'post_date' => 'Select date',
            'departure_date' => 'Departure Date',
            'post_id' => 'Enter Post Name',
            'item_type_id' => 'Enter Item Type',
            'item_weight' => 'Enter Item Weight',
            'description' => 'Enter Item Description',
            'space_size_id' => 'Enter Space Size',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' => 'Ip Address',
            'is_active' => 'Status',
            'is_delete' => 'Delete',
            'model' => 'Make',
            'routes_via' => 'Via Route'
        ];
    }

    /*public function custom_plate_number_unique($attribute, $params) {
        
        $details = PostTripVehicle::find()->where(['is_delete' => INACTIVE])->andWhere(['plate_number' => $this->plate_number])->one();
        if(isset($this->id) && $this->id!=''){
            $is_change = PostTripVehicle::find()->where(['plate_number' => $this->plate_number])->andWhere(['is_delete' => NOT_DELETED])->andWhere('id != ' .$this->id)->one();
            if(!empty($is_change)){
                $this->addError($attribute, PLATE_NO);    
            }
        }else{
            if(!empty($details)){
                $this->addError($attribute, PLATE_NO);
            }
        }
    }*/

}