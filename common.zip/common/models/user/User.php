<?php

namespace common\models\user;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use yii\db\Query;

/**
 * This is the model class for table "users".
 *
 * @property int $id
 * @property string $first_name
 * @property string $last_name
 * @property string $username
 * @property string $email
 * @property string $contact_number
 * @property string $date_of_birth
 * @property int $age
 * @property string $password
 * @property string $auth_key
 * @property string $password_reset_token
 * @property string $driver_licence_image_name
 * @property string $description
 * @property string $role
 * @property int $created_by
 * @property string $created_date
 * @property int $updated_by
 * @property string $updated_date
 * @property string $ip_address
 * @property string $is_active
 * @property string $is_delete
 * @property string $is_email_verify
 * @property string $is_phone_verify
 * @property string $is_approved
 * @property string $is_login
 * @property string $last_login
 * @property string $driver_licence2
 */
class User extends ActiveRecord implements IdentityInterface {

    /**
     * @inheritdoc
     */
    const USER_DELETED = 'Y';
    const STATUS_ACTIVE = 'Y';
    const NOT_DELETED = 'N';
    const ROLE_USER = 2;
    const ROLE_ADMIN = 1;

    public static function tableName() {
        return '{{%users}}';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['username', 'email', 'password'], 'required'],
            [['date_of_birth', 'created_date', 'updated_date','role', 'last_login', 'age', 'contact_number', 'date_of_birth','gender', 'insurance_number', 'is_driver_licence_approved', 'is_insurance_number_approved','driver_licence2'], 'safe'],
            [['age', 'created_by', 'updated_by'], 'integer'],
            [['ip_address', 'description', 'is_active', 'is_delete', 'is_email_verify', 'is_phone_verify', 'is_approved', 'is_login'], 'string'],
            [['first_name', 'last_name', 'email'], 'string', 'max' => 100],
            [['username', 'password', 'driver_licence','image'], 'string', 'max' => 255],
            [['contact_number'], 'string', 'max' => 20],
            [['auth_key'], 'string', 'max' => 32],
            [['ip_address'], 'string', 'max' => 50],

        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'username' => 'Username',
            'email' => 'Email',
            'contact_number' => 'Contact Number',
            'date_of_birth' => 'Date Of Birth',
            'age' => 'Age',
            'gender' => 'Gender',
            'password' => 'Password',
            'auth_key' => 'Auth Key',
            'driver_licence' => 'Driver Licence',
            'driver_licence_image_name' => 'Driver Licence Image Name1',
            'driver_licence2' => 'Driver Licence Image Name2',
            'image' => 'Driver Image',
            'description' => 'Description',
            'role' => 'Role',
            'created_by' => 'Created By',
            'created_date' => 'Created Date',
            'updated_by' => 'Updated By',
            'updated_date' => 'Updated Date',
            'ip_address' => 'Ip Address',
            'is_active' => 'Status',
            'is_delete' => 'Is Delete',
            'is_email_verify' => 'Is Email Verify',
            'is_phone_verify' => 'Is Phone Verify',
            'is_approved' => 'Is Approved',
            'is_login' => 'Is Login',
            'last_login' => 'Last Login',
        ];
    }

    public static function isUserAdmin($email) {
        if (static::findOne(['email' => $email, 'role' => [1]])) {

            return true;
        } else {

            return false;
        }
    }

    /**
     * @inheritdoc
     */
    public static function findIdentity($id) {
        return static::findOne(['id' => $id, 'is_active' => ACTIVE]);
    }
    
    public static function findByPasswordResetToken($token) {
        if (!static::isPasswordResetTokenValid($token)) {
            return null;
        }

        return static::findOne([
                    'password_reset_token' => $token,
                    'is_active' => self::STATUS_ACTIVE,
        ]);
    }

    /**
     * @inheritdoc
     */
    public static function findIdentityByAccessToken($token, $type = null) {
        throw new NotSupportedException('"findIdentityByAccessToken" is not implemented.');
    }

    public static function findByUsername($username) {

        return static::findOne(['email' => $username, 'is_active' => ACTIVE, 'is_delete' => INACTIVE]);
    }

    public static function findByAdmin($email) {

        if (static::find()->where(['email' => $email, 'is_active' => ACTIVE, 'role' => 1, 'is_delete' => INACTIVE])) {
            return true;
        } else {

            return false;
        }
    }

    public static function isPasswordResetTokenValid($token) {
        if (empty($token)) {
            return false;
        }
        $timestamp = (int) substr($token, strrpos($token, '_') + 1);

        $expire = Yii::$app->params['user.passwordResetTokenExpire'];
        return $timestamp + $expire >= time();
    }

    /**
     * @inheritdoc
     */
    public function getId() {
        return $this->getPrimaryKey();
    }

    /**
     * @inheritdoc
     */
    public function getAuthKey() {
        return $this->auth_key;
    }

    /**
     * @inheritdoc
     */
    public function validateAuthKey($authKey) {
        return $this->getAuthKey() === $authKey;
    }

    public static function getAreaName($id) {
        $Area = Area::find()->select('area')->where(['id' => $id])->one();

        if ($Area != null) {
            return $Area->area;
        } else {
            return 'No Data';
        }
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */
    public function validatePassword($password) {
        return Yii::$app->security->validatePassword($password, $this->password);
    }

    /**
     * Generates password hash from password and sets it to the model
     *
     * @param string $password
     */
    public function setPassword($password) {
        $this->password = Yii::$app->security->generatePasswordHash($password);
    }

    /**
     * Generates "remember me" authentication key
     */
    public function generateAuthKey() {
        $this->auth_key = Yii::$app->security->generateRandomString();
    }

    /**
     * Generates new password reset token
     */
    public function generatePasswordResetToken() {
        $this->password_reset_token = Yii::$app->security->generateRandomString() . '_' . time();
    }

    /**
     * Removes password reset token
     */
    public function removePasswordResetToken() {
        $this->password_reset_token = null;
    }

    public function getQueue() {
        return $this->hasMany(Queue::className(), ['res_id' => 'id']);
    }

    public function getOrder() {
        return $this->hasMany(Order::className(), ['res_id' => 'id']);
    }
	public function sendEmail1($user) {
			
        $from = 'demo.xceltec4@gmail.com'; //$this->getConfigureValueByKey('FROM_EMAIL');
        return \Yii::$app->mailer
                        ->compose(['html' => 'subadmin-html'], ['user' => $user])
                        ->setFrom($from)
                        ->setTo($user['email'])
                        ->setSubject('Trunkit | Super Admin Created Sub Admin successfully!')
                        ->send();
    }

}
