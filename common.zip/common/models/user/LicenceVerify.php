<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\user;

use Yii;
use yii\base\Model;
use common\models\user\User;

class LicenceVerify extends Model {

    public $driver_licence;
    public $new_driver_licence;
    private $_user;

    public function rules() {

        return [
            [['driver_licence', 'new_driver_licence'], 'required'],
            //['driver_licence', 'validatePhone'],
            ['new_driver_licence', 'custom_contact_unique'],
            //[['driver_licence','new_driver_licence'],'match','pattern'=>'/^([+]{0,1}?[0-9.-]+)$/'],
        ];
    }

    public function validatePhone($attribute, $params) {

        $user = User::find()->where(['id' => \Yii::$app->user->identity->id])->andWhere(['contact_number' => $this->contact_number])->one();

        if (!$user) {
            $this->addError($attribute, 'You have entered wrong phone number.');
        }
    } 

    public function custom_contact_unique($attribute, $params) {
        $check = User::find()->Where('id !=' . Yii::$app->user->identity->id)->andWhere(['is_delete' => NOT_DELETED])->all();
        foreach ($check as $c) {
            if ($c['driver_licence'] == $this->$attribute) {
                $this->addError($attribute, 'This Licence Number' . ALREADY);
            }
        }
    }

    protected function getUser($user_id) {

        if (!$user_id) {
            if ($this->_user === null) {
                $this->_user = User::findIdentity(\Yii::$app->user->identity->id);
            }
        } else {
            if ($this->_user === null) {
                $this->_user = User::findIdentity($user_id);
            }
        }
        return $this->_user;
    }

    public function attributeLabels() {
        return [
            'driver_licence' => 'Licence Number',
            'new_driver_licence' => 'New Licence Number',
        ];
    }

    public function sendEmail() { /* @var $user User */
        $user = User::findOne([
                    'is_active' => User::STATUS_ACTIVE,
                    'id' => Yii::$app->user->identity->id,
        ]);
        if (!$user) {
            return false;
        }
        if (!User::isPasswordResetTokenValid($user->password_reset_token)) {

            $user->generatePasswordResetToken();
            if (!$user->save()) {
                return false;
            }
        }
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'passwordResetToken-html', 'text' => 'passwordResetToken-text'], ['user' => $user]
                        )
                        ->setFrom('demo.xceltec@gmail.com')
                        ->setTo($this->email)
                        ->setSubject('Email Verified for ' . Yii::$app->name)
                        ->send();
    }

}
