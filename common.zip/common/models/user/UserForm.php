<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\user;

use Yii;
use yii\base\Model;
use common\models\user\User;
use common\models\siteconfiguration\SiteConfiguration;

class UserForm extends Model {

    //public $id;
    public $first_name;
    public $last_name;
    public $username;
    public $email;
    public $contact_number;
    public $date_of_birth;
    public $age;
    public $password;
    public $confirm_password;
    public $description;
    public $image;
    public $driver_licence;
    public $new_email;
    public $new_contact_number;
    public $gender;
    public $paypal_email_id;
    public $insurance_number;
    public $driver_licence2;
    public $is_driver_licence_approved;
    public $is_insurance_number_approved;
    public $notification_pref;


    public function rules() {

        return [
            [['first_name', 'last_name', 'email', 'password','confirm_password', 'contact_number', 'gender'], 'required'],
            [['image', 'contact_number', 'date_of_birth', 'age', 'description', 'new_contact_number', 'confirm_password', 'insurance_number', 'is_driver_licence_approved', 'is_insurance_number_approved', 'date_of_birth', 'description'], 'safe'],
            ['email', 'email', 'message' => 'Please enter valid email address'],
            [['last_name', 'date_of_birth', 'age',
            'description', 'gender','paypal_email_id', 'driver_licence','driver_licence2','notification_pref'], 'safe'],
            
            [['contact_number'], 'integer', 'message' => 'Phone Number Must be Numeric'],
            [['description'], 'string', 'max' => 500],
            [['age'], 'integer', 'message' => 'Age Must be Number'],
            [['password', 'confirm_password'], 'string', 'min' => 6],
            [['first_name', 'email'], 'string', 'max' => 50],
            [['contact_number'], 'string', 'max' => 12],
            ['contact_number','custom_contact_unique'],
            //['paypal_email_id','custom_paypal_unique'],
            ['driver_licence','custom_driver_licence_unique'],
            ['email','custom_email_unique'],
           // ['driver_licence', 'match', 'pattern' => '/^[a-zA-Z0-9]+$/', 'message' => 'Driver Licence can only contain alphanumeric characters.'],
            [['password', 'confirm_password'], 'string'],
            ['confirm_password', 'compare', 'compareAttribute' => 'password', 'message' => "Password and Confirm Password must be same."],
        ];
    }

    public function attributeLabels() {
        return [
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'username' => 'Username',
            'email' => 'Email Address',
            'contact_number' => 'Phone Number',
            'new_contact_number' => 'New Phone Number',
            'paypal_email_id' => 'PayPal Email Id',
            'date_of_birth' => 'Date of Birth',
            'age' => 'Age',
            'gender' => 'Gender',
            'password' => 'Password',
            'driver_licence' => 'Driver Licence',
            'description' => 'Description',
            'insurance_number' => 'Car Insurance Number Image',
            'notification_pref' => 'Notification Preferences'
        ];
    }

    public function custom_driver_licence_unique($attribute, $params) {
        if (isset(Yii::$app->user->identity->id) && !empty(Yii::$app->user->identity->id)) {

            $is_change = \common\models\user\User::find()->where(['driver_licence' => $this->driver_licence])->andWhere(['is_delete' => NOT_DELETED])->andWhere('id != ' . Yii::$app->user->identity->id)->one();

            if ($is_change) {
                $this->addError($attribute, LICENCE);
            }
        } else {
            $is_change = \common\models\user\User::find()->where(['driver_licence' => $this->driver_licence])->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($is_change) {
                $this->addError($attribute, LICENCE);
            }
        }
    }

    
    public function custom_email_unique($attribute, $params) {
        $check = false;

        if ((isset($_GET['id']) && !empty($_GET['id'])) || (isset(Yii::$app->user->identity->id) && !empty(Yii::$app->user->identity->id)) ) {
                if(isset($_GET['id']) && !empty($_GET['id']))
                {
                    $uid = $_GET['id'];
                }
                else
                {
                    $uid = Yii::$app->user->identity->id;
                }

            $check = User::find()->where(['id' => $uid])->one();
            if ($check) {
                $cmp = strcasecmp(trim($check->email), trim($this->$attribute));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = User::find()->where(['email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This Email'.ALREADY);
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = User::find()->where(['email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This Email'.ALREADY);
            }
        }
    }

    public function custom_contact_unique($attribute, $params) {
        $check = false;
        $haystack = $this->$attribute;
        $needle   = "+1";
        $str = substr($haystack, 0, 2);
     
        if($str!=$needle){
            $this->addError($attribute, PHONEPLUSONE);
        }else{
             if ((isset($_GET['id']) && !empty($_GET['id'])) || (isset(Yii::$app->user->identity->id) && !empty(Yii::$app->user->identity->id)) ) {
                if(isset($_GET['id']) && !empty($_GET['id']))
                    {
                        $uid = $_GET['id'];
                    }
                    else
                    {
                        $uid = Yii::$app->user->identity->id;
                    }
                $check = User::find()->where(['id' => $uid])->one();
                if ($check) {
                    $cmp = strcasecmp(trim($check->contact_number), trim($this->$attribute));
                    if ($cmp == 0) {
                        $check = true;
                    } else {
                        $check = User::find()->where(['contact_number' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();

                        
                            if ($check) {
                                $this->addError($attribute, 'This Phone number'.ALREADY);
                            } else {
                                    $check = true;
                            }
                    }
                }

            } else {
                $check = \common\models\user\User::find()->where(['contact_number' => $this->contact_number])->andWhere(['is_delete' => NOT_DELETED])->one();
                if ($check) {
                    $this->addError($attribute, PHONE);        
                }
            }   
        }
    } 

    public function custom_paypal_unique($attribute, $params) {
           
        if (isset(Yii::$app->user->identity->id) && !empty(Yii::$app->user->identity->id)) {

            $is_change = \common\models\user\User::find()->where(['paypal_email_id' => $this->paypal_email_id])->andWhere(['is_delete' => NOT_DELETED])->andWhere('id != ' . Yii::$app->user->identity->id)->one();
            if ($is_change) {
                $this->addError($attribute, PAYPAL);
            }
        } else {
            $is_change = \common\models\user\User::find()->where(['paypal_email_id' => $this->paypal_email_id])->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($is_change) {
                $this->addError($attribute, PAYPAL);
            }
        }
    }
    
    public function custom_username_unique($attribute, $params) {
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $is_change = \common\models\user\User::find()->where(['username' => $this->username])->andWhere(['is_delete' => NOT_DELETED])->andWhere('id != ' . $_GET['id'])->one();
            if ($is_change) {
                $this->addError($attribute, EMAIL);
            }
        } else {
            $is_change = \common\models\user\User::find()->where(['username' => $this->username])->andWhere(['is_delete' => NOT_DELETED])->one();
            if ($is_change) {
                $this->addError($attribute, EMAIL);
            }
        }
    }

    public function validatePassword($attribute, $params) {
        $user = $this->getUser($this->user_id);
        if (!$user || !$user->validatePassword($this->password)) {
            $this->addError($attribute, 'Incorrect password.');
        }
    }

    public function getUpdateModel($model) {

        $this->username = $model->username;
        $this->email = $model->email;
        $this->first_name = $model->first_name;
        $this->last_name = $model->last_name;
        $this->image = $model->image;
        $this->contact_number = $model->contact_number;
        $this->date_of_birth = $model->date_of_birth;
        $this->gender = $model->gender;
        $this->password = $model->password;
        $this->description = $model->description;
        $this->driver_licence = $model->driver_licence;
        $this->paypal_email_id = $model->paypal_email_id;
        $this->insurance_number = $model->insurance_number;
        $this->is_driver_licence_approved = $model->is_driver_licence_approved;
        $this->is_insurance_number_approved = $model->is_insurance_number_approved;
        $this->driver_licence2 = $model->driver_licence2;
        $this->notification_pref = $model->notification_pref;
        return $this;
    }
    
    public function getUpdateEmail($model) {
        $this->paypal_email_id = $model->paypal_email_id;
        return $this;
    }

    public function sendEmail() { /* @var $user User */
        $user = User::findOne([
                    'is_active' => User::STATUS_ACTIVE,
                    'id' => Yii::$app->user->identity->id,
        ]);
        if (!$user) {
            return false;
        }
        if (!User::isPasswordResetTokenValid($user->password_reset_token)) {

            $user->generatePasswordResetToken();
            if (!$user->save()) {
                return false;
            }
        }
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'passwordResetToken-html', 'text' => 'passwordResetToken-text'], ['user' => $user]
                        )
                        ->setFrom('demo.xceltec@gmail.com')
                        ->setTo($this->email)
                        ->setSubject('Email Verified for ' . Yii::$app->name)
                        ->send();
    }
	
	public function sendUserEmail($id) { 
  
        //$fromEmail = SiteConfiguration::getConfigureValueByKey('demo.xceltec4@gmail.com');
		$fromEmail = 'demo.xceltec4@gmail.com';
        $user = User::findOne(['id' => $id]);
        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'adduserEmailVerifyHtml'], ['user' => $user]
                        )
                        ->setFrom($fromEmail)
                        ->setTo($user->email)
                        ->setSubject('User Email Verification')
                        ->send();
    }

}
