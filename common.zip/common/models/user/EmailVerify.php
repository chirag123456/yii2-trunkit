<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\user;

use Yii;
use yii\base\Model;
use common\models\user\User;

class EmailVerify extends Model {

    public $old_email;
    public $new_email;
    public $email_verify;
    private $_user;

    public function rules() {

        return [
            [['old_email', 'new_email'], 'required','message' =>'Email cannot be black'],
            ['new_email', 'email', 'message' => 'Please enter valid email address'],
            ['email_verify', 'safe'],
            ['new_email', 'custom_email_unique'],
        ];
    }

    public function validatePhone($attribute, $params) {

        $user = User::find()->where(['id' => \Yii::$app->user->identity->id])->andWhere(['contact_number' => $this->contact_number])->one();

        if (!$user) {
            $this->addError($attribute, 'You have entered wrong phone number.');
        }
    }

    public function custom_email_unique($attribute, $params) {
        $check = User::find()->Where('id !=' . Yii::$app->user->identity->id)->andWhere(['is_delete' => NOT_DELETED])->all();
        foreach ($check as $c) {
            if ($c['email'] == $this->$attribute) {
                $this->addError($attribute, 'This Email ID' . ALREADY);
            }
        }
    }

    public function custom_contact_unique($attribute, $params) {
        $check = User::find()->where(['contact_number' => trim($this->$attribute)])
                        ->andWhere(['is_delete' => NOT_DELETED])->one();

        if ($check) {
            $this->addError($attribute, 'This Contact Number' . ALREADY);
        }
    }

    protected function getUser($user_id) {

        if (!$user_id) {
            if ($this->_user === null) {
                $this->_user = User::findIdentity(\Yii::$app->user->identity->id);
            }
        } else {
            if ($this->_user === null) {
                $this->_user = User::findIdentity($user_id);
            }
        }
        return $this->_user;
    }

    public function attributeLabels() {
        return [
            'new_email' => 'New Email',
            'old_email' => 'Old Email',
        ];
    }

    public function sendEmail() { /* @var $user User */
        $user = User::findOne([
                    'is_active' => User::STATUS_ACTIVE,
                    'id' => Yii::$app->user->identity->id,
        ]);

        if (!$user) {
            return false;
        }

        return Yii::$app
                        ->mailer
                        ->compose(
                                ['html' => 'emailVerifyHtml'], ['user' => $user]
                        )
                        ->setFrom('demo.xceltec1@gmail.com')
                        ->setTo($this->new_email)
                        ->setSubject('Email Verified for ' . Yii::$app->name)
                        ->send();
    }

}
