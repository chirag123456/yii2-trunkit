<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\user;

use Yii;
use yii\base\Model;
use common\models\user\User;

class OtpVerify extends Model {

    public $otp;


    public function rules() {

        return [
            [['opt'], 'required'],
        ];
    }

    public function attributeLabels() {
        return [
            'otp' => 'OTP',
        ];
    }

}
