<?php

namespace common\models\user;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\user\User;

/**
 * UserSearch represents the model behind the search form about `common\models\User`.
 */
class UserSearch extends User {

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
//            [[ 'email'], 'required'],
            [['date_of_birth', 'created_date', 'updated_date', 'last_login'], 'safe'],
            [['age', 'created_by', 'updated_by'], 'integer'],
            [['description', 'is_active', 'is_delete', 'is_email_verify', 'is_phone_verify', 'is_approved', 'is_login'], 'string'],
            [['first_name', 'last_name', 'email', 'driver_licence'], 'string', 'max' => 100],
            [['username', 'password', 'driver_licence','image'], 'string', 'max' => 255],
            [['contact_number', 'role'], 'string', 'max' => 20],
            [['auth_key'], 'string', 'max' => 32],
            [['ip_address'], 'string', 'max' => 50],
        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email Address',
            'contact_number' => 'Contact No',
            'date_of_birth' => 'date_of_birth',
            'age' => 'age',
            'password' => 'Password',
            'auth_key' => 'Auth Key',
            'password_reset_token' => 'Password Reset Token',
            'driver_license_image_url' => 'Driver License image',
            'driver_licence_image_name' => 'driver_licence_image_name',
            'description' => 'Description',
            'role' => 'Role',
            'is_email_verify' => 'Status',
            'is_phone_verify' => 'Status',
            'is_active' => 'Is Active',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios() {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params, $role) {
        $query = User::find()->where(['is_delete' => NOT_DELETED, 'role' => $role]);
       // ->andWhere('id !=' . Yii::$app->user->identity->id)

        $settings = \common\models\Settings::find()->one();

        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => [
                'defaultPageSize' => $pagesize,
                'pageSizeLimit' => [1, 100],
            ],
        ]);
        $this->load($params);

        if (!$this->validate()) {
           
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere(['like', 'username', $this->username])
                ->andFilterWhere(['like', 'email', $this->email])
                ->andFilterWhere(['like', 'first_name', $this->first_name])
                ->andFilterWhere(['like', 'last_name', $this->last_name])
                ->andFilterWhere(['like', 'contact_number', $this->contact_number])

                ->andFilterWhere(['like', 'is_active', $this->is_active]);

        return $dataProvider;
    }

    public function search1($params, $role) {
        $query = User::find()->where(['is_delete' => NOT_DELETED, 'role' => $role])->andWhere('id !=' . Yii::$app->user->identity->id)->limit(5);
         
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => ['defaultOrder' => ['id' => SORT_DESC]],
            'pagination' => false

        ]);

        $this->load($params);

        if (!$this->validate()) {
            return $dataProvider;
        }
        return $dataProvider;
    }

}
