<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\state;

use yii\base\Model;
use common\models\state\State;

class StateForm extends Model {

    public $state_name;
    public $country_id;

    public function rules() {

        return [
            [['country_id', 'state_name'], 'required'],
            [['state_name'], 'string'],
            ['state_name', 'custom_state_unique'],
            [['state_name', 'country_id'], 'custom_state_unique'],
        ];
    }

    public function attributeLabels() {
        return [
            'id' => 'ID',
            'state_name' => 'State',
            'country_id' => 'Country',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'is_delete' => 'Is Deleted',
        ];
    }

    public function getUpdateModel($model) {
        $this->country_id = $model->country_id;
        $this->state_name = isset($model->state_name) ? $model->state_name : '';

        return $this;
    }

    /*
     * custom_state_unique()
     * @@state name can be unique 
     */

    public function custom_state_unique($attribute, $params) {
        $check = false;
        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $check = State::find()->where(['id' => $_GET['id']])->one();
            if ($check) {
                $cmp = strcasecmp(trim($check->state_name), trim($this->$attribute));
                if ($cmp == 0) {
                    $check = true;
                } else {
                    $check = State::find()->where(['state_name' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED])->one();
                    if ($check) {
                        $this->addError($attribute, 'This state has already been taken.');
                    } else {
                        $check = true;
                    }
                }
            }
        } else {
            $check = State::find()->where(['state_name' => trim($this->$attribute)])->
                            andWhere(['country_id' => $_POST['StateForm']['country_id']])->
                            andWhere(['is_delete' => NOT_DELETED])->one();
            if ($check) {
                $this->addError($attribute, 'This state has already been taken.');
            }
        }
    }

}
