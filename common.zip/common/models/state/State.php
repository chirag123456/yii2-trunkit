<?php

namespace common\models\state;

use Yii;
use common\models\country\Country;
use common\models\user\User;

/**
 * This is the model class for table "state".
 *
 * @property integer $id
 * @property string $state_name
 * @property integer $country_id
 * @property string $is_active
 * @property integer $created_by
 * @property integer $updated_by
 * @property integer $date_created
 * @property integer $date_updated
 * @property string $is_deleted
 *
 * @property City[] $cities
 * @property Country $country
 * @property User $createdBy
 * @property User $updatedBy
 * @property User[] $users
 */
class State extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'state';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['state_name', 'country_id', 'is_active', 'created_by', 'updated_by',  'is_delete'], 'required'],
            [['country_id', 'created_by', 'updated_by'], 'integer'],
            [['is_active', 'is_delete'], 'string'],
            [['state_name'], 'string'],
            [[ 'created_date', 'updated_date'], 'safe'],
            [['country_id'], 'exist', 'skipOnError' => true, 'targetClass' => Country::className(), 'targetAttribute' => ['country_id' => 'id']],
            [['created_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['created_by' => 'id']],
            [['updated_by'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['updated_by' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'state_name' => 'State',
            'country_id' => 'Country',
            'is_active' => 'Status',
            'created_by' => 'Created By',
            'updated_by' => 'Updated By',
            'created_date' => 'Date Created',
            'updated_date' => 'Date Updated',
            'is_delete' => 'Is Delete',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCities()
    {
        return $this->hasMany(City::className(), ['state_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCountry()
    {
        return $this->hasOne(Country::className(), ['id' => 'country_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'created_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUpdatedBy()
    {
        return $this->hasOne(User::className(), ['id' => 'updated_by']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUsers()
    {
        return $this->hasMany(User::className(), ['state_id' => 'id']);
    }
}
