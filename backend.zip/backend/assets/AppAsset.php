<?php

namespace backend\assets;

use yii\web\AssetBundle;

/**
 * Main backend application asset bundle.
 */
class AppAsset extends AssetBundle {

    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/site.css',
        //'bootstrap/css/bootstrap.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css',
        'https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css',
         'plugins/datatables/dataTables.bootstrap.css', 
        'dist/css/AdminLTE.min.css',
        'dist/css/skins/_all-skins.min.css',
        'plugins/iCheck/flat/blue.css',       
		'plugins/timepicker/bootstrap-timepicker.min.css',
        'css/cropping/style-example.css',
        'css/cropping/jquery.Jcrop.css',
        'css/custom.css',
		'css/developer.css',
		'css/developer_media.css',            
    ];
    public $js = [     
        'plugins/datatables/jquery.dataTables.min.js',
        'plugins/datatables/dataTables.bootstrap.min.js',     
        'plugins/datepicker/bootstrap-datepicker.js',
	'plugins/timepicker/bootstrap-timepicker.min.js',        
        'dist/js/app.min.js',        
        'dist/js/demo.js',
        'js/custom.js',
        'js/cropping/jquery.Jcrop.js',
        'js/cropping/jquery.SimpleCropper.js',            
    ];
    public $depends = [
        'yii\web\YiiAsset',
        'yii\bootstrap\BootstrapAsset',
        'yii\bootstrap\BootstrapPluginAsset',
    ];

}
