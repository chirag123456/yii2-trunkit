<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\homeimage\Homeimage;
use common\models\homeimage\HomeimageForm;
use common\models\homeimage\HomeimageSearch;
use backend\components\CustController;

/**
 * Description of HomeimageController
 *
 * @author xceltec35
 */

class Homeimage1Controller extends CustController  {
    function actionIndex(){        	
        $searchModel = new HomeimageSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);        
	    return $this->render('index', [
				'searchModel' => $searchModel,
				'dataProvider' => $dataProvider,
	    ]);
    }
    function actionAdd(){
        
        $model = new \common\models\homeimage\HomeimageForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {            
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }        
        
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {            
            $errors = ActiveForm::validate($model);
                $homeimage = new Homeimage();
                $homeimage->attributes = $model->attributes;
                $homeimage->name=$model->name;
                $homeimage->image_name=$this->base64_to_image($model->image_name,'');
                $homeimage->created_by = Yii::$app->user->identity->id;
                $homeimage->updated_by = Yii::$app->user->identity->id;
                $homeimage->created_date = date("Y-m-d H:i:s");
                $homeimage->updated_date = date("Y-m-d H:i:s");
                $homeimage->is_active = ACTIVE;
                $homeimage->is_delete = NOT_DELETED;
                if ($homeimage->validate()) {
                    $homeimage->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Image' . ADDED,
                        'title' => 'City Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['homeimage/index']);
                } else {
                     Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['homeimage/index']);
                }            
        }
        
        return $this->render('create', [
                    'model' => $model
        ]);
    }
    function actionUpdate($id){
                $details = Homeimage::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($details == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['homeimage/index']);
        }
        $model = new HomeimageForm();
        $model->attributes = $details->attributes;
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if ($model->load(Yii::$app->request->post())) {            
            $homeimage = Homeimage::findOne(['id' => $id]);
            $homeimage->attributes = $model->attributes;
            $homeimage->name=$model->name;
            if (empty($model->image_name)) {
                $homeimage->image_name = $details->image_name;
            } else {
                    $basePath = dirname(\Yii::$app->basePath);      
                    $file = $basePath.DIRECTORY_SEPARATOR.'media'.DIRECTORY_SEPARATOR.'home_image'.DIRECTORY_SEPARATOR.$details->image_name;
                if(file_exists($file)){
                    unlink($file);
                }
                $homeimage->image_name = $this->base64_to_image($homeimage->image_name,'');
            }

            $homeimage->updated_by = Yii::$app->user->identity->id;
            $homeimage->updated_date = date("Y-m-d H:i:s");           
            if ($homeimage->validate()) {
                if ($homeimage->save()) {
                   
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User' . UPDATED,
                        'title' => 'User Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['homeimage/index']);
        }

        return $this->render('edit-image1', [
                    'model' => $model,
        ]);
        
    }
    public function actionStatus($id) {
        
        $model = Homeimage::findOne($id);

        if (isset($_REQUEST['status']) && $_REQUEST['status'] == "Y") {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'User' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else if (isset($_REQUEST['status']) && $_REQUEST['status'] == "N") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'User' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else if (isset($_REQUEST['status']) && $_REQUEST['status'] == "P") {
            $model->is_active = PENDING;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'User' . PENDINGDONE,
                'title' => 'Pending Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {

            if ($model->is_active == "Y") {
                $model->is_active = INACTIVE;
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'User' . DEACTIVATED,
                    'title' => 'Inactive Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            } else {
                $model->is_active = ACTIVE;
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'User' . ACTIVATED,
                    'title' => 'Inactive Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['homeimage/index']));
    }
    function actionDelete($id){
       if ($id) {
            $model = Homeimage::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                if($model->save(false)){
                
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User' . DELETEDMESSAGE,
                        'title' => 'Active Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }else{
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Active Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            }
            return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['homeimage/index']));
        }
    }
    public function base64_to_image($imageData, $type) {
        $basePath = dirname(\Yii::$app->basePath);      
        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid().'.'.$image_type;
        $file = $basePath.DIRECTORY_SEPARATOR.'media'.DIRECTORY_SEPARATOR.'home_image'.DIRECTORY_SEPARATOR.$imagename;
        file_put_contents($file, $image_base64);
        return $imagename;
    }
}