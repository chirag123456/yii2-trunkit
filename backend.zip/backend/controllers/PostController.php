<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use common\models\post\PostSearch;
use yii\bootstrap\ActiveForm;
use backend\components\CustController;
use common\models\post\PostOrderSearch;
use common\models\post\Post;

/**
 * CityController
 *  This controller used for City list , add , update , delete.
 * @author Trunkit
 * @since Jun,2017
 */
class PostController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionPostTrip() {
        $searchModel = new PostSearch();
        $dataProvider = $searchModel->searchtrip(Yii::$app->request->queryParams);

        return $this->render('post-trip', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    public function actionPostRequest() {
        $searchModel = new PostSearch();
        $dataProvider = $searchModel->searchrequest(Yii::$app->request->queryParams);

        return $this->render('post-request', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }
    
    /**
     * Status Action
     *  In this action use for change Status for City.
     * $id is City id
     * @return mixed
     */
    public function actionStatus($id) {
        $model = City::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'City' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'City' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['city/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete City data.
     * $id is City id
     * @return
     */
    public function actionDelete($id) {
        if ($id) {
            $model = City::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'City' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['city/index']));
            }
        }
    }

    /**
     * SetAction Action
     * @dependent drop down for city _form
     * @return
     */
    public function actionSetAction($id) {
        if (Yii::$app->request->isAjax) {
            $model = \common\models\state\State::find()->where(['country_id' => $id])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['is_active' => ACTIVE])->all();

            $modelcount = count((array) $model);
            if ($modelcount > 0) {
                echo "<option>Please select state</option>";
                foreach ($model as $action) {

                    echo "<option value='" . $action->id . "'>" . $action->state_name . "</option>";
                }
            } else {
                echo "<option>Please insert state</option>";
            }
        }
        return false;
    }

    /**
     * SetCity Action
     * @dependent drop down for user _form
     * $id is state id
     * @return
     */
    public function actionSetCity($id) {
        if (Yii::$app->request->isAjax) {

            $model = \common\models\city\City::find()->where(['state_id' => $id])->andWhere(['is_delete' => NOT_DELETED, 'is_active' => ACTIVE])->orderBy(['id' => SORT_DESC])->all();

            $modelcount = count((array) $model);

            if ($modelcount > 0) {

                echo "<option>Please Select City</option>";
                foreach ($model as $action) {

                    echo "<option value='" . $action->id . "'>" . $action->name . "</option>";
                }
            } else {
                echo "<option>Please Select State</option>";
            }
        }
        return false;
    }
    
    public function actionViewTrip($id) {

        //$model = Post::find()->where(['post.is_delete' => INACTIVE])->joinWith('vehicletype')->andWhere('post.id = ' . $id)->one();
        $model = Post::find()->where(['post.is_delete' => INACTIVE])->andWhere('post.id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['order/post-trip']);
        }

        return $this->render('view-trip', ['model' => $model]);
    }
    
    public function actionViewRequest($id) {

        $model = Post::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['order/post-trip']);
        }
        $requestItems = Post::getRequestItems($id);

        return $this->render('view-request', ['model' => $model,'request' => $requestItems]);
    }

	public function actionGetTripDetails() {
		
        if (isset($_POST['ride_giver_id'])) {
           
            $passenger = Post::find()->where(['id' => $_POST['ride_giver_id']])->one();			
            //print_r($_POST['ride_giver_id']); exit();
            $first_ele = [0 => [$passenger->origin, $passenger->origin_lat, $passenger->origin_long]];

            $last_ele = [0 => [$passenger->destination, $passenger->destination_lat, $passenger->destination_long]];           
            
            $lat_log = array_merge($first_ele, $last_ele);  
            
            if (isset($passenger) && !empty($passenger)) {
                $data = [
                    'order' => [
                        'ride_giver_id' => $passenger->id,                     
                        'lat' => $passenger->origin_lat,
                        'long' => $passenger->origin_long,
                        'icon' => \yii\helpers\Url::base(true) . '/web/images/source.png',
                        'lat_log' => $lat_log,  
                    ]
                ];
			
                return \yii\helpers\Json::encode($data); 
            } else {
                return false;
            }
        }
    }
}
