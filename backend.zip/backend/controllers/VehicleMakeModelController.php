<?php

namespace backend\controllers;

use Yii;
use backend\components\CustController;
use common\models\vehiclemakemodel\VehicleMakeModel;
use yii\web\Response;
use yii\widgets\ActiveForm;
use common\models\vehiclemakemodel\VehicleMakeModelForm;
use common\models\vehiclemakemodel\VehicleMakeModelSearch;

/**
 * StateController implements the CRUD actions for State model.
 */
class VehicleMakeModelController extends CustController {

   /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new VehicleMakeModelSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $model = new VehicleMakeModelForm();

        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $details = VehicleMakeModel::findOne(['id' => $_GET['id'], 'is_delete' => INACTIVE]);

            if ($details != null) {
                $model = new VehicleMakeModelForm();
                $model->attributes = $details->attributes;
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Something Error : Invalid data!',
                    'title' => 'Something Error : Invalid data!',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['vehicle-make-model/index']);
            }
        }
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model,
        ]);
    }
 /**
     * Add Action
     *  In this action use for Add the new data.
     * @return mixed
     */
    public function actionAdd() {

        $model = new VehicleMakeModelForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $make_model_name = new VehicleMakeModel();
            $make_model_name->attributes = $model->attributes;

            $make_model_name->make_model_name = $model->make_model_name;
            $make_model_name->parent_id = 0;
            $make_model_name->created_by = Yii::$app->user->identity->id;
            $make_model_name->updated_by = Yii::$app->user->identity->id;
            $make_model_name->created_date = date("Y-m-d H:i:s");
            $make_model_name->updated_date = date("Y-m-d H:i:s");
            $make_model_name->is_active = ACTIVE;
            $make_model_name->is_delete = NOT_DELETED;
           
            $make_model_name->ip_address = $_SERVER['REMOTE_ADDR'];

            if ($make_model_name->validate()) {
                if ($make_model_name->save()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Vehicle Make Model' . ADDED,
                        'title' => 'Vehicle Make Model Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }

            return $this->redirect(['vehicle-make-model/index']);
        }
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model
        ]);
    }
/**
     * Update Action
     *  In this action use for update the data.
     * @return mixed
     */
    public function actionUpdate($id) {

        $model = new VehicleMakeModelForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $make_model_name = VehicleMakeModel::find()->where(['id' => $_GET['id']])->one();

            $make_model_name->make_model_name = trim($model->make_model_name);
            $make_model_name->parent_id = 0;
            $make_model_name->created_by = Yii::$app->user->identity->id;
            $make_model_name->updated_by = Yii::$app->user->identity->id;
            $make_model_name->created_date = date("Y-m-d H:i:s");
            $make_model_name->updated_date = date("Y-m-d H:i:s");
            $make_model_name->is_active = ACTIVE;
            $make_model_name->is_delete = NOT_DELETED;
            
            $make_model_name->ip_address = $_SERVER['REMOTE_ADDR'];
            if ($make_model_name->validate()) {
                if ($make_model_name->save()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Vehicle Make Model' . UPDATED,
                        'title' => 'Vehicle Location Update',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
        }

        return $this->redirect(['vehicle-make-model/index']);
    }
 /**
     * Status Action
     *  In this action use for change the status.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = VehicleMakeModel::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Vehicle Make Model' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Vehicle Make Model' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    }
/**
     * Delete Action
     *  In this action use for Delete the data.
     * @return mixed
     */
    public function actionDelete($id) {
        if ($id) {
            $model = VehicleMakeModel::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Vehicle Make Model' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }
}
