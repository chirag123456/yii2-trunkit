<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\post\PostOrder;
use common\models\post\PostOrderSearch;
use backend\components\CustController;
use common\models\post\Post;
/**
 * StateController implements the CRUD actions for State model.
 */
class StatisticsController extends CustController {
  /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {

        $searchModel = new PostOrderSearch();
        $dataProvider = $searchModel->searchorder(Yii::$app->request->queryParams);

        return $this->render('index', ['dataProvider' => $dataProvider]);
         
        }

}
