<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\notification\Notification;
use common\models\notification\NotificationSearch;
//use common\models\RolePermission;
use backend\components\CustController;
//use yii\helpers\Inflector;
/**
 * AreaController
 *  This controller used for Area list , add , update , delete.
 * @author Trunkit
 * @since Jun,2017
 */
class NotificationController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
		
        $searchModel = new NotificationSearch();
        
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);
        
        return $this->render('index', [
                        'searchModel' => $searchModel,
                        'dataProvider' => $dataProvider,
        ]);
        
    }
	
    /**
     * Add Action
     *  In this action use for Add new data in Area.
     * @return
     */
    public function actionAdd() {
		
        $model = new \common\models\notification\NotificationForm();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
      
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $notification = new Notification();
                $notification->attributes = $model->attributes;
        
                $notification->title = trim($model->title);
                $notification->description = $model->description;
                $notification->created_by = Yii::$app->user->identity->id;
                $notification->updated_by = Yii::$app->user->identity->id;
                $notification->created_date = date("Y-m-d H:i:s");
                $notification->updated_date = date("Y-m-d H:i:s");
                $notification->is_active = ACTIVE;
                $notification->is_delete = NOT_DELETED;
	
                if ($notification->validate()) {
                    $notification->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Notification' . ADDED,
                        'title' => 'Notification Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['notification/index']);
                } else {
                    print_r($notification->getErrors());
                    die;
                }
            }
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }

    /**
     * Update Action
     *  In this action use for update Area.
     * $id is Area id
     * @return mixed
     */
    public function actionUpdate($id) {
	
        $details = Notification::find()->where(['is_delete'=>INACTIVE] )->andWhere('id = '.$id)->one();        
       
       if($details == NULL){
              Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                  // 'icon' => 'glyphicon glyphicon-remove-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]); 
              return $this->redirect(['notification/index']);
        }
        $NotificationForm = new \common\models\notification\NotificationForm();
        $model = $NotificationForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $notification = Notification::find()->where(['id' => $details->id])->one();

                $connection = Yii::$app->db;
                $transaction = $connection->beginTransaction();

                $notification->attributes = $model->attributes;
                $notification->title = trim($model->title);
                $notification->description = $model->description;
                $notification->created_by = Yii::$app->user->identity->id;
                $notification->updated_by = Yii::$app->user->identity->id;
                $notification->created_date = date("Y-m-d H:i:s");
                $notification->updated_date = date("Y-m-d H:i:s");

                if ($notification->validate()) {
                    $notification->save();
                    $transaction->commit();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Notification' . UPDATED,
                        'title' => 'Notification Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);

                    return $this->redirect(['notification/index']);
                } else {
                    $transaction->rollBack();
                    print_r($notification->getErrors());
                    die;
                }
            }
        }
        return $this->render('edit_notification', [
                    'model' => $model
        ]);
    }

    /**
     * Status Action
     *  In this action use for change Status for Area.
     * $id is Area id
     * @return mixed
     */
    public function actionStatus($id) {
	
        $model = Notification::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Notification' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Notification' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['notification/index']));
    }

    /**
     * Delete Action
     *  In this action use for delete Area data.
     * $id is Area id
     * @return
     */
    public function actionDelete($id) {
			
        if ($id) {
            $model = Notification::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Notification' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['notification/index']));
            }
        }
    }

}
