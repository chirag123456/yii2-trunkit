<?php

namespace backend\controllers;

use Yii;
use backend\components\CustController;
use common\models\VehicleManagement;
use common\models\user\User;
use yii\web\Response;
use yii\widgets\ActiveForm;
use backend\components\CommonFunctions;
use common\models\vehicletype\VechicleTypeForm;
use common\models\vehicletype\VechicleType;
use common\models\vehicletype\VehicleTypeSearch;

class VehicleTypeController extends CustController {
/**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new VehicleTypeSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $model = new VechicleType();

        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $details = VechicleType::findOne(['id' => $_GET['id'], 'is_delete' => INACTIVE]);

            if ($details != null) {
                $model = new VechicleType();
                $model->attributes = $details->attributes;
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Something Error : Invalid data!',
                    'title' => 'Something Error : Invalid data!',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['vehicle-type/index']);
            }
        }
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model,
        ]);
    }
/**
     * Add Action
     *  In this action use for Add the new data.
     * @return mixed
     */
    public function actionAdd() {

        $model = new VechicleType();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $type = new VechicleType();
            $type->attributes = $model->attributes;

            $type->name = $model->name;
            $type->is_active = ACTIVE;
            $type->is_delete = NOT_DELETED;


            if ($type->validate()) {
                if ($type->save()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Vehicle Type' . ADDED,
                        'title' => 'Vehicle Type Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }

            return $this->redirect(['index']);
        }
        return $this->render('type', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model
        ]);
    }
/**
     * Update Action
     *  In this action use for update the data.
     * @return mixed
     */
    public function actionUpdate($id) {

        $model = new VechicleType();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $type = VechicleType::find()->where(['id' => $_GET['id']])->one();

            $type->name = trim($model->name);
            $type->modifier = trim($model->modifier);
            $type->is_active = ACTIVE;
            $type->is_delete = NOT_DELETED;

            if ($type->validate()) {
                if ($type->save()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Vehicle Type' . UPDATED,
                        'title' => 'Vehicle Location Update',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
        }

        return $this->redirect(['index']);
    }
 /**
     * Status Action
     *  In this action use for change the status.
     * @return mixed
     */
    public function actionStatus($id) {
        $model = VechicleType::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Vehicle Type' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Vehicle Type' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    }
/**
     * Delete Action
     *  In this action use for Delete the data.
     * @return mixed
     */
    public function actionDelete($id) {
        if ($id) {
            $model = VechicleType::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Vehicle Type' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }
}
