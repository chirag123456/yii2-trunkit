<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use common\models\review\ReviewSearch;
use yii\bootstrap\ActiveForm;
use backend\components\CustController;
use common\models\post\PostOrder;
use common\models\review\Review;

/**
 * ReviewController
 *  This controller used for City list , add , update , delete.
 * @author Trunkit
 * @since Jun,2017
 */
class ReviewController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new ReviewSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }
    // public function actionApprove($id) {

    // $model = Review::findOne($id);
    //     if ($model->is_approved == ACTIVE) {
    //         $model->is_approved = INACTIVE;
    //         Yii::$app->getSession()->setFlash('success', [
    //             'type' => 'success',
    //             'duration' => 12000,
    //             'image' => 'glyphimage glyphimage-ok-sign',
    //             'message' => ' Review' .NOTAPPROVED,
    //             'title' => 'Inactive Added',
    //             'positonY' => 'top',
    //             'positonX' => 'right'
    //         ]);
    //     } else {
    //         $model->is_approved = ACTIVE;
    //         Yii::$app->getSession()->setFlash('success', [
    //             'type' => 'success',
    //             'duration' => 12000,
    //             'image' => 'glyphimage glyphimage-ok-sign',
    //             'message' => ' Review' .APPROVED,
    //             'title' => 'Inactive Added',
    //             'positonY' => 'top',
    //             'positonX' => 'right'
    //         ]);
    //     }
    //     $model->save(false);
    //     //return $this->redirect($_SERVER['HTTP_REFERER']);
    //     return $this->redirect(['review/index']);
    // }
}
