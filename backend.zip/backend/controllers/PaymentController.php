<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\transaction\Transaction;
use common\models\city\City;
use common\models\city\CitySearch;
use backend\components\CustController;
use common\models\post\PostOrderSearch;
use common\models\post\PostOrder;
use frontend\components\CommonFunctions;
/**
 * PaymentController
 *  This controller used for Payment list , add , update , delete.
 * @author Trunkit
 * @since Jun,2017
 */
class PaymentController extends CustController {

    /**
    * Payment pending single view  
    */
    public function actionView($id) {

        $model = Transaction::getTransactionDetail($id);
        //echo "<pre>"; print_r($model); exit();
        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                //'icon' => 'glyphicon glyphicon-remove-sign',
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['order/post-order']);
        }
        return $this->render('view', ['model' => $model]);
    }

    //Function for Pending Payment
    public function actionPendingPayment() {

        $searchModel = new PostOrderSearch();
        $is_exported = NOT_DELETED;
        //$dataProvider = $searchModel->searchpendingpay(Yii::$app->request->queryParams, $is_exported);
    
        $dataProvider = $searchModel->searchpendingpayment(Yii::$app->request->queryParams, $is_exported);
        
    
        return $this->render('pending-payment', [ 
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'post' => isset($_POST) && !empty($_POST) ? $_POST : ''
        ]);
    }

    // Export csv for Pending Payments
     public function actionExport() {
       
        $i = 1;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];
     
        if(isset($_REQUEST['id']) && $_REQUEST['id']!='')
        {
            $ids = $_REQUEST['id'];
            
            //$post_order = new PostOrder();
            $trans = new Transaction();
            $data = $trans->getTransactionData($ids);
            $adminPaypalCommisionPercentage = CommonFunctions::getConfigureValueByKey('TRUNKIT_COMMISION');

            if(isset($data) && !empty($data))
            {
                $i=0;
                foreach ($data as  $value) {
                    //$adminCommision =  $value['to_user_amt']* $adminPaypalCommisionPercentage/100;
                    //$driver_amt = $value['price']-$adminCommision;

                    //$data_val[$i]['name'] = $value['first_name']. ' '.$value['last_name'];
                    $data_val[$i]['email'] = $value['paypal_email_id'];
                    $data_val[$i]['to_user_amt'] = $value['to_user_amt'];
                    $data_val[$i]['usd'] = 'USD';
                    $data_val[$i]['msg'] = 'Thanks '.$value['first_name']. ' '.$value['last_name'];
                    $i++;
                }
            }
        }
            //$fields = $data_key1;
            $fields_val = $data_val;
            //$this->dataExport($fields, $fields_val);
            $this->dataExport($fields_val);
          
            if(!isset($_REQUEST['is_archived'])){
                $id_arr = explode(',', $ids);
                foreach($id_arr as $vals){
                    $transaction = Transaction::find()->where(['id' => $vals])->one();
                    $transaction->is_exported = 'Y';
                    $transaction->exported_date = date("Y-m-d H:i:s");
                    $transaction->save();
                }
            }
              
    }

    /**
     * dataExport Function
     *  In this function all product data export in (.xls) file format.
     * @return mixed
     */
    public function dataExport($data) {
        //$setCounter = 0;
        $setExcelName = "PendingPayments".date('Y-m-d H:i:s');
        $setMainHeader = "";
        $setData = "";

        /*$setCounter = count($fields);

        foreach ($fields as $k => $v) {
            $setMainHeader .= $v . "\t";
        }*/

        foreach ($data as $val) {
            $rowLine = "";
            foreach ($val as $key => $value) {
                //$value = strip_tags(str_replace('"', '""', $value));
                $value = strip_tags(str_replace('', '', $value));
                //$value = '"' . $value . '"' . "\t";

                $value = $value .',';

                $rowLine .= $value;
            }
            $str = strlen($rowLine);
            $setData .= substr(trim($rowLine), 0, $str-1) . "\n";
        }

        $setData = str_replace("\r", "", $setData);

        if ($setData == "") {
            $setData = "\nno matching records found\n";
        }

        //$setCounter = count($fields);
        //This Header is used to make data download instead of display the data
        //header("Content-type: application/xls; charset=utf-8");
        header("Content-Type: text/csv");
        header("Content-Disposition: attachment; filename=" . $setExcelName . ".csv");
        header("Pragma: no-cache");
        header("Expires: 0");

        //It will print all the Table row as Excel file row with selected column name as header.
        // Simple Output Data
        //echo ucwords($setMainHeader)."\n".$setData."\n";
        // UTF-8 Output Data
        //$output = ucwords($setMainHeader) . "\n" . $setData . "\n";
        $output = $setData . "\n";
        //print( chr(255) . chr(254) . mb_convert_encoding($output, 'UTF-16LE', 'UTF-8'));
        print($output);
    }

    //Function for Pending Payment
    public function actionArchivedPayment() {

        $searchModel = new PostOrderSearch();
        $is_exported = ACTIVE;
        $dataProvider = $searchModel->searchpendingpay(Yii::$app->request->queryParams, $is_exported);
    
        return $this->render('archived-payment', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

}
