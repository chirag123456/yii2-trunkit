<?php

namespace backend\controllers;

use Yii;
use yii\web\Controller;
use backend\models\ForgotPasswordForm;
use yii\helpers\Url;
use common\models\user\User;
use yii\web\Response;
use common\models\LoginForm;
use yii\bootstrap\ActiveForm;

class SiteController extends Controller {

    public function actions() {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }
    
  /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        return $this->render('login');
    }
  /**
     * Error Action
     *  In this action show the Error.
     * @return mixed
     */
    public function actionError() {
        $this->layout = "error/main";
        $exception = Yii::$app->errorHandler->exception;
        return $this->render('error', ['error' => $exception]);
    }
  /**
     * Login Action
     * In this Action use for Login driver.
     * @return mixed
     */
    public function actionLogin() {

        $this->layout = "login/main";

        $model = new LoginForm();

        if (!Yii::$app->user->isGuest) {
            return $this->redirect(\Yii::$app->urlManager->createUrl("dashboard/index"));
        }
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model); // Validation Advertisement add input
        }

        if ($model->load(Yii::$app->request->post()) && $model->loginAdmin()) {
            
            $user = User::find()->where(['email' => $model->email])->andWhere(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->one();

            if ($user != null) {
                $user->last_login = date("Y-m-d H:i:s");
                $user->ip_address = $_SERVER['REMOTE_ADDR'];
                $user->is_login = ACTIVE;
                $user->save(false);
                return $this->redirect(\Yii::$app->urlManager->createUrl("dashboard/index"));
            } else {
                return $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
            }
        } else {
            return $this->render('login', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * @actionForgotPassword
     * In this action use for Forgot Password Mail
     */
    public function actionForgotPassword() {

        $this->layout = "login/main";

        if (!Yii::$app->user->isGuest) {
            return $this->redirect(['dashboard/index']);
        }

        $model = new ForgotPasswordForm();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $user = User::find()->where(['email' => $model->email])->andWhere(['role' => 1])
                            ->andWhere(['is_active' => ACTIVE, 'is_delete' => NOT_DELETED])->one();
            if ($user != null) {
                $password = $model->rendomStringGenrator(10);
                $user->setPassword($password);
                if ($user->save(false)) {

                    $userData = [
                        'username' => $user->username,
                        'email' => $user->email,
                        'password' => $password,
                        'url' => \yii\helpers\Url::base(true),
                    ];

                    if ($model->sendEmail($userData)) {
                        return $this->redirect(['site/forgot-password?sendmail=true']);
                    } else {
                        Yii::$app->getSession()->setFlash('danger', [
                            'type' => 'danger',
                            'duration' => 12000,
                            'icon' => 'glyphicon glyphicon-remove-sign',
                            'message' => 'Something error in mail send!',
                            'title' => 'Error',
                            'positonY' => 'top',
                            'positonX' => 'right'
                        ]);
                    }
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-remove-sign',
                        'message' => 'Something error in mail send!',
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            }
        }

        return $this->render('forgot-password', ['model' => $model]);
    }

    /**
     * @actionLogout
     * In this action use for Logout driver 
     */
    public function actionLogout() {

        Yii::$app->user->logout();
        return $this->redirect(\Yii::$app->urlManager->createUrl("site/login"));
    }

}
