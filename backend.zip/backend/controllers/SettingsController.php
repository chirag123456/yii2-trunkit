<?php
namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use yii\bootstrap\ActiveForm;
use common\models\Settings;
use common\models\form\SettingsForm;


/**
 * SettingsController
 *  This controller used for Settings update.
 * @author Xceltec01
 * @since Jun,2017
 */
class SettingsController extends Controller {

    /**
     * Index Action
     *  In this action for update settings data.
     * @return mixed
     */
    public function actionIndex() {

        $details = \common\models\Settings::find()->all();
        
        $SettingsForm = new SettingsForm();
        $model = $SettingsForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {

                $setting = Settings::find()->all();
                foreach ($setting as $settings) {
                    $settings->attributes = $model->attributes;
                    $settings->paging = trim($model->paging);
                    $settings->created_by = Yii::$app->user->identity->id;
                    $settings->updated_by = Yii::$app->user->identity->id;
                    $settings->date_created = date("Y-m-d H:i:s");
                    $settings->date_updated = date("Y-m-d H:i:s");
                }

                if ($settings->validate()) {
                    $settings->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Settings' . ADDED,
                        'title' => 'Settings',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                    return $this->redirect(['settings/index']);
                } else {
                    print_r($settings->getErrors());
                    die;
                }
            }
        }
        return $this->render('edit-settings', [
                    'model' => $model
        ]);
    }

}
