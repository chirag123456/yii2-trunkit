<?php

namespace backend\controllers;

ini_set('memory_limit', '512M');

use Yii;
use XLSXWriter;
use common\models\post\PostOrder;
use backend\components\CustController;
use PHPExcel;
use PHPExcel_IOFactory;
use yii2tech\csvgrid\CsvGrid;
use kartik\export\ExportMenu;

class ExportController extends CustController {

    public $enableCsrfValidation = true;
  /**
     * Export Data Action
     *  In this action for Export the data.
     * @return mixed
     */
    public function actionExportData1() {

        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "Order.csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');
        $data_key1 = ['Tracking No', 'Origin','Destination' ,'Order Date', 'Total Amount'];

        fputcsv($output, $data_key1);

        $i = 1;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];
        $order = $_GET['order'];
        if ($order == 'daily') {
            $product = PostOrder::find()
                            ->select('traking_number','order_date','price')
                            ->where(['is_delete' => NOT_DELETED])
                            ->andWhere(['order_status' => 'FINISHED'])
                            ->andWhere(['>=','created_date',date("Y-m-d")])
                            ->all();
        } elseif ($order == 'monthly') {
            $product = PostOrder::find()
                            ->select(['DATE_FORMAT(created_date,"%Y-%m") as created_date ,count(traking_number) as traking_number,sum(price) as price'])
                            ->where(['is_delete' => NOT_DELETED])
                            ->andWhere(['order_status' => 'FINISHED'])
                            ->groupBy(['DATE_FORMAT(created_date,"%Y-%m")'])->all();
        } elseif ($order == 'yearly') { 
            /*$product = PostOrder::find()
                            ->select(['DATE_FORMAT(created_date,"%Y") as created_date ,count(traking_number) as traking_number,sum(price) as price'])
                            ->where(['is_delete' => NOT_DELETED])
                            ->andWhere(['order_status' => 'FINISHED'])
                            ->groupBy(['DATE_FORMAT(created_date,"%Y")'])->all();*/
                            $year =  date('Y');
                            $data = PostOrder::find()->select('order_date')->where(['YEAR(order_date)'=> $year])->orderBy(['order_date'=>SORT_DESC])->all(); 
                            $query = PostOrder::find()->where(['is_delete' => NOT_DELETED])->andWhere(['order_status' => 'FINISHED','order_date' => $data]);
        } else {
            $product = PostOrder::find()
                            ->select(['DATE_FORMAT(created_date,"%Y-%m-%d") as created_date ,count(traking_number) as traking_number,price'])
                            ->where(['is_delete' => NOT_DELETED])
                            ->andWhere(['order_status' => 'FINISHED'])
                            ->groupBy(['DATE_FORMAT(created_date,"%Y-%m-%d")'])->all();
        }

        if ($product != null) {
            if ($order == 'daily') {
                $sm = PostOrder::find()
                            ->select('traking_number','order_date','price')
                            ->where(['is_delete' => NOT_DELETED])
                            ->andWhere(['order_status' => 'FINISHED'])
                            ->andWhere(['>=','created_date',date("Y-m-d")])
                            ->all();
            } elseif ($order == 'monthly') {
                $sm = PostOrder::find()
                                ->select(['DATE_FORMAT(created_date,"%Y-%m") as created_date ,count(traking_number) as traking_number,sum(price) as price'])
                                ->where(['is_delete' => NOT_DELETED])
                                ->andWhere(['order_status' => 'FINISHED'])
                                ->groupBy(['DATE_FORMAT(created_date,"%Y-%m")'])->all();
            } elseif ($order == 'yearly') {
                $sm = PostOrder::find()
                                ->select(['DATE_FORMAT(created_date,"%Y") as created_date ,count(traking_number) as traking_number,sum(price) as price'])
                                ->where(['is_delete' => NOT_DELETED])
                                ->andWhere(['order_status' => 'FINISHED'])
                                ->groupBy(['DATE_FORMAT(created_date,"%Y")'])->all();
            } else {
                $sm = PostOrder::find()
                                ->select(['DATE_FORMAT(created_date,"%Y-%m-%d") as created_date ,count(traking_number) as traking_number,price'])
                                ->where(['is_delete' => NOT_DELETED])
                                ->andWhere(['order_status' => 'FINISHED'])
                                ->groupBy(['DATE_FORMAT(created_date,"%Y-%m-%d")'])->all();
            }

            foreach ($product as $data) {
                $data_val[$i][] = $data->traking_number;
                $data_val[$i][] = $data->created_date;
                $data_val[$i][] = $data->traking_number;
                $data_val[$i][] = $data->price;

                if ($order == 'daily') {
                    $sm =PostOrder::find()
                            ->select('traking_number','order_date','price')
                            ->where(['is_delete' => NOT_DELETED])
                            ->andWhere(['order_status' => 'FINISHED'])
                            ->andWhere(['>=','created_date',date("Y-m-d")])
                            ->all();
                } elseif ($order == 'monthly') {
                    $sm = PostOrder::find()
                                    ->select(['DATE_FORMAT(created_date,"%Y-%m") as created_date ,count(traking_number) as traking_number,sum(price) as price'])
                                    ->where(['is_delete' => NOT_DELETED])
                                    ->andWhere(['order_status' => 'FINISHED'])
                                    ->groupBy(['DATE_FORMAT(created_date,"%Y-%m")'])->all();
                } elseif ($order == 'yearly') {
                    $sm = PostOrder::find()
                                    ->select(['DATE_FORMAT(created_date,"%Y") as created_date ,count(traking_number) as traking_number,sum(price) as price'])
                                    ->where(['is_delete' => NOT_DELETED])
                                    ->andWhere(['order_status' => 'FINISHED'])
                                    ->groupBy(['DATE_FORMAT(created_date,"%Y")'])->all();
                } else {
                    $sm = PostOrder::find()
                                    ->select(['DATE_FORMAT(created_date,"%Y-%m-%d") as created_date ,count(traking_number) as traking_number,price'])
                                    ->where(['is_delete' => NOT_DELETED])
                                    ->andWhere(['order_status' => 'FINISHED'])
                                    ->groupBy(['DATE_FORMAT(created_date,"%Y-%m-%d")'])->all();
                }
                foreach ($sm as $val) {
                    if($order == 'daily'){
                    $sql1 = PostOrder::find()
                            ->select('traking_number','order_date','price')
                            ->where(['is_delete' => NOT_DELETED])
                            ->andWhere(['order_status' => 'FINISHED'])
                            ->andWhere(['>=','created_date',date("Y-m-d")])
                            ->all();
                    }elseif($order == 'monthly'){
                    $sql1 = "SELECT DATE_FORMAT(created_date,'%Y-%m') as created_date ,count(traking_number) as traking_number,sum(price) as price FROM `post_order` WHERE `is_delete`='N' AND order_status = 'FINISHED' GROUP BY YEAR(`created_date`),MONTH(`created_date`)";
                    }elseif($order == 'yearly'){
                    $sql1 = "SELECT DATE_FORMAT(created_date,'%Y') as created_date ,count(traking_number) as traking_number,sum(price) as price FROM `post_order` WHERE `is_delete`='N' AND order_status = 'FINISHED' GROUP BY YEAR(`created_date`)";
                    }else{
                    $sql1 = "SELECT created_date,traking_number,price FROM `post_order` WHERE `is_delete`='N' AND order_status = 'FINISHED' GROUP BY DATE(`created_date`)";
                    }
                    $connection = \Yii::$app->getDb();
                    $command = $connection->createCommand($sql1);
                    $result1 = $command->queryAll();
                }
                $i++;
            }
        }

        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }
    }

    public function actionExportData()
    {
        header('Content-Type: text/csv; charset=utf-8');
        $file_name = "StatisticsReport".date('Y-m-d H:i:s').".csv";
        header('Content-Disposition: attachment; filename=' . $file_name);
        $output = fopen('php://output', 'w');
        $data_key1 = ['Tracking No', 'Origin','Destination' ,'Order Date', 'Total Amount'];

        fputcsv($output, $data_key1);

        $i = 1;
        $data_key_new = [];

        $data_val = [];
        $data_val_new = [];
        $order = $_GET['order'];
        if($order == 'daily'){
            $date =  Yii::$app->formatter->asDate('now', 'yyyy-MM-dd');
            $query = PostOrder::find()->joinWith('post')->where(['post_order.is_delete' => NOT_DELETED])->andWhere(['post_order.order_status' => 'FINISHED', 'order_date' => $date])->all();            
        }elseif ($order == 'monthly') {
            //$yourMonth = date('m') -1;
            $yourMonth = date('m');
            $data = PostOrder::find()->select('order_date')->joinWith('post')->where(['MONTH(order_date)'=> $yourMonth ])->orderBy(['order_date'=>SORT_DESC])->all();         
            
            $query = PostOrder::find()->joinWith('post')->where(['post_order.is_delete' => NOT_DELETED])->andWhere(['post_order.order_status' => 'FINISHED','order_date' => $data])->all();
            
        }elseif ($order == 'yearly') {
            $year =  date('Y');
            $data = PostOrder::find()->select('order_date')->where(['YEAR(order_date)'=> $year])->orderBy(['order_date'=>SORT_DESC])->all(); 
            $query = PostOrder::find()->joinWith('post')->where(['post_order.is_delete' => NOT_DELETED])->andWhere(['post_order.order_status' => 'FINISHED','order_date' => $data])->all();
        }else {
            $query = PostOrder::find()->joinWith('post')->where(['post_order.is_delete' => NOT_DELETED])->andWhere(['post_order.order_status' => 'FINISHED'])->all();
        }

        //echo count($query)."<pre>"; print_r($query); exit();
        foreach ($query as $val) {
            $data_val[$i][] = $val->traking_number;
            $data_val[$i][] = $val->post->origin;
            $data_val[$i][] = $val->post->destination;
            $data_val[$i][] = "'".$val->order_date."'";
            $data_val[$i][] = $val->price;
            $i++;
        }
    
        foreach ($data_val as $val) {
            fputcsv($output, $val);
        }
    }

}
