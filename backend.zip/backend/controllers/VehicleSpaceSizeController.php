<?php

namespace backend\controllers;

use Yii;
use backend\components\CustController;
use common\models\VehicleSpaceSizeManagement;
use common\models\user\User;
use yii\web\Response;
use yii\widgets\ActiveForm;
use backend\components\CommonFunctions;
use common\models\vehiclespacesize\VehicleSpaceSize;
use common\models\vehiclespacesize\VehicleSpaceSizeSearch;

class VehicleSpaceSizeController extends CustController {
   /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new VehicleSpaceSizeSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $model = new VehicleSpaceSize();

        if (isset($_GET['id']) && !empty($_GET['id'])) {
            $details = VehicleSpaceSize::findOne(['id' => $_GET['id'], 'is_delete' => INACTIVE]);

            if ($details != null) {
                $model = new VehicleSpaceSize();
                $model->attributes = $details->attributes;
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Something Error : Invalid data!',
                    'title' => 'Something Error : Invalid data!',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect(['vehicle-space-size/index']);
            }
        }
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model,
        ]);
    }
 /**
     * Add Action
     *  In this action use for Add the new data.
     * @return mixed
     */
    public function actionAdd() {

        $model = new VehicleSpaceSize();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $size = new VehicleSpaceSize();
            $size->attributes = $model->attributes;

            $size->name = $model->name;
            $size->is_active = ACTIVE;
            $size->is_delete = NOT_DELETED;
            if ($size->validate()) {
                if ($size->save()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Vehicle Space Size' . ADDED,
                        'title' => 'Vehicle Space Size Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }

            return $this->redirect(['vehicle-space-size/index']);
        }
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'model' => $model
        ]);
    }
/**
     * Update Action
     *  In this action use for update the  data.
     * @return mixed
     */
    public function actionUpdate($id) {

        $model = new VehicleSpaceSize();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }

        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {

            $size = VehicleSpaceSize::find()->where(['id' => $_GET['id']])->one();

            $size->name = trim($model->name);
            $size->is_active = ACTIVE;
            $size->is_delete = NOT_DELETED;

            if ($size->validate()) {
                if ($size->save()) {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Vehicle Space Size' . UPDATED,
                        'title' => 'Item Location Update',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
        }
        return $this->redirect(['vehicle-space-size/index']);
    }
    /**
     * Status Action
     *  In this action use for change the status.
     * @return mixed
     */

    public function actionStatus($id) {
        $model = VehicleSpaceSize::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Vehicle Space Size' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Vehicle Space Size' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        return $this->redirect($_SERVER['HTTP_REFERER']);
    }
/**
     * Delete Action
     *  In this action use for Delete the data.
     * @return mixed
     */
    public function actionDelete($id) {
        if ($id) {
            $model = VehicleSpaceSize::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Vehicle Space Size' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                return $this->redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }

}
