<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\web\Controller;
use common\models\post\PostOrderSearch;
use yii\bootstrap\ActiveForm;
use backend\components\CustController;
use common\models\post\PostOrder;

class OrderController extends CustController {


    public function actionPostOrder() {

        $searchModel = new PostOrderSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('post-order', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    public function actionDelete($id) {
        if ($id) {
            $model = PostOrder::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'City' . DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['order/post-order']));
            }
        }
    }
    
    public function actionView($id) {

        $model = PostOrder::find()->where(['is_delete' => INACTIVE])->andWhere('traking_number = ' . $id)->one();

        if ($model == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                //'icon' => 'glyphicon glyphicon-remove-sign',
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);

            return $this->redirect(['order/post-order']);
        }
        return $this->render('view', ['model' => $model]);
    }

}
