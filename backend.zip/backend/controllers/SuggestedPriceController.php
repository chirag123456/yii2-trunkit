<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use common\models\cms\Cms;
use common\models\cms\CmsForm;
use common\models\cms\CmsSearch;
use backend\components\CustController;
use backend\components\CommonFunctions;


/**
 * UserController
 *  This controller used for User list , add , update , delete.
 * @author Trunkit
 * @since Jun,2017
 */
class CmsController extends CustController { 

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new CmsSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Add Action
     *  In this action use for Add new data in CMS.
     * @return
     */
   public function actionAdd() {
        $model = new CmsForm();
//echo '<pre>';print_r($_POST['content']);die;
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
                       
                $cms = new Cms();
                $cms->attributes = $model->attributes;               
                $cms->name = trim($model->name);
                $cms->slug = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '-', $model->name));
                //$cms->content = trim($model->content);
                $cms->content = $_POST['content'];
                $cms->created_by = Yii::$app->user->identity->id;
                $cms->updated_by = Yii::$app->user->identity->id;
                $cms->date_created = date("Y-m-d H:i:s");
                $cms->date_updated = date("Y-m-d H:i:s");
                $cms->is_active = ACTIVE;
                $cms->is_delete = NOT_DELETED;
			
             
                if ($cms->validate()) {
                    
                    $cms->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Content' . ADDED,
                        'title' => 'Content Page Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                   
                    return $this->redirect(['cms/index']);
                } else {
                    Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-remove-sign',
                    'message' => 'Something error.',
                    'title' => 'User Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                    return $this->redirect(['cms/index']);
                }
            
        }
        return $this->render('create', [
                    'model' => $model
        ]);
    }
 /**
     * Update Action
     *  In this action use for Update data in CMS.
     * @return
     */
   public function actionUpdate($id) {

        $details = Cms::findOne($id);
        $CmsForm = new CmsForm();
        $model = $CmsForm->getUpdateModel($details);

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if (Yii::$app->request->post() && $model->load(Yii::$app->request->post())) {
            $errors = ActiveForm::validate($model);
            if ($errors) {
                print_r($errors);
                die;
            } else {
                $cms = Cms::find()->where(['id' => $details->id])->one();

                $cms->attributes = $model->attributes;
		$cms->slug = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '-', $model->name));
                $cms->content = $_POST['content'];
                $cms->created_by = Yii::$app->user->identity->id;
                $cms->updated_by = Yii::$app->user->identity->id;
                $cms->date_created = date("Y-m-d H:i:s");
                $cms->date_updated = date("Y-m-d H:i:s");

                
                  if ($cms->validate()) {
                    $cms->save();
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'Content ' .UPDATED,
                        'title' => 'Content Page Added',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                   
                    return $this->redirect(['cms/index']);
                } else {
                    print_r($cms->getErrors());
                    die;
                }
            }
        }
        return $this->render('edit-cms', [
                    'model' => $model
        ]);
    }
 /**
     * Status Action
     *  In this action use for change status .
     * @return
     */
    public function actionStatus($id) {
        $model = Cms::findOne($id);
        if ($model->is_active == "Y") {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Content' . DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => 'Content' . ACTIVATED,
                'title' => 'Active Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        $this->redirect(\Yii::$app->urlManager->createAbsoluteUrl(['cms/index']));
    }

     /**
     * Delete Action
     *  In this action use for Delete Cms.
     * @return
     */
    public function actionDelete($id) {
        if ($id) {

            $model = Cms::findOne($id);

            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'icon' => 'glyphicon glyphicon-ok-sign',
                    'message' => 'Content' . DELETEDMESSAGE,
                    'title' => 'Delete Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);

                return $this->redirect(Yii::$app->urlManager->createAbsoluteUrl(['cms/index']));
            }
        }
    }

}
