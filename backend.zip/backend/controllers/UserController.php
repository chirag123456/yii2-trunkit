<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use common\models\user\User;
use common\models\user\UserForm;
use common\models\user\UserSearch;
use common\models\ChangePasswordForm;
use backend\components\CustController;
use backend\components\CommonFunctions;
use common\models\userrole\UserAccess;
use common\models\userrole\AuthAssignment;

/**
 * UserController
 *  This controller used for User list , add , update , delete.
 * @author Trunkit
 * @since Jun,2017
 */
class UserController extends CustController {

    /**
     * Index Action
     *  In this action show list of data.
     * @return mixed
     */
    public function actionIndex() {

        $role = '2';
        $searchModel = new UserSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams, $role);
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Add Action
     *  In this action use for Add new data in User.
     * @return
     */
    public function actionAdd() {

        $model = new UserForm();
        
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
        //echo 'rrr<pre>';print_r(Yii::$app->request->post()); die;    
            return ActiveForm::validate($model);
        }
    //echo 'rrr<pre>';print_r($model->attributes); die; 
        if ($model->load(Yii::$app->request->post())) {
            $user = new User();

            $user->attributes = $model->attributes;
            
            $user->setPassword($model->password);
            $user->generateAuthKey();
            $user->generatePasswordResetToken();
            $user->role = 2;
            $user->username = $model->email;

            if (!empty($_POST['UserForm']['image_name'])) {
                $user->driver_licence = $this->base64_to_image($_POST['UserForm']['image_name'], 'users/driver_licence');
            }
            if (!empty($_POST['UserForm']['user_image'])) {
                $user->image = $this->base64_to_image($_POST['UserForm']['user_image'], 'users/image');
            }
            $user->last_login = date("Y-m-d H:i:s");
            $user->ip_address = $_SERVER['REMOTE_ADDR'];
            $user->created_by = Yii::$app->user->identity->id;
            $user->updated_by = Yii::$app->user->identity->id;
            $user->updated_date = date("Y-m-d H:i:s");
            $user->created_date = date("Y-m-d H:i:s");
            $user->is_active = ACTIVE;
            $user->is_delete = NOT_DELETED;

            if ($user->validate()) 
            {
                if($user->save()){
					
                     if ($model->sendUserEmail($user->id))
                     {
                        Yii::$app->getSession()->setFlash('success', [
                            'type' => 'success',
                            'duration' => 12000,
                            'icon' => 'glyphicon glyphicon-ok-sign',
                            'message' => 'Thanks for signing up ! Please confirm email address using the verification link sent to you.',
                            'title' => 'User Added',
                            'positonY' => 'top',
                            'positonX' => 'right'
                        ]);
                    }
                     else {
                        Yii::$app->getSession()->setFlash('success', [
                            'type' => 'success',
                            'duration' => 12000,
                            'icon' => 'glyphicon glyphicon-ok-sign',
                            'message' => 'Thanks for signing up ! Please confirm email address using the verification link sent to you.',
                            'title' => 'User Added',
                            'positonY' => 'top',
                            'positonX' => 'right'
                        ]);
                    }
				}else{
					echo "error";
				}
                
            } else {
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_SAVED,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['user/index']);
        }
        return $this->render('create', [
                    'model' => $model,
        ]);
    }
    
    /**
     * Update Action
     *  In this action update the data.
     * @return mixed
     */
    public function actionUpdate($id) {
        $details = User::find()->where(['is_delete' => INACTIVE])->andWhere('id = ' . $id)->one();

        if ($details == NULL) {
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'danger',
                'duration' => 12000,
                'icon' => 'glyphicon glyphicon-ok-sign',
                'message' => DATA_NOT_VALID,
                'title' => 'Error',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
            return $this->redirect(['user/index']);
        }
        $model = new UserForm();
        $model->attributes = $details->attributes;

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return ActiveForm::validate($model);
        }
        if ($model->load(Yii::$app->request->post())) {
            $user = User::findOne(['id' => $id]);

            $user->attributes = $model->attributes;
            $user->username = $model->email;
            
            $user->driver_licence2 = $details->driver_licence2;
            if (empty($_POST['UserForm']['image_name'])) {
                $user->driver_licence = $user->driver_licence;
            } else {
                $user->driver_licence = $this->base64_to_image($_POST['UserForm']['image_name'], 'users/driver_licence');
            }

            if (empty($_POST['UserForm']['image'])) {
                $user->image = $user->oldAttributes['image'];
            } else {
                $user->image = $this->base64_to_image($_POST['UserForm']['image'], 'users/image');
            }

            $user->updated_by = Yii::$app->user->identity->id;
            $user->updated_date = date("Y-m-d H:i:s");
           
            if ($user->validate()) {
                if ($user->save()) {
                    if (isset($_POST['UserForm']['image_name']) && $_POST['UserForm']['image_name'] != "") {
                        $image = CommonFunctions::base64ToImage($_POST['UserForm']['image_name'], date("YmdHis"), 'users/driver_licence/');
                    }
                    if (isset($_POST['UserForm']['image']) && $_POST['UserForm']['image'] != "") {
                        $image2 = CommonFunctions::base64ToImage($_POST['UserForm']['image'], date("YmdHis"), 'users/image/');
                    }

                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'success',
                        'duration' => 12000,
                        'icon' => 'glyphicon glyphicon-ok-sign',
                        'message' => 'User' . UPDATED,
                        'title' => 'User Updated',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                } else {
                    Yii::$app->getSession()->setFlash('success', [
                        'type' => 'danger',
                        'duration' => 12000,
                        'message' => DATA_NOT_SAVED,
                        'title' => 'Error',
                        'positonY' => 'top',
                        'positonX' => 'right'
                    ]);
                }
            } else {
                Yii::$app->getSession()->setFlash('danger', [
                    'type' => 'danger',
                    'duration' => 12000,
                    'message' => DATA_NOT_VALID,
                    'title' => 'Error',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
            }
            return $this->redirect(['user/index']);
        }

        return $this->render('edit-user', [
                    'model' => $model,
        ]);
    }
/**
 * 
 * Base64 to image action
 * In this action use for image path and decode the image
 * @return mixed
 */
    public function base64_to_image($imageData, $type) {

        $basePath = dirname(\Yii::$app->basePath);

        $image_parts = explode(";base64,", $imageData);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $imagename = uniqid() . '.' . $image_type;
        $file = $basePath . DIRECTORY_SEPARATOR . 'media'  . DIRECTORY_SEPARATOR . $type . DIRECTORY_SEPARATOR . $imagename;
        file_put_contents($file, $image_base64);

        return $imagename;
    }

    /**
     * Status Action
     *  In this action use for change Status for User.
     * $id is User id
     * @return mixed
     */
    public function actionStatus($id) {

	$model = User::findOne($id);
        if ($model->is_active == ACTIVE) {
            $model->is_active = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => 'User' .DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_active = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => 'User' .ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        //return $this->redirect($_SERVER['HTTP_REFERER']);
        return $this->redirect(['user/index']);
    }

    /**
     * Delete Action
     *  In this action use for delete User data.
     * $id is User id
     * @return
     */
    public function actionDelete($id) {

	if ($id) {
            $model = User::findOne($id);
            if ($model) {
                $model->is_delete = DELETED;
                $model->save(false);
                Yii::$app->getSession()->setFlash('success', [
                    'type' => 'success',
                    'duration' => 12000,
                    'message' => 'User' .DELETEDMESSAGE,
                    'title' => 'Active Added',
                    'positonY' => 'top',
                    'positonX' => 'right'
                ]);
                //return $this->redirect($_SERVER['HTTP_REFERER']);
                return $this->redirect(['user/index']);
            }
        }
    }
    
    /**
     * Status Action
     *  In this action use for change Status for User.
     * $id is User id
     * @return mixed
     */
    public function actionApprove($id) {

	$model = User::findOne($id);
        if ($model->is_approved == ACTIVE) {
            $model->is_approved = INACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => 'User' .DEACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        } else {
            $model->is_approved = ACTIVE;
            Yii::$app->getSession()->setFlash('success', [
                'type' => 'success',
                'duration' => 12000,
                'image' => 'glyphimage glyphimage-ok-sign',
                'message' => 'User' .ACTIVATED,
                'title' => 'Inactive Added',
                'positonY' => 'top',
                'positonX' => 'right'
            ]);
        }
        $model->save(false);
        //return $this->redirect($_SERVER['HTTP_REFERER']);
        return $this->redirect(['user/index']);
    }

}
