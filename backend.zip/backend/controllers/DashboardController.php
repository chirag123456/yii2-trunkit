<?php

namespace backend\controllers;

use Yii;
use yii\web\Response;
use yii\bootstrap\ActiveForm;
use common\models\user\User;
use common\models\user\UserForm;
use common\models\user\UserSearch;
use common\models\post\PostSearch;
use common\models\post\Post;
use common\models\post\PostOrderSearch;
use backend\components\CustController;
use common\models\post\PostRequestItems;
use common\models\post\PostRequestItemsSearch;

/**
 * DashboardController
 *  This controller used for view notifications of Feedback & Suggestions.
 * @author Trunkit
 * @since Jun,2017
 */
class DashboardController extends CustController {

    /**
     * Index Action
     *  In this action show notifications list of Feedback & Suggestions.
     * @return mixed
     */
    public function actionIndex() {

        $role = '2';
        $searchModel = new UserSearch();
        $searchModel1 = new PostSearch();
        $searchModel2 = new PostOrderSearch();
        $searchModel3 = new PostRequestItems();
        $searchModel4 = new PostRequestItemsSearch();

        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams, $role); 
        $dataProvider1 = $searchModel1->searchtrip1(Yii::$app->request->queryParams);
        $dataProvider2 = $searchModel1->searchrequest1(Yii::$app->request->queryParams);
        $dataProvider3 = $searchModel2->search1(Yii::$app->request->queryParams);
        $dataProvider4 = $searchModel4->search(Yii::$app->request->queryParams);

        $details = Yii::$app->commonfunction->getDashboardDetails();

        return $this->render('index', [
                    'dataProvider' => $dataProvider,
                    'dataProvider1' => $dataProvider1,
                    'dataProvider2' => $dataProvider2,
                    'dataProvider3' => $dataProvider3,
                    'dataProvider4' => $dataProvider4,
                    'details' => $details,
        ]);
    }

}
