<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use kartik\file\FileInput;

$this->title = 'Admin';
?>


<!-- /.box-header -->
<!-- form start -->
<div class="box-body"> 

    <div class="user-form">

        <?php
     $form= ActiveForm::begin(['id' => 'image-form',
                           'enableAjaxValidation' => true,
                           'enableClientValidation' => true,
                           'options' => ['enctype' => 'multipart/form-data']
                          ]);

        ?>       
        <div class="row">
            <div class="col-md-3">
                <?= $form->field($model, 'name')->textInput(['id'=>'name','autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter  Name']);?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
        <?php    echo $form->field($model, 'image_name')->widget(FileInput::classname(), [
        'options' => ['accept' => 'image/*'],
        'pluginOptions' => ['required'=>true,]
        ]);
        
           // echo  $form->field($model, 'image_name')->hiddenInput(['id'=>'set_img','autofocus' => true, 'maxlength' => 50])->label(false);
            ?>
            <input type="hidden" id="set_img" name="set_img">
        </div>
    
        <div class=" col-md-12">
            <div class="col-md-6 col-md-offset-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                }
                ?>
                <?php echo Html::a('Cancel', ['homeimage/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>
    </div>
    </div>
</div>
    <?php ActiveForm::end(); ?>
</div>
<?php
$this->registerJs("
    $(document).ready(function(){
        $('#image-form').on('submit',function(){        
            $('#set_img').val($('.file-preview-image').attr('src'));
            if($('#set_img').val()==''){
            $('.kv-fileinput-error').html('Select Image File');    
            $('.kv-fileinput-error').css('display','block');            
                return false;
            }else{                
                return true;
            }            
        });
    });
    //$('#set_img').val('');      
");
?>