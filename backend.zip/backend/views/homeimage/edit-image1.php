
<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\Cms */

$this->title = '';
$this->params['breadcrumbs'][] = ['label' => 'Edit Home Image', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>


<section class="content-header">
    <h1>
        Edit Home Image
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("homeimage/index") ?>" >Home Image</a></li>
        <li class="active">Edit Home Image</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Edit Home Image</h3> 
                    <a href="<?= yii\helpers\Url::to(['homeimage/index']) ?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>    <?=
                $this->render('_form', [
                    'model' => $model,
                ])
                ?>
            </div>
        </div>
    </div>
</section>