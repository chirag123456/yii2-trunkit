<?php
/* @var $this yii\web\View */

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel common\models\search\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = 'Admin';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
     Home Image
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Home Image</li>
    </ol>
</section>
<section class="content">
    <!-- Small boxes (Stat box) -->

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <!-- /.box-header -->
                <div class="box-body">
                    <div class="user-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                        $settings = \common\models\Settings::find()->one();
                        //echo '<pre>';print_r($settings['config_value']);die;
                        $pagesize = $settings['config_value'];
                        ?>


                        <?php // echo $this->render('_search', ['model' => $searchModel]);      ?>
                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                            <?= Html::a('Add Home Image', ['add'], ['class' => 'btn btn-primary']) ?>
                            <?php echo Html::a('Reset', ['homeimage/index'], ['class' => 'btn btn-primary filter-reset']) ?>
                        </p>
                        <?php Pjax::begin(['id' => 'users']) ?>  
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'showOnEmpty' => true,
                            'columns' => [
                                /*['class' => 'yii\grid\SerialColumn',

                                    'header' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                    'headerOptions' => ['style' => 'color:#3C8DBC;'],
                                ],*/
                                [   'attribute' => 'id',
                                    'label' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
                                 [
                                    'label' => 'Image',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:70px;'],
                                     'contentOptions'=>[ 'style'=>'width: 10%'], 
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                            $path ="\/media\/home_image\/";
                                            $imgUrl = Yii::$app->request->hostInfo.$path.$model->image_name;
                                            
                                            return '<img data-toggle="tooltip" title=""  alt="Home Image" src="'.$imgUrl.'" style="width:50px;height:50px;border-radius: 25px;">';
                                    },
                                ],
                                // 'id',
                                [
                                    'attribute' => 'name',
                                    'format' => 'raw',                                    
                                    'contentOptions'=>[ 'style'=>'width: 65%'], 
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search By  Name'
                                    ],                                
                                ],
                                [
                                    'attribute' => 'is_active',
                                    'format' => 'raw',
                                    
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select Status'
                                    ],
                                    'filter' => [ACTIVE => "Active", INACTIVE => "Inactive"],
                                    'value' => function ($model) {
                                        if ($model->is_active == ACTIVE) {
                                            return Html::tag('span', 'Active', ['class' => ['label', 'label-success']]);
                                        } elseif ($model->is_active == INACTIVE) {
                                            return Html::tag('span', 'Inactive', ['class' => ['label', 'label-danger']]);
                                        }
                                    },
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{update} {status} {delete}',
                                    'buttons' => [
                                        'status' => function ($url, $model) {
                                            if ($model->is_active == ACTIVE) {
                                                return Html::a('<span class="glyphicon glyphicon-ok-circle" style="color:#5cb85c"></span>', $url, [
                                                            'class' => '',
                                                            'data-confirm' => INACTIVESTATUS . " Home Image?", // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Inactive'
                                                ]);
                                            } else {
                                                return Html::a('<span class="glyphicon glyphicon-remove-circle" style="color:#d9534f"></span>', $url, [
                                                            'data-confirm' => ACTIVESTATUS . " Home Image?", // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Active'
                                                ]);
                                            }
                                        },
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                        'data-confirm' => DELETESTATUS . " Home Image?", // <-- confirmation works...
                                                        'data-method' => 'post',
                                                        'class' => 'delete',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Delete',
                                            ]);
                                        },
                                        'update' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Edit',
                                            ]);
                                        }
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if (is_array($key)) {
                                            $key = $key['id'];
                                        }
                                        if ($action === 'status') {
                                            return \yii\helpers\Url::toRoute(['homeimage/status/' . $key]);
                                        } else if ($action === 'update') {
                                            return \yii\helpers\Url::toRoute(['homeimage/update/' . $key]);
                                        } else if ($action === 'delete') {
                                            return \yii\helpers\Url::toRoute(['homeimage/delete/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
<?php
$this->registerJs("
   $(document).on('ready pjax:success', function () {
    $('.ajaxStatus').on('click', function (e) {
        e.preventDefault();
        var Url     = $(this).attr('status-url');
        var pjaxContainer = $(this).attr('pjax-container');
            $.ajax({
                    url:   Url,
                    type:  'post',
                }).done(function (data) {
                  $.pjax.reload({container: '#' + $.trim(pjaxContainer)});
                });

    });
});
");
?>