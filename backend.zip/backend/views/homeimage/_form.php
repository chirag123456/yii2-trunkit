<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

$this->title = 'Admin';
?>


<!-- /.box-header -->
<!-- form start -->
<div class="box-body"> 

    <div class="user-form">

        <?php
        $form = ActiveForm::begin([
                    'id' => 'user-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
        ]);
        ?>       
        <div class="row">
        <div class="col-md-3">
            <?= $form->field($model, 'name')->textInput(['id'=>'name','autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter  Name']);?>
        </div>
            </div>
        </div>
        <div class="col-md-3">
                    <div class="col-md-12">
                        <div class="image-label2"><label>Select Home Image</label></div>
                    </div>
                    <div class=" col-md-12">                         
                        <div class="cropme" id="client_image" style="width: 200px; height: 200px;" data-image="true"></div>
                        <?= $form->field($model, 'image_name')->hiddenInput(['id'=>'set_img','autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter First Name'])->label(false)?>
                        <!--<input type="hidden" name="HomeImageForm[homeimage]" id="set_img">-->
                        <input type="hidden" name="imageRemove" id="imgRemove2" value="0">
                        <button type="button" id="remove" class="pull-right btn btn-default user-remove-img-btn">
                            <span class="fa fa-remove"></span>
                        </button>
                    </div>
                    <div  style="display:none; color: red;margin-top: 5px; margin-left: 30px; margin-bottom: 10px;" 
                          class="image-error2">Image cannot be blank.</div>
        </div>
    
        <div class=" col-md-12">
            <div class="col-md-6 col-md-offset-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                }
                ?>
                <?php echo Html::a('Cancel', ['homeimage/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>

    </div>
</div>
    <?php ActiveForm::end(); ?>

</div>                        
<?php
if (isset($model->image_name) && !empty($model->image_name)) {
    $mediaFileUrl = dirname(\yii\helpers\Url::base(true)) . '/media/home_image/' . $model->image_name;

    $this->registerJs("
        $(document).ready(function() {
            var client_image_url = 'url($mediaFileUrl)';
            $('#client_image').css('background-image', client_image_url);
        });
    ");
}
$this->registerJs("

 $('.cropme').simpleCropper();  
 
 $('#img').click(function() {    
     var client_img_src =  $('#client_image').children().attr('src');         
     //$('#set_client_img').val(client_img_src);      
     $('#set_img').val(client_img_src);     
     console.log($('#set_img').val());
 });
"); 
$default_img = Yii::$app->urlManager->createAbsoluteUrl("/web/uploads/UploadLight.png");
if (!isset($_GET['id']) && empty($_GET['id'])) {

    $this->registerJs("               
    $('#remove').click(function() {
        $('#client_image img').remove();
        $('#client_image').css('background-image', 'url($default_img)');
    }); 
    
    $('#remove-image').click(function() {
        $('#client_img_src img').remove();
        $('#client_img_src').css('background-image', 'url($default_img)');
    });
    
    $('#user-form').on('submit', function() {  
    
        if ($('#client_image img').length == 0 || $('#image_remove').val() == 1) {
               
            $('#client_image').css('border', '1px solid red');
            $('.image-labe12').css('color', '#dd4b39');
            $('.image-error2').show();
            var a = 1;
        } else {            
            $('#client_image').css('border', '1px solid green');
            $('.image-labe12').css('color', '#00a65a');
            $('.image-error2').hide();
            var a = 2;
        }
//        if ($('#image img').length == 0 || $('#vehicle_photo_remove').val() == 1) {

//            $('#image').css('border', '1px solid red');
//            $('.image-labe12').css('color', '#dd4b39');
//            $('.image-error2').show();
//            var b = 1;
//        } else {
//            $('#image').css('border', '1px solid green');
//            $('.image-labe12').css('color', '#00a65a');
//            $('.image-error2').hide();
//            var b = 2;
//        } 
        
//        if (a == '1' || b == '1') {
        if (a == '1' ) {
            return false;
        } else {
            return true;
        }
    });
  
    ");
} else {
    $this->registerJs("
        $('#remove').click(function() {
           $('#client_image img').remove();
           $('#client_image').css('background-image', 'url($default_img)');
           $('#imgRemove1').val(1);
        });
        $('#remove-image').click(function() {
        alert('asdsad2');
           $('#image img').remove();
           $('#image').css('background-image', 'url($default_img)');
           $('#imgRemove2').val(1);
        });
        
        $('#user-form').on('submit', function() {
        
            if($('#client_image img').length == 0 ) {
                if( $('#client_image').data('image') == 'false'  || $('#imgRemove1').val() == 1 ) {
                    $('#client_image').css('border', '1px solid red');
                    $('.image-labe12').css('color', '#dd4b39');
                    $('.image-error2').show();
                   var a = 1; 
                } else {
                    $('#client_image').css('border', '1px solid green');
                    $('.image-labe12').css('color', '#00a65a');
                    $('.image-error2').hide();
                    var a = 2;
                }
            } else {
                $('#client_image').css('border', '1px solid green');
                $('.image-label2').css('color', '#00a65a');
                $('.image-error2').hide();
                var a = 2;
            }
            

            if($('#image img').length == 0 ) {
                if( $('#image').data('image') == 'false'  || $('#imgRemove2').val() == 1 ) {
                    $('#image').css('border', '1px solid red');
                    $('.image-labe12').css('color', '#dd4b39');
                    $('.image-error2').show();
                   var b = 1; 
                } else {
                    $('#image').css('border', '1px solid green');
                    $('.image-labe12').css('color', '#00a65a');
                    $('.image-error2').hide();
                    var b = 2;
                }
            } else {
                $('#image').css('border', '1px solid green');
                $('.image-label2').css('color', '#00a65a');
                $('.image-error2').hide();
                var b = 2;
            }
            if (a == '1' || b == '1') {
                return false;
            } else {
                return true;
            }
        });
     

");
}
$this->registerJs("
    $('#set_img').val('');      
");



?>

