<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use kartik\file\FileInput;
use yii\helpers\ArrayHelper;
use yii\web\UploadedFile;


$this->title = 'Admin';
$basePath = dirname(\yii\helpers\Url::base(true)) . '/media/home_image/' . $model->image_name;
?>


<!-- /.box-header -->
<!-- form start -->
<div class="box-body"> 

    <div class="user-form">

        <?php
        $form = ActiveForm::begin([
                    'id' => 'user-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
        ]);
        ?>       
        <div class="row">
        <div class="col-md-3">
            <?= $form->field($model, 'name')->textInput(['id'=>'name','autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter  Name']);?>
        </div>
            </div>
        </div>
        <input type="hidden" id="h_img" name="h_img"><?php            
        
        
        echo FileInput::widget([
            'model' => $model,
            'attribute'=>'image_name',
   'name' => 'attachment_49[]',
    'options'=>[
        'multiple'=>false
    ],
    'pluginOptions' => [
        'initialPreview'=>[
            $basePath
        ],
        //'required'=>true,
        'initialPreviewAsData'=>true,
        'initialPreviewConfig' => [
        'overwriteInitial'=> true
        
        ],
       // 'overwriteInitial'=>false,
        'maxFileSize'=>2800
    ]
]);
    ?>
        <div class=" col-md-12">
            <div class="col-md-6 col-md-offset-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                }
                ?>
                <?php echo Html::a('Cancel', ['homeimage/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>

    </div>
</div>
    <?php ActiveForm::end(); ?>

</div>                        
<?php

if (isset($model->image_name) && !empty($model->image_name)) {
    $mediaFileUrl = dirname(\yii\helpers\Url::base(true)) . '/media/home_image/' . $model->image_name;

    $this->registerJs("
        $(document).ready(function() {
            var client_image_url = 'url($mediaFileUrl)';
            $('#client_image').css('background-image', client_image_url);
        });
    ");
}

$default_img = Yii::$app->urlManager->createAbsoluteUrl("/web/uploads/UploadLight.png");

$this->registerJs("
    $(document).ready(function(){
        $('#user-form').on('submit',function(){        
            $('#h_img').val($('.file-preview-image').attr('src'));
        });
    });
    //$('#h_img').val('');      
");



?>

