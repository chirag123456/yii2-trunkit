<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
use common\models\vehiclemakemodel\VehicleMakeModel;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>
<div class="box-header with-border">
    <h3 class="box-title">Add Vehicle Space Size</h3>
</div>
<?php
$form = ActiveForm::begin([
            'id' => 'vehicle-make-model-form',
            'enableAjaxValidation' => true,
            'enableClientValidation' => true,
            'action' => \yii\helpers\Url::to(['vehicle-space-size/add'])
        ]);
?>
<div class="row" style="margin-top: 10px;">
    <div class="col-md-12">
        <div class="col-md-6">
            <?php echo $form->field($model, 'name')->textInput(['maxlength' => true, 'placeholder' => 'Enter Vehicle Space Size', 'autofocus' => true]) ?>
        </div>
        <div class="col-md-6"> 
            <?php
            echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right city-add-button','style'=>'margin-left: 5px;']);
            echo Html::button('Cancel', ['class' => 'btn btn-default pull-right cancel-button remove']);
            ?>                              
        </div>
    </div>
</div>
<?php ActiveForm::end(); ?>

