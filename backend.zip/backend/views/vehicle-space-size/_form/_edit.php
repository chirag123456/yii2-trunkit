<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use common\models\vehiclemakemodel\VehicleMakeModel;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>
<div class="box-header with-border">
    <h3 class="box-title">Update Vehicle Space Size</h3>
</div>
<?php
$form = ActiveForm::begin([
            'id' => 'vehicle-make-model-form',
           'enableAjaxValidation' => true,
           'enableClientValidation' => true,
            'action' => \yii\helpers\Url::to(['vehicle-space-size/update/' . $_GET['id']])
        ]);
?>
<div class="row">
    <div class="col-md-12">
        <div class="col-md-6">
            <?php echo $form->field($model, 'name')->textInput(['maxlength' => true, 'placeholder' => 'Enter Vehicle Space Size']) ?>
        </div>       
        <div class="col-md-6">

            <?php
            echo Html::submitButton('Update ', ['class' => 'btn btn-primary pull-right  create-button','style'=>'margin-left: 5px;']);

            echo Html::a(' Cancel', ['index'], ['class' => 'btn btn-default pull-right  cancel-button']);
            ?>                                

        </div>
    </div>
</div>
<?php ActiveForm::end(); ?>

