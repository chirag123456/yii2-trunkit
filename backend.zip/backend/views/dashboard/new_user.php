<?php
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
?>

<div class="box box-primary">
    <div class="box-header"><h3> New User </h3> </div>
    <!-- /.box-header -->
    <div class="box-body">
        
        <div class="user-index">
            <?php
            $form = \yii\widgets\ActiveForm::begin([
                'method' => 'get', 'id' => 'super'
            ]);
            ?>
            

            <?php ActiveForm::end();
            ?>
            
            <?php Pjax::begin(['id' => 'users']) ?>  
            <?=
            GridView::widget([
                'dataProvider' => $dataProvider,
                'showOnEmpty' => true,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn',
                    'header' => '#ID',
                    'contentOptions' => ['style' => 'width:40px;'],
                    'headerOptions' => ['style' => 'color:#3C8DBC;'],
                ],
                
                [
                    'attribute' => 'first_name',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search By First Name'
                    ],
                ],
                [
                    'attribute' => 'last_name',
                    'label' => 'Last Name',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search By Last Name '
                    ],
                ],
                [
                    'attribute' => 'contact_number',
                    'label' => 'Contact Number',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search By Contact Number'
                    ],
                ],
                [
                    'attribute' => 'email',
                    'label' => 'Email',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search By Email'
                    ],
                ],
                
            ],
        ]);
        ?>
        <?php Pjax::end() ?>

    </div>
    <a href="<?= yii\helpers\Url::to(['/user/index'])?>" class="btn btn-default pull-right">Show More</a>
</div>
</div>