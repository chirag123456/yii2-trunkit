<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
use common\models\relation\TripRequestRelation;

$model = new TripRequestRelation();

?>

<div class="box box-primary">
    <div class="box-header"><h3> New Request</h3></div>
    <div class="box-body">
        
        <div class="user-index">


            <?=
            GridView::widget([
                'dataProvider' => $dataProvider,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],
                    [
                        'attribute' => 'trip_user_id',
                        'label' => 'Trip User Name',
                        'format' => 'raw',
                        'value' => function ($model) {
                         return isset($model->tripuser->first_name)?$model->tripuser->first_name:'N\A';
                     },
                 ],
                 [
                    'attribute' => 'trip_origin',
                    'label' => 'Trip Origin',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search by Starting Point'
                    ],
                ],
                [
                    'attribute' => 'trip_destination',
                    'label' => 'Trip Destination',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search by Destination Point'
                    ],
                ],
                [
                    'attribute' => 'request_user_id',
                    'label' => 'Request User Name',
                    'format' => 'raw',
                    'value' => function ($model) {
                        return isset($model->requestuser->first_name)?$model->requestuser->first_name:'N\A';
                    },
                ],
                [
                    'attribute' => 'request_origin',
                    'label' => 'Request Origin',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search by Starting Point'
                    ],
                ],
                [
                    'attribute' => 'request_destination',
                    'label' => 'Request Destination',
                    'format' => 'raw',
                    'filterInputOptions' => [
                        'class' => 'form-control',
                        'placeholder' => 'Search by Destination Point'
                    ],
                ],
            ],
        ]);
        ?>
    </div>
    <a href="<?= yii\helpers\Url::to(['/post/post-request'])?>" class="btn btn-default pull-right">Show More</a>
</div>
</div>