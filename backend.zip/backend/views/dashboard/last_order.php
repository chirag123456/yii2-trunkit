<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
?>
<div class="box box-primary">
   <div class="box-header">
      <h3> Last Order</h3>
  </div>        
  <div class="box-body">
    
   <div class="user-index">
    <?=
    GridView::widget([
        'dataProvider' => $dataProvider3,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
                'attribute' => 'traking_number',
                'label' => 'Traking Number',
                'format' => 'raw',
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Traking Number'
                ],
            ],
            [
                'attribute' => 'user_id',
                'label' => 'User',
                //'headerOptions' => ['style' => 'color:#3C8DBC;width:70px;'],
                'format' => 'raw',
                'value' => function ($model) {
                    return isset($model->user->first_name) ? $model->user->first_name : 'N\A';
                },
                'filter' => false,
            ],
            [
                'attribute' => 'origin',
                'label' => 'Origin',
                'format' => 'raw',
                'value' => function ($model) {
                    return isset($model->post->origin) ? $model->post->origin : 'N\A';
                },
                'filter' => false,
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Origin'
                ],
            ],
            [
                'attribute' => 'destination',
                'label' => 'Destination',
                'format' => 'raw',
                'value' => function ($model) {
                    return isset($model->post->destination) ? $model->post->destination : 'N\A';
                },
                'filter' => false,
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Destination'
                ],
            ],
            [
                'attribute' => 'order_date',
                'label' => 'Order Date',
                'format' => 'raw',
                'value' => function ($model) {
                    return isset($model->order_date) ? date('M j, Y g:ia', strtotime($model->order_date)) : 'N/A';
                },
                'filter' => false,
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Order Date'
                ],
            ],
            [
                'attribute' => 'order_status',
                'label' => 'Order Status',
                'format' => 'raw',
                'value' => function ($model) {
                    if(isset($model->order_status) && !empty($model->order_status) && strtoupper($model->order_status) == 'INITILISED')
                    {
                        return 'INITIALISED';
                    }
                    elseif (isset($model->order_status) && !empty($model->order_status) && strtoupper($model->order_status) == 'ACCEPT') {
                        # code...
                        return 'ACCEPTED';
                    }
                    else
                    {
                        return $model->order_status;
                    }
                },
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Traking Number'
                ],
            ],
            [
                'attribute' => 'price',
                'label' => 'Price',
                'format' => 'raw',
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Traking Number'
                ],
            ],
        ],
    ]);
    ?>
</div>
<a href="<?= yii\helpers\Url::to(['/order/post-order'])?>" class="btn btn-default pull-right">Show More</a>
</div>
</div>