<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;

//$this->title = 'Admin | Dashboard';
$this->title = 'Trunk It Admin Portal';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<?php //$details = Yii::$app->commonfunction->getDashboardDetails(); ?>

<section class="content-header">  
    <h1>
        Dashboard
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
</section>
<section class="content-header">
  <div class="box box-primary"> 
    <div class="box-body">
        <div class="user-index">
            <div class="row">
              <div class="col-xs-3 pull-right">
                <?php
                    $form = \yii\widgets\ActiveForm::begin([
                        'method' => 'get',
                        'action' => yii\helpers\Url::base() . '/dashboard/index/',
                        'id' => 'super'
                      ]);
                  ?>
                  <select onchange="java_script_:show(this.options[this.selectedIndex].value)" class="form-control">
                    <option value="All">All</option>
                    <option value="Daily">Daily</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Yearly">Yearly</option>
                  </select>
                <?php ActiveForm::end();?>
              </div>
            </div>
        </div>
    </div>
  </div>
</section>

<SCRIPT>  
  function show(select_item) {
      if (select_item == "Daily") {
        hiddenDiv1.style.visibility='visible';
        hiddenDiv1.style.display='block';
        hiddenDiv2.style.visibility='hidden';
        hiddenDiv2.style.display='none';
        hiddenDiv3.style.visibility='hidden';
        hiddenDiv3.style.display='none';
        hiddenDiv4.style.visibility='hidden';
        hiddenDiv4.style.display='none';
        hiddenDiv5.style.visibility='hidden';
        hiddenDiv5.style.display='none';
        Form.fileURL.focus();
    } else if(select_item == "Weekly"){
        hiddenDiv5.style.visibility='visible';
        hiddenDiv5.style.display='block';
        hiddenDiv2.style.display='none';
        hiddenDiv3.style.visibility='hidden';
        hiddenDiv1.style.visibility='hidden';
        hiddenDiv1.style.display='none';
        hiddenDiv3.style.visibility='hidden';
        hiddenDiv3.style.display='none';
        hiddenDiv4.style.visibility='hidden';
        hiddenDiv4.style.display='none';
        Form.fileURL.focus();
    }else if(select_item == "Monthly"){
        hiddenDiv2.style.visibility='visible';
        hiddenDiv2.style.display='block';
        hiddenDiv1.style.visibility='hidden';
        hiddenDiv1.style.display='none';
        hiddenDiv3.style.visibility='hidden';
        hiddenDiv3.style.display='none';
        hiddenDiv4.style.visibility='hidden';
        hiddenDiv4.style.display='none';
        hiddenDiv5.style.visibility='hidden';
        hiddenDiv5.style.display='none';
        Form.fileURL.focus();
    }else if(select_item == "Yearly"){
        hiddenDiv3.style.visibility='visible';
        hiddenDiv3.style.display='block';
        hiddenDiv2.style.visibility='hidden';
        hiddenDiv2.style.display='none';
        hiddenDiv1.style.visibility='hidden';
        hiddenDiv1.style.display='none';
        hiddenDiv4.style.visibility='hidden';
        hiddenDiv4.style.display='none';
        hiddenDiv5.style.visibility='hidden';
        hiddenDiv5.style.display='none';
        Form.fileURL.focus();
    }else{
      hiddenDiv1.style.visibility='hidden';
      hiddenDiv1.style.display='none';
      hiddenDiv2.style.visibility='hidden';
      hiddenDiv2.style.display='none';
      hiddenDiv3.style.visibility='hidden';
      hiddenDiv3.style.display='none';
      hiddenDiv4.style.visibility='visible';
      hiddenDiv4.style.display='block';
      hiddenDiv5.style.visibility='hidden';
      hiddenDiv5.style.display='none';
    }
  } 
</SCRIPT>  


<div id='hiddenDiv1' style="display: none;">
    <section class="content-header">
     <div class="box box-primary"> 
      <div class="box-body">
        <div class="user-index">
          <div class="row">
            <div class="col-lg-3 col-xs-12">

              <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>"><div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo $details['details']['daily_user'] ?></h3>
                  <p>Total Users</p>
                </div>
                <div class="icon">
                  <span class="ion ion-ios-people-outline"></span>
                </div>

              </div>
            </a>
          </div>
          <div class="col-lg-3 col-xs-12">
           <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-trip") ?>">
            <div class="small-box bg-green">
              <div class="inner">
                <h3><?php  echo $details['details']['daily_trip'] ?></h3>

                <p>Total Trip</p>
              </div>

              <div class="icon">
                <span class="fa fa-suitcase"></span>
              </div>

            </div>
          </a>

        </div>

        <div class="col-lg-3 col-xs-12">
          <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-request") ?>">
            <div class="small-box bg-green">
              <div class="inner">
                <h3><?php  echo $details['details']['daily_request'] ?></h3>

                <p>Total Request</p>
              </div>
              <div class="icon">
                <span class="fa fa-truck"></span>
              </div>

            </div>
          </a>
        </div>
        <div class="col-lg-3 col-xs-12">
         <a href="#">
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php  echo "$".$details['details']['daily_income'] ?></h3> 

              <p>Total Income</p>
            </div>
            <div class="icon">
              <span class="fa fa-money"></span>
            </div>

          </div>
        </a>
      </div>

    </div>

  </div>
</div>
</div>
</section>
</div>

<div id='hiddenDiv2' style="display: none">
<section class="content-header">
 <div class="box box-primary"> 
    <div class="box-body">
        <div class="user-index">
            <div class="row">
                <div class="col-lg-3 col-xs-12">

                    <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>"><div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php echo $details['details']['monthly_user'] ?></h3>
                            <p>Total Users</p>
                        </div>
                        <div class="icon">
                            <span class="ion ion-ios-people-outline"></span>
                        </div>

                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-xs-12">
             <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-trip") ?>">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?php  echo $details['details']['monthly_trip'] ?></h3>

                        <p>Total Trip</p>
                    </div>

                    <div class="icon">
                        <span class="fa fa-suitcase"></span>
                    </div>

                </div>
            </a>

        </div>

        <div class="col-lg-3 col-xs-12">
          <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-request") ?>">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?php  echo $details['details']['monthly_request'] ?></h3>

                    <p>Total Request</p>
                </div>
                <div class="icon">
                    <span class="fa fa-truck"></span>
                </div>

            </div>
        </a>
    </div>
    <div class="col-lg-3 col-xs-12">
     <a href="#">
        <div class="small-box bg-green">
            <div class="inner">
                <h3><?php  echo "$".$details['details']['monthly_income'] ?></h3> 

                <p>Total Income</p>
            </div>
            <div class="icon">
                <span class="fa fa-money"></span>
            </div>

        </div>
    </a>
</div>

</div>

</div>
</div>
</div>
</section>
</div>

<div id='hiddenDiv3' style="display: none">
  <section class="content-header">
 <div class="box box-primary"> 
    <div class="box-body">
        <div class="user-index">
            <div class="row">
                <div class="col-lg-3 col-xs-12">

                    <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>"><div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php echo $details['details']['yearly_user'] ?></h3>
                            <p>Total Users</p>
                        </div>
                        <div class="icon">
                            <span class="ion ion-ios-people-outline"></span>
                        </div>

                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-xs-12">
             <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-trip") ?>">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?php  echo $details['details']['yearly_trip'] ?></h3>

                        <p>Total Trip</p>
                    </div>

                    <div class="icon">
                        <span class="fa fa-suitcase"></span>
                    </div>

                </div>
            </a>

        </div>

        <div class="col-lg-3 col-xs-12">
          <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-request") ?>">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?php  echo $details['details']['yearly_request'] ?></h3>

                    <p>Total Request</p>
                </div>
                <div class="icon">
                    <span class="fa fa-truck"></span>
                </div>

            </div>
        </a>
    </div>
    <div class="col-lg-3 col-xs-12">
     <a href="#">
        <div class="small-box bg-green">
            <div class="inner">
                <h3><?php  echo "$".$details['details']['yearly_income'] ?></h3> 

                <p>Total Income</p>
            </div>
            <div class="icon">
                <span class="fa fa-money"></span>
            </div>

        </div>
    </a>
</div>

</div>

</div>
</div>
</div>
</section>
</div>

<div id='hiddenDiv4'>
<section class="content-header">
 <div class="box box-primary"> 
    <div class="box-body">
        <div class="user-index">
            <div class="row">
                <div class="col-lg-3 col-xs-12">

                    <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>"><div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php echo $details['details']['total_User'] ?></h3>
                            <p>Total Users</p>
                        </div>
                        <div class="icon">
                            <span class="ion ion-ios-people-outline"></span>
                        </div>

                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-xs-12">
             <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-trip") ?>">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?php  echo $details['details']['total_intrip_post'] ?></h3>

                        <p>Total Trip</p>
                    </div>

                    <div class="icon">
                        <span class="fa fa-suitcase"></span>
                    </div>

                </div>
            </a>

        </div>

        <div class="col-lg-3 col-xs-12">
          <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-request") ?>">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?php  echo $details['details']['total_Request_post'] ?></h3>

                    <p>Total Request</p>
                </div>
                <div class="icon">
                    <span class="fa fa-truck"></span>
                </div>

            </div>
        </a>
    </div>
    <div class="col-lg-3 col-xs-12">
        <div class="small-box bg-green">
            <div class="inner">
                <h3><?php  echo "$".$details['details']['total_income'] ?></h3> 

                <p>Total Income</p>
            </div>
            <div class="icon">
                <span class="fa fa-money"></span>
            </div>

        </div>
  </div>

</div>

</div>
</div>
</div>
</section>
</div>

<div id='hiddenDiv5' style="display: none;">
  <section class="content-header">
 <div class="box box-primary"> 
    <div class="box-body">
        <div class="user-index">
            <div class="row">
                <div class="col-lg-3 col-xs-12">

                    <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>"><div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php echo $details['details']['weekly_user'] ?></h3>
                            <p>Total Users</p>
                        </div>
                        <div class="icon">
                            <span class="ion ion-ios-people-outline"></span>
                        </div>

                    </div>
                </a>
            </div>
            <div class="col-lg-3 col-xs-12">
             <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-trip") ?>">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?php  echo $details['details']['weekly_trip'] ?></h3>

                        <p>Total Trip</p>
                    </div>

                    <div class="icon">
                        <span class="fa fa-suitcase"></span>
                    </div>

                </div>
            </a>

        </div>

        <div class="col-lg-3 col-xs-12">
          <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-request") ?>">
            <div class="small-box bg-green">
                <div class="inner">
                    <h3><?php  echo $details['details']['weekly_request'] ?></h3>

                    <p>Total Request</p>
                </div>
                <div class="icon">
                    <span class="fa fa-truck"></span>
                </div>

            </div>
        </a>
    </div>
    <div class="col-lg-3 col-xs-12">
     <a href="#">
        <div class="small-box bg-green">
            <div class="inner">
                <h3><?php  echo "$".$details['details']['weekly_income'] ?></h3> 

                <p>Total Income</p>
            </div>
            <div class="icon">
                <span class="fa fa-money"></span>
            </div>

        </div>
    </a>
</div>

</div>

</div>
</div>
</div>
</section>
</div>

<section class="content">

    <div class="row">
        <div class="col-xs-12">
           <?=
           $this->render('new_request', [
               'dataProvider' => $dataProvider2,
           ])
           ?>
       </div>
       <div class="col-xs-12">
         <?=
         $this->render('new_trip', [
             'dataProvider' => $dataProvider1, 
         ])
         ?>
      </div>
      <div class="col-xs-12">
           <?=
           $this->render('last_item', [
               'dataProvider4' => $dataProvider4, 
           ])
           ?>
       </div>
       <div class="col-xs-12">
       <?=
       $this->render('new_user', [
           'dataProvider' => $dataProvider,
       ])
       ?>
   </div>
   <div class="col-xs-12">
       <?=
       $this->render('last_order', [
           'dataProvider3' => $dataProvider3,
       ])
       ?>
   </div>

</div>
</section>



