<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
?>
<div class="box box-primary">
  <div class="box-header">
      <h3> New Item</h3>
  </div>           
  <div class="box-body">
   
   <div class="user-index">
    <?=
    GridView::widget([
        'dataProvider' => $dataProvider4,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
                'attribute' => 'user_id',
                'label' => 'User Name',
                //'headerOptions' => ['style' => 'color:#3C8DBC;width:70px;'],
                'format' => 'raw',
                'value' => function ($model) {
                    return isset($model->user->first_name) ? $model->user->first_name : 'N\A';
                },
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by User'
                ],
            ],
            [
                'attribute' => 'origin',
                'label' => 'Origin',
                'format' => 'raw',
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Starting Point'
                ],
            ],
            [
                'attribute' => 'destination',
                'label' => 'Destination',
                'format' => 'raw',
                'filterInputOptions' => [
                    'class' => 'form-control',
                    'placeholder' => 'Search by Destination Point'
                ],
            ],
            [
                'attribute' => 'departure_date',
                'format' => 'raw',
                'value' => function($model) {
                    //return date('d/m/Y', strtotime($model->departure_date));
                    return isset($model->departure_date) ? date('d/m/Y', strtotime($model->departure_date)) : 'N\A';
                },
                'filter' => false
            ],
            
        ],
    ]);
    ?>
</div>
<a href="<?= yii\helpers\Url::to(['/post/post-request'])?>" class="btn btn-default pull-right">Show More</a>
</div>
</div>