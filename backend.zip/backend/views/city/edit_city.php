<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\models\Country */
?>

<section class="content-header">
      <h1>
        City
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-dashboard"></i> Home</a></li>
       <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("city/index") ?>" >City</a></li>
        <li class="active">Edit City</li>
      </ol>
  </section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
          <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Edit City</h3>
                  <a href="<?= yii\helpers\Url::to(['city/index'])?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>
                  <div class="country-create">


                        <?= $this->render('_edit_form', [
                            'model' => $model,
                        ]) ?>

                    </div>
            </div></div></div></section>
