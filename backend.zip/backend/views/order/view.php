<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;
//echo $_REQUEST['pending-payment'];

?>

<div class="order-create">
    <section class="content-header">
        <h1> Order Management </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="<?php echo \Yii::$app->urlManager->createUrl("order/post-order") ?>" >Order Management</a></li>
            <li class="active">View</li>
        </ol>
    </section>
    <section class="content">

        <div class="row">
            <div class="col-md-12">

                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><b>Order #<?php echo $model->traking_number; ?> on <?php if($model->order_date!=''){echo date('M j, Y g:ia', strtotime($model->order_date));}else{echo 'N/A';} ?></b></h3> 
                        <?php if(isset($_REQUEST['pending-payment']) && $_REQUEST['pending-payment']==1){?>
                            <a href="<?php echo yii\helpers\Url::to(['order/pending-payment']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                        <?php }else{?>
                            <a href="<?php echo yii\helpers\Url::to(['order/post-order']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                        <?php } ?>
                    </div>

                    <div class="box-body"> 

                        <div class="order-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <h4>Order Details</h4> 

                                    <?php $or_date = '';
                                    echo
                                    DetailView::widget([
                                        'model' => $model,
                                        'attributes' => [
                                            [
                                                'attribute' => 'traking_number',
                                                'label' => 'Tracking Number',
                                                'format' => ['raw', ['style' => 'width:100px;']],
                                            ],
                                            [
                                                'attribute' => 'order_date',
                                                'label' => 'Order Date',
                                                'format' => 'raw',
                                                'value' => function ($model) {
                                                    //return isset($model->order_date) ? date('M j, Y g:ia', strtotime($model->order_date)) : 'N/A';
                                                    return isset($model->order_date)?date('Y-m-d', strtotime($model->order_date)):'N\A';
                                                },
                                            ],
                                            [
                                                'attribute' => 'price',
                                                'label' => 'Total Price',
                                                'format' => 'raw',
                                                'value' => isset($model->price) ? $model->price : 'N/A',
                                            ],
                                            /*[
                                                'attribute' => 'tax',
                                                'label' => 'Tax',
                                                'format' => 'raw',
                                                'value' => isset($model->tax) ? $model->tax : 'N/A',
                                            ],
                                            [
                                                'attribute' => 'discount',
                                                'label' => 'Discount',
                                                'format' => 'raw',
                                                'value' => isset($model->discount) ? $model->discount : 'N/A',
                                            ],
                                            [
                                                'attribute' => 'total_price',
                                                'label' => 'Total Price',
                                                'format' => 'raw',
                                                'value' => isset($model->total_price) ? $model->total_price : 'N/A',
                                            ],*/
                                            [
                                                'attribute' => 'order_status',
                                                'label' => 'Order Status',
                                                'format' => 'raw',
                                                'value' => isset($model->order_status) ? $model->order_status : 'N/A',  
                                            ],
                                            [
                                                'attribute' => 'payment_status',
                                                'label' => 'Payment Status',
                                                'format' => 'raw',
                                                'value' => isset($model->payment_status) ? $model->payment_status : 'N/A',
                                            ],
                                        ],
                                    ]);
                                    ?>
                                </div>
                                <div class="col-md-6">
                                    <h4>User Details</h4>
                                    <?php
                                    echo
                                    DetailView::widget([
                                        'model' => $model,
                                        'attributes' => [
                                            [
                                                'attribute' => 'user_id',
                                                'label' => 'User Name',
                                                'format' => 'raw',
                                                'value' => function ($model) {
                                                    //return isset($model->user->username)?$model->user->username:'N\A';
                                                    if (isset($model->user->first_name)) {
                                                        return isset($model->user->first_name) ? $model->user->first_name : 'N\A';
                                                    } else {
                                                        return isset($model->client->username) ? $model->client->username : 'N\A';
                                                    }
                                                },
                                            ],
                                            [
                                                'label' => 'Image',
                                                'format' => 'raw',
                                                'value' => function ($model) {
                                                    //$imgUrl = dirname(Url::base(true)) . '/uploads/user/' . (isset($model->user->image) ? $model->user->image : 'default_user.png');
                                                    $mediaFileUrl = Yii::$app->request->hostInfo . USER_PROFILE_PATH . (isset($model->user->image) ? $model->user->image : 'default_user.png');
                                                    
                                                    return '<img data-toggle="tooltip" alt="User Image" src="' . $mediaFileUrl . '" style="width:50px;height:50px;border-radius: 25px;">';
                                                },
                                            ],
                                            [
                                                'label' => 'User Email',
                                                'format' => 'raw',
                                                'value' => function ($model) {
                                                    return isset($model->user->email) ? $model->user->email : 'N\A';
                                                },
                                            ],
                                            [
                                                'label' => 'User Contact No.',
                                                'format' => 'raw',
                                                'value' => function ($model) {
                                                    return isset($model->user->contact_number) ? $model->user->contact_number : 'N\A';
                                                },
                                            ],
                                        ],
                                    ]);
                                    ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h4>Trip Details</h4>
                                    <?php
                                    echo
                                    DetailView::widget([
                                        'model' => $model,
                                        'attributes' => [
                                            [
                                                'label' => 'Origin',
                                                'format' => 'raw',
                                                'value' => function ($model) {
                                                    return isset($model->post->origin) ? $model->post->origin : 'N\A';
                                                },
                                            ],
                                            [
                                                'label' => 'Destination',
                                                'format' => 'raw',
                                                'value' => function ($model) {
                                                    return isset($model->post->destination) ? $model->post->destination : 'N\A';
                                                },
                                            ],
                                            
                                        ],
                                    ]);
                                    ?>

                                </div>
                                <div class="col-md-6">
                                    <h4>Trip Map</h4>                    
                                    <input type="hidden" id="origin-input" name="origin" value="<?= isset($model->post->origin) ? $model->post->origin : 'N\A'; ?>">
                                    <input type="hidden" id="destination-input" name="origin" value="<?= isset($model->post->destination) ? $model->post->destination : 'N\A' ?>">
                                      <div class="detail-trip-map-img">
                                        <div class="detail-trip-map-img" id="googleMap" style="width:100%;height:200px;">              
                                        </div>
                                      </div>
                                </div>
                            </div>
                        </div>   		
                    </div>        
                </div>
            </div>
        </div> 
    </section> 
</div>
<?php
$map_api_key = \backend\components\CommonFunctions::getConfigureValueByKey('MAP_API_KEY');
$this->registerJsFile(Yii::$app->homeUrl . 'resource/post/view-tripdetail.js', ['depends' => 'yii\web\JqueryAsset']);
$this->registerJsFile('https://maps.googleapis.com/maps/api/js?key='.$map_api_key.'&region=CA&libraries=places&callback=initMap', ['depends' => 'yii\web\JqueryAsset']);
?>