<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
?>
 <div class="login-logo">
    <b>Change-Password</b>
 </div>
<div class="row">
<div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
                 <?php $form = ActiveForm::begin([
                    'id'=>"change-password",
                    'enableAjaxValidation' => true,
                    'enableClientValidation'=>true]); ?>              
            <div class="box-body">
                <div class="form-group">
                    <?= $form->field($model, 'old_password')->passwordInput(['maxlength' => true]) ?>
                </div>
                <div class="form-group">
                    <?= $form->field($model, 'new_password')->passwordInput(['maxlength' => true]) ?>
                </div>
                <div class="form-group">
                    <?= $form->field($model, 'confirm_password')->passwordInput(['maxlength' => true]) ?>
                </div>
                    <?= Html::submitButton("Change Password", ['class' => 'btn btn-primary submit']); ?>

            </div>
            <div class="box-footer">
            </div>
                <?php ActiveForm::end(); ?>
          </div>
</div>
</div>