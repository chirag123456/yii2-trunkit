<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

            <div class="box-body">
                <div class="user-form">

                    <?php
                    $form = ActiveForm::begin([
                                'id' => 'settings-form',
                                'enableAjaxValidation' => true,
                                'enableClientValidation' => true,
                                'options' => ['enctype' => 'multipart/form-data']
                    ]);
                    ?>

                    <div class="row">
                        <div class="col-md-12">
                            <?php
                            $settings = \common\models\Settings::find()->all();
                            $data = $settings[0]['paging'];
                          ?>

                            <div class="col-md-6">                                  

                                <?= $form->field($model, 'paging')->dropdownList(['10' => '10', '20' => '20', '50' => '50', '100' => '100']) ?> 

                            </div>
                            <div class="col-md-6">
                                <?= $form->field($model, 'from_email')->textInput(['maxlength' => true]) ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <?= $form->field($model, 'to_email')->textInput(['maxlength' => true]) ?>
                            </div>
                            <div class="col-md-6">
                                <?= $form->field($model, 'cc_email')->textInput(['maxlength' => true]) ?>
                            </div>

                        </div>
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <?= $form->field($model, 'bcc_email')->textInput(['maxlength' => true]) ?>
                            </div>
                            <div class="col-md-6">
                                <?= $form->field($model, 'smtp_host')->textInput(['maxlength' => true]) ?>
                            </div>

                        </div>                                      
                        <div class="col-md-12">
                            <div class="col-md-4">
                                <?= $form->field($model, 'smtp_port')->textInput(['maxlength' => true]) ?>
                            </div>
                            <div class="col-md-4">
                                <?= $form->field($model, 'smtp_username')->textInput(['maxlength' => true]) ?>
                            </div>
                            <div class="col-md-4">
                                <?= $form->field($model, 'smtp_password')->textInput(['maxlength' => true]) ?>
                            </div>
                        </div>

                        <div class="col-md-12">                                
                            <div class="col-md-12">                                
                                <?php
                                if (isset($_GET['id']) && !empty($_GET['id'])) {
                                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                                } else {
                                    echo Html::submitButton('Create', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                </div>
                <?php ActiveForm::end(); ?>

            </div>                        
