<?php
/* @var $this yii\web\View */

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;

/* @var $this yii\web\View */
/* @var $searchModel common\models\search\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = 'Admin';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
        User
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">User</li>
    </ol>
</section>
<section class="content">
    <!-- Small boxes (Stat box) -->

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <!-- /.box-header -->
                <div class="box-body">
                    <div class="user-index">
                       <p>
                            <?= Html::a('Add User', ['add'], ['class' => 'btn btn-primary']) ?>
                        </p>
                        <?php Pjax::begin(['id' => 'users']) ?>  
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'showOnEmpty' => true,
                            'columns' => [
                                [   'attribute' => 'id',
                                    'label' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC', 'style' => 'width:100px'],
                                    'template' => '{update} {status} {delete}',
                                    'buttons' => [
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                        'data-confirm' => DELETESTATUS . " user?", // <-- confirmation works...
                                                        'data-method' => 'post',
                                                        'class' => 'delete',
                                            ]);
                                        }
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'status') {
                                            return \yii\helpers\Url::toRoute(['user/status/' . $key]);
                                        } else if ($action === 'update') {
                                            return \yii\helpers\Url::toRoute(['settings/update/' . $key]);
                                        } else if ($action === 'delete') {
                                            return \yii\helpers\Url::toRoute(['user/delete/' . $key]);
                                        } else if ($action === 'change-password') {
                                            return \yii\helpers\Url::toRoute(['user/delete/' . $key]);
                                        }
                                    }
                                ],
                                'paging',
                          
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
$this->registerJs("
   $(document).on('ready pjax:success', function () {
    $('.ajaxStatus').on('click', function (e) {
        e.preventDefault();
        var Url     = $(this).attr('status-url');
        var pjaxContainer = $(this).attr('pjax-container');
            $.ajax({
                    url:   Url,
                    type:  'post',
                }).done(function (data) {
                  $.pjax.reload({container: '#' + $.trim(pjaxContainer)});
                });

    });
});
");
?>