<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

$this->title = 'Admin';
?>
<div class="box-body"> 

    <div class="user-form">

        <?php
        $form = ActiveForm::begin([
                    'id' => 'user-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
        ]);
        ?>

        <div class="row">
            <div class="col-md-12">
                <div class="col-md-4">
                    <?= $form->field($model, 'name')->textInput(['autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter Name']) ?>
                </div>
            </div>

            <div class=" col-md-12">                  
              <div class="col-md-12">
               <?php echo $form->field($model, 'content')->textarea(['autofocus' => true,'maxlength' => 50, 'placeholder' => 'Enter content' , 'autofocus'=>true,'required'=> true]) ?>    
               </div>                        
            </div>
		 
        </div>
        <div class=" col-md-12">
            <div class="col-md-6 col-md-offset-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                }
                ?>
                <?php echo Html::a('Cancel', ['cms/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>

    </div>
    <?php ActiveForm::end(); ?>

</div>                        

<?php
$this->registerJsFile(Yii::$app->homeUrl . 'web/plugins/ckeditor/ckeditor.js', ['depends' => 'yii\web\JqueryAsset']);

$this->registerJs("
  $('.cke_source').prop('required',true);
    var editor1 = CKEDITOR.replace('cmsform-content', 
                                     {
                                      extraAllowedContent: 'div',
                                      height: 250,
                                      enterMode : CKEDITOR.ENTER_BR,
                                      shiftEnterMode: CKEDITOR.ENTER_P
                                      });
                                      editor1.on('instanceReady', function () {

                                      this.dataProcessor.writer.selfClosingEnd = '>';

                                     var dtd = CKEDITOR.dtd;
                                    for (var e in CKEDITOR.tools.extend({})) {
                                    this.dataProcessor.writer.setRules(e, {
                                        indent: true,
                                        breakBeforeOpen: true,
                                        breakAfterOpen: true,
                                        breakBeforeClose: true,
                                        breakAfterClose: true
                                         });
                                         }       
                                         this.setMode('source');
                                          });
                                  
    ");
?>



