<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;
use common\models\vehiclecolor\VehicleColor;
use common\models\post\Post;
use common\models\post\PostOrder;
use common\models\post\PostTripAccept;
use common\models\vehiclemakemodel\VehicleMakeModel;
use common\models\uservehicle\UserVehicle;


?>

<div class="order-create">
<section class="content-header">
    <h1> Trip Management </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-trip") ?>" >Trip Management</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content">
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Trip Management Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['post/post-trip']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">
								<?php
$price =  $model->qtyprice->small_item + $model->qtyprice->medium_item + $model->qtyprice->large_item + $model->qtyprice->xlarge_item;
$Qty =  $model->qtyprice->small_item_qty + $model->qtyprice->medium_item_qty + $model->qtyprice->large_item_qty + $model->qtyprice->xlarge_item_qty;
//.'+'.$model->qtyprice->large_item.'+'.$model->qtyprice->xlarge_item;
?>
                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [
                                    [
                                    'attribute' => 'origin',
                                    'label' => 'Origin',   
                                    'format' => 'raw',
                                ], 
                                [
                                    'attribute' => 'destination',
                                    'label' => 'Destination',   
                                    'format' => 'raw',
                                ],
                                [
                                    'attribute' => 'user_id',
                                    'label' => 'User Name',
                                    'format' => 'raw',
                                    'value' => isset($model->user->first_name) ? $model->user->first_name : 'N/A',
                                    
                                ],
                                [
                                    'attribute' => 'departure_date',
                                    'label' => 'Departure Date',
                                    'format' => 'raw',  
                                ],                               
                                [
                                    'label' => 'Vehicle Color',
                                    'format' => 'raw', 
                                    'value' => isset($model->vehiclecolor->name) ? $model->vehiclecolor->name : 'N/A', 
                                ],
                                [                                    
                                    'label' => 'Plate Number',
                                    'format' => 'raw', 
                                    'value' => isset($model->posttripvehicle->plate_number) ? $model->posttripvehicle->plate_number : 'N/A', 
                                ],
                                [                                    
                                    'label' => 'Vehicle Type',
                                    'format' => 'raw', 
                                    'value' => isset($model->vehiclecolor->name) ? $model->vehiclecolor->name : 'N/A',  
                                ],								                                
                                 [
                                    'label' => 'Model',
                                    'format' => 'raw',
                                    'value' => isset($model->Vehiclemodel->make_model_name) ? $model->Vehiclemodel->make_model_name : 'N/A',                                       
                                ],                                                     
                                 [                                   
                                    'label' => 'Price',
                                    'format' => 'raw',
                                    'value' =>$price ,                                     
                                ],
								[                                  
                                    'label' => 'Quantity',
                                    'format' => 'raw',
                                    'value' =>$Qty ,                                   
                                ],

                                [
                                    'label' => 'Image 1',
                                    'format' => 'raw',
                                    'value'=> $model->posttripimageurl1,
                                ],

                                [
                                    'label' => 'Image 2',
                                    'format' => 'raw',
                                    'value'=> $model->posttripimageurl2,
                                ],

                             ],
                        ]);
                        ?>
                    </div>   		
                </div>
				
            </div>
        </div>
    </div> 
	
</section> 
</div>

<?php
$this->registerJs("
     var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
    ");


//$this->registerJs("var date  = '" . $date . "';", \yii\web\View::POS_BEGIN);
$this->registerJs(\yii\web\View::POS_BEGIN);

$this->registerCssFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.css');
$this->registerCssFile('http://www.jqueryscript.net/css/jquerysctipttop.css');

$this->registerJsFile(Yii::$app->homeUrl . 'resource/drivers/views.js', ['depends' => 'yii\web\JqueryAsset']);
$this->registerJsFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.js', ['depends' => 'yii\web\JqueryAsset']);
?>