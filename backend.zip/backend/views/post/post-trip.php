<?php
use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

$this->title = 'Admin';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
     Post Trip's
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Post Trip's</li>
    </ol>
</section>
<section class="content">

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <div class="box-body">
                    <div class="user-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                        $settings = \common\models\Settings::find()->one();                      
                        $pagesize = $settings['config_value'];
                        ?>
                        <?php // echo $this->render('_search', ['model' => $searchModel]);      ?>
                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>
                        <p>
                            <?php echo Html::a('Reset', ['/post/post-trip'], ['class' => 'btn btn-primary filter-reset']) ?>
                        </p>
                        <?php Pjax::begin(['id' => 'users']) ?>  
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'columns' => [
                                [   'attribute' => 'id',
                                    'label' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
                                [
                                    'attribute' => 'user_id',
                                    'label' => 'User',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                            return isset($model->user->first_name)?$model->user->first_name:'N\A';
                                    },
                                    'filterInputOptions' => [
                                        'class'=>'form-control',
                                        'placeholder' => 'Search by User'
                                    ],
                                ],
                                [
                                    'attribute' => 'origin',
                                    'label' => 'Origin',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class'=>'form-control',
                                        'placeholder' => 'Search by Starting Point'
                                    ],
                                ],
                                [
                                    'attribute' => 'destination',
                                    'label' => 'Destination',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class'=>'form-control',
                                        'placeholder' => 'Search by Destination Point'
                                    ],
                                ],                               
                                
                                [
                                    'attribute' => 'departure_date',
                                    'format' => 'raw',
                                    'value' => function($model) {
                                        return isset($model->departure_date)?date('Y-m-d', strtotime($model->departure_date)):'N\A';
                                    },
                                    'filter' => false
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{view} {location}',
                                    'buttons' => [
                                        'status' => function ($url, $model) {
                                            if ($model->is_active == ACTIVE) {
                                                return Html::a('<span class="glyphicon glyphicon-remove-circle" style="color:#d9534f"></span>', $url, [
                                                            'class' => '',
                                                            'data-confirm' => INACTIVESTATUS, // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'InActive'
                                                ]);
                                            } else {
                                                return Html::a('<span class="glyphicon glyphicon-ok-circle" style="color:#5cb85c"></span>', $url, [
                                                            'data-confirm' => ACTIVESTATUS, // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Active'
                                                ]);
                                            }
                                        },
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                        'data-confirm' => DELETESTATUS, // <-- confirmation works...
                                                        'data-method' => 'post',
                                                        'class' => 'delete',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Delete',
                                            ]);
                                        },
                                        'update' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Edit',
                                            ]);
                                        },										
										
                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', 
                                                    ['post/view-trip/' . $model->id], [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'View',
                                            ]);
                                        },
										
										'location' => function ($url, $model) {
                                        return Html::a('<span class="glyphicon glyphicon-map-marker" style="color:#3c8dbc;"></span>', '#', [
                                                    'class' => 'popup-map-passenger-archive',
                                                    'data-toggle' => 'tooltip',
                                                    'title' => 'Location',
                                                    'data-toggle' => 'modal',
                                                    'data-target' => '#myModal',
                                                    'data-value' => $model->origin,
                                                    'data-value1' => $model->destination,
                                                    'data-url' => Url::to(['post/get-trip-details/' . $model->id])  
                                        ]);
                                    },										
										
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'status') {
                                            return \yii\helpers\Url::toRoute(['user/status/' . $key]);
                                        } else if ($action === 'update') {
                                            return \yii\helpers\Url::toRoute(['user/update/' . $key]);
                                        } else if ($action === 'delete') {
                                            return \yii\helpers\Url::toRoute(['user/delete/' . $key]);
                                        } else if ($action === 'change-password') {
                                            return \yii\helpers\Url::toRoute(['user/delete/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
	    
</section> 
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Trip Enroute</h4>
            </div>
            <div class="modal-body" id="google-map">
                <div id="directions" style="width:500px;height:500px;float:left"></div>

                <div id="googleMap" class="custom-map-modal" style="overflow: hidden;"  ></div>
            </div>
        </div>

    </div>
</div>
<style type="text/css">
    .custom-map-modal {
    position: absolute;
    overflow: hidden;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
.modal-body {
    position: relative;
    padding: 15px;
    min-height: 82vh;
}
</style>

<?php
$map_api_key = \backend\components\CommonFunctions::getConfigureValueByKey('MAP_API_KEY');
//$this->registerJsFile(Yii::$app->homeUrl . 'resource/post/post-trip.js?v=010101', ['depends' => 'yii\web\JqueryAsset']);
//$this->registerJsFile('https://maps.googleapis.com/maps/api/js?key='.$map_api_key.'&libraries=places', ['depends' => 'yii\web\JqueryAsset']); //AIzaSyDV0hzpMzB9qDYi0xpyuy9AEXfiIbUvdFU
$this->registerJsFile('https://maps.googleapis.com/maps/api/js?key='.$map_api_key.'&region=CA&libraries=places', ['depends' => 'yii\web\JqueryAsset']);
$this->registerJsFile(Yii::$app->homeUrl . 'resource/post/post-trip.js', ['depends' => 'yii\web\JqueryAsset']); 
?>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
<?php
$this->registerJs("
   $(document).on('ready pjax:success', function () {
    $('.ajaxStatus').on('click', function (e) {
        e.preventDefault();
        var Url     = $(this).attr('status-url');
        var pjaxContainer = $(this).attr('pjax-container');
            $.ajax({
                    url:   Url,
                    type:  'post',
                }).done(function (data) {
                  $.pjax.reload({container: '#' + $.trim(pjaxContainer)});
                });

    });
});
");
?>
<?php
$this->registerJs("
    $('.add-button').on('click', function (e) {
        $(this).hide();
        $('.add-custom-popup-form').show();
    });
    $('.remove').on('click', function (e) {
        $('.add-custom-popup-form').hide();
        $('.add-button').show();
    });
");
?>