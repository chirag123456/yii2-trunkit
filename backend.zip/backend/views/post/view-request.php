<?php
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;
use common\models\post\Post;


?>

<div class="order-create">
<section class="content-header">
    <h1> Request Management </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-request") ?>" >Request Management</a></li>
        <li class="active">View</li>
    </ol>
</section>
<section class="content">
    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Request Management Details</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['post/post-request']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">
                    
                    <div class="order-form">
                        <?php 
                        echo 
                        DetailView::widget([
                                'model' => $model,
                                'attributes' => [

                                    [
                                    'attribute' => 'origin',
                                    'label' => 'Origin',   
                                    'format' => 'raw',
                                ], 
                                [
                                    'attribute' => 'destination',
                                    'label' => 'Destination',   
                                    'format' => 'raw',
                                ], 
                                [
                                    'attribute' => 'user_id',
                                    'label' => 'User Name',
                                    'format' => 'raw',
                                    'value' => isset($model->user->first_name) ? $model->user->first_name : 'N/A',
                                    
                                ],
                                
                                 
                                [
                                    'attribute' => 'departure_date',
                                    'label' => 'Departure Date',   
                                    'format' => 'raw',
                                    //'value' => isset($model->departure_date) ? date('d/m/Y', strtotime($model->departure_date)) : 'N/A',
                                    'value' => isset($model->departure_date)?date('Y-m-d', strtotime($model->departure_date)):'N\A',
                                   
                                ],

                               ],
                        ]);
                        ?>
                    </div>   		
                </div>        
            </div>
        </div>
    </div> 
</section> 
<?php 
if(count($request) > 0 && isset($request) && !empty($request))
{
    $i = 1;
    foreach ($request as $requestItem) {
    //echo "<pre>"; print_r($requestItem); 
?>

<section class="content">    
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title"><b>Request Item <?=$i?> Detail</b></h3> 
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <div class="box-body">
                    
                    <div class="order-form">
                        <table id="w1" class="table table-striped table-bordered detail-view">
                            <tbody>
                                <tr>
                                    <th>Item Type</th>
                                    <td><?= $requestItem['item_type_name'] ?></td>
                                </tr>
                                <tr>
                                    <th>Item Size</th>
                                    <td><?= $requestItem['vehicle_spacesize_name'] ?></td>
                                </tr>
                                <tr>
                                    <th>Item Weight(KG)</th>
                                    <td><?= $requestItem['post_request_items_item_weight'] ?></td>
                                </tr>
                                <tr>
                                    <th>Quantity</th>
                                    <td><?= $requestItem['post_request_items_qty'] ?></td>
                                </tr>
                                <tr>
                                    <th>Images</th>
                                    <td>
                                    <?php if(!empty($requestItem['post_request_items_image1'])){ ?>
                                    <img class="brifcase-img" src="<?php echo Yii::$app->request->hostInfo . USER_REQUEST_IMAGE1_PATH .$requestItem['post_request_items_image1']; ?>">
                                    <?php }?>
                                    </td>
                                    <td>
                                    <?php if(!empty($requestItem['post_request_items_image2'])){ 
                                        $filename = Yii::$app->request->hostInfo . USER_REQUEST_IMAGE2_PATH .$requestItem['post_request_items_image1'];
                                         if (file_exists($filename)) {
                                            $mediaFileUrl = Yii::$app->request->hostInfo . USER_REQUEST_IMAGE2_PATH . (isset($requestItem['post_request_items_image1']) ? $requestItem['post_request_items_image1'] : 'default_user.png');
                                         }else{
                                            $mediaFileUrl = Yii::$app->request->hostInfo . USER_PROFILE_PATH . 'UploadLight.png';
                                         } ?>
                                    <?php /*<img class="brifcase-img" src="<?php echo Yii::$app->request->hostInfo . USER_REQUEST_IMAGE2_PATH .$requestItem['post_request_items_image1']; ?>">*/ ?>
                                    <img class="brifcase-img" src="<?php echo $mediaFileUrl ?>">
                                    
                                    <?php  } ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>          
                </div>        
            </div>
        </div>
    </div> 
</section>
<?php
$i++;    
} }
?>
</div>

<?php
$this->registerJs("
     var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
    ");

$this->registerJs(\yii\web\View::POS_BEGIN);

$this->registerCssFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.css');
$this->registerCssFile('http://www.jqueryscript.net/css/jquerysctipttop.css');

$this->registerJsFile(Yii::$app->homeUrl . 'resource/drivers/views.js', ['depends' => 'yii\web\JqueryAsset']);
$this->registerJsFile(Yii::$app->homeUrl . 'plugins/Yearly-Calendar/calendar_by_year.js', ['depends' => 'yii\web\JqueryAsset']);

?>