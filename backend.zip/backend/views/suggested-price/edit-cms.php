
<?php

use yii\helpers\Html;


$this->title = '';
$this->params['breadcrumbs'][] = ['label' => 'Cms', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>


<section class="content-header">
    <h1>
        Content
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("cms/index") ?>" >Content</a></li>
        <li class="active">Edit Content</li>

    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <h3 class="box-title">Edit Content</h3> 
                    <a href="<?= yii\helpers\Url::to(['cms/index']) ?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>    <?=
                $this->render('_form', [
                    'model' => $model,
                ])
                ?>
            </div>
        </div>
    </div>
</section>