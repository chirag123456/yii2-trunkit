<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

$this->title = 'Admin';
?>



<div class="box-body"> 

    <div class="user-form">

        <?php
        $form = ActiveForm::begin([
                    'id' => 'user-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
        ]);
        ?>

        <div class="row">
            <div class="col-md-12">
                <div class="col-md-4">
                    <?= $form->field($model, 'name')->textInput(['autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter Name']) ?>
                </div>
               
               
            </div>

            <div class=" col-md-12"> 
               <h3>  &nbsp;&nbsp; Content</h3>                
              <textarea class="text-area" cols="50" id="editor1" name="content" rows="10" required="true"><?php echo $model->content; ?></textarea>

              <script>
               var editor1 = CKEDITOR.replace('editor1', 
               {
                extraAllowedContent: 'div',
                height: 250,
                enterMode : CKEDITOR.ENTER_BR,
                shiftEnterMode: CKEDITOR.ENTER_P
                });
                editor1.on('instanceReady', function () {

                this.dataProcessor.writer.selfClosingEnd = '>';

               var dtd = CKEDITOR.dtd;
              for (var e in CKEDITOR.tools.extend({}, dtd.$nonBodyContent, dtd.$block, dtd.$listItem, dtd.$tableContent)) {
              this.dataProcessor.writer.setRules(e, {
                  indent: true,
                  breakBeforeOpen: true,
                  breakAfterOpen: true,
                  breakBeforeClose: true,
                  breakAfterClose: true
                   });
                   }       
                   this.setMode('source');
                    });
              </script>
          </div>
           
        </div>
        <div class=" col-md-12">
            <div class="col-md-6 col-md-offset-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                }
                ?>
                <?php echo Html::a('Cancel', ['cms/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>

    </div>
    <?php ActiveForm::end(); ?>

</div>                        



