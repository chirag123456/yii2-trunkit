<footer class="main-footer">
    <strong>Copyright &copy; <?= date('Y')?> Trunkit Management System.</strong> All rights reserved.
</footer>

                        
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php
$this->registerJs("
	$( document ).ready(function() {
		if( $('.main-module li').length == 0 ){
			$('.main-module li').parent('li').remove();
		}
	});
");
?>