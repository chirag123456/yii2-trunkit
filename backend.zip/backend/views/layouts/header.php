<?php 

use yii\helpers\Url;
$baseUrl = Url::base(true);
?>
<header class="main-header"> 
    
    <a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>" class="logo">
       
        <span class="logo-mini">
            <img src="<?= dirname(Url::base(true)).ADMIN_LOGO ?>" height="35" width="35" alt="logo-mini"/>
        </span>
        
        <span class="logo-lg">
            <img src="<?= dirname(Url::base(true)).SIDE_LOGO ?>" class="img-responsive" alt="logo-lg"/>
        </span>
    </a>
    
    <nav class="navbar navbar-static-top">
        
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <?php if (isset(Yii::$app->user->identity->id)) { ?>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
               <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <?php if (isset(Yii::$app->user->identity->image) && !empty(Yii::$app->user->identity->image)) { 

                            $userimage = Yii::$app->request->hostInfo . USER_PROFILE_PATH . Yii::$app->user->identity->image;
                            ?>

                            <img src="<?= $userimage ?>" class="user-image" alt="User Image">                                      
                        <?php } else { ?>
                            <img src="<?= $baseUrl . '/uploads/default.png' ?>" class="user-image" alt="User Image">                                      
                        <?php }
                        ?>
                        <span class="hidden-xs"><?= Yii::$app->user->identity->email?></span>
                    </a>
                    <ul class="dropdown-menu">
                       
                        <li class="user-header">
                            <?php if (isset(Yii::$app->user->identity->image) && !empty(Yii::$app->user->identity->image)) { 
                                $userimage = Yii::$app->request->hostInfo . USER_PROFILE_PATH . Yii::$app->user->identity->image;
                                ?>

                                <img src="<?= $userimage ?>" class="img-circle" alt="User Image">
                            <?php } else { ?> 
                                <img src="<?= $baseUrl . '/uploads/default.png' ?>" class="img-circle" alt="User Image">

                            <?php } ?>
                            <p>
                                <?= Yii::$app->user->identity->email ?> <small></small>
                                
                                <small>IP  <?= Yii::$app->user->identity->ip_address ?></small>
                            </p>
                        </li>
                        
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="<?php echo yii::$app->urlManager->createAbsoluteUrl(['admin/view-profile']) ?>" class="btn btn-default btn-flat">View Profile</a>
                            </div>
                            <div class="pull-right">
                                <?php
                                echo \yii\helpers\Html::a(
                                        'Sign out', \yii\helpers\Url::to(['site/logout']), [
                                    'data-confirm' => "Are you sure want to logout?", // <-- confirmation works...
                                    'data-method' => 'post',
                                    'class' => "btn btn-default btn-flat"
                                        ]
                                );
                                ?>
                            </div>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        <?php } ?>
    </nav>
</header>