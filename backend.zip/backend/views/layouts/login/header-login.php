<?php
use yii\helpers\Url;

$baseUrl = Url::base(true);
?>
<header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
        <span class="logo-lg">
            <img src="<?php echo $baseUrl; ?>/web/images/logo/logo.png" alt="logo"/>
            <span>Admin</span>
        </span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
       

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- Messages: style can be found in dropdown.less-->

                <!-- Notifications: style can be found in dropdown.less -->

                <!-- User Account: style can be found in dropdown.less -->
                
            </ul>
        </div>
    </nav>
</header>