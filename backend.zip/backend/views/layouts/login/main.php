<?php

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use backend\assets\AppAsset;
use yii\helpers\Url;

AppAsset::register($this);
$this->title = 'Trunkit | Admin Panel | Login';
//$this->title = 'The Moter Master | Admin Panel | Login';

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html class="auth-page" lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" href="<?= dirname(Url::base(true)) ?>/backend/web/favicon.ico" type="image/x-icon">
        <?= Html::csrfMetaTags() ?>
        <?php $this->head() ?>
               <title><?php echo Html::encode($this->title) ?></title>
    </head>
    <body class="hold-transition login-page">
        <?php $this->beginBody() ?>

        <div class="login-box">

            <?= $content ?>

        </div>
        <?php $this->endBody() ?>

    </body>
</html>
<?php $this->endPage() ?>