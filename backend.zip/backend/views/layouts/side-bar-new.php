<?php

use yii\helpers\Html;

use backend\models\user\AuthAssignments;
use backend\models\user\UserAccess;
?>
<?php if (isset(Yii::$app->user->identity->id)) { ?>
<aside class="main-sidebar">    
  
    <section class="sidebar">
       
        <?php
        $active = isset($this->params['left_menu_active']) ? $this->params['left_menu_active'] : '';
        $itemsArray = array();

        
        $itemsArray['dashboard'] = [
            'class' => '',
            'label' => '<i class="fa fa-tachometer"></i> <span>Dashboard</span>',
            'url' => 'dashboard/index',
        ];
       
        $itemsArray['user'] = [
            'class' => 'treeview',
            'label' => '<i class="fa fa-user"></i><span>User Management</span>
							<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>',
            'url' => '#',
            'items' => [
                [
                    'label' => '<i class="fa fa-user"></i> <span>User Info</span>',
                    'url' => 'user/index',
                ],
                [
                    'label' => '<i class="fa fa-user"></i> <span>User Roles & Permission</span>',
                    'url' => 'user-role/index',
                ],
            ],
        ];
       
        $itemsArray['university'] = [
            'class' => '',
            'label' => '<i class="fa fa-university"></i> <span>University / Board</span>',
            'url' => 'university/index',
        ];

        
        $itemsArray['location'] = [
            'class' => 'treeview',
            'label' => '<i class="fa fa-map-marker"></i><span>Location</span>
                    <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>',
            'url' => '#',
            'items' => [
                [
                    'label' => '<i class="fa fa-arrow-right"></i> <span>Country</span>',
                    'url' => 'country/index',
                ],
                [
                    'label' => '<i class="fa fa-arrow-right"></i> <span>State</span>',
                    'url' => 'state/index',
                ],
                [
                    'label' => '<i class="fa fa-arrow-right"></i> <span>City</span>',
                    'url' => 'city/index',
                ],
            ],
        ];

        
        $itemsArray['standard'] = [
            'class' => '',
            'label' => '<i class="fa fa-book"></i> <span>Standard</span>',
            'url' => 'standard/index',
        ];

       
        $itemsArray['academic-year'] = [
            'class' => '',
            'label' => '<i class="fa fa-calendar"></i> <span>Academic Year</span>',
            'url' => 'academic-year/index',
        ];

        
        $itemsArray['subjects-management'] = [
            'class' => 'treeview',
            'label' => '<i class="fa fa-book"></i><span>Subjects Management</span>
                    <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>',
            'url' => '#',
            'items' => [
                [
                    'label' => '<i class="fa fa-object-group"></i> <span>Subject Group</span>',
                    'url' => 'subject-group/index',
                ],
                [
                    'label' => '<i class="fa fa-book"></i> <span>Subjects</span>',
                    'url' => 'subject/index',
                ],
            ],
        ];

        
        $itemsArray['students-management'] = [
            'class' => 'treeview',
            'label' => '<i class="fa fa-users"></i><span>Students Management</span>
                    <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>',
            'url' => '#',
            'items' => [
                [
                    'label' => '<i class="fa fa-object-group"></i> <span>Student Group</span>',
                    'url' => 'student-group/index',
                ],
                [
                    'label' => '<i class="fa fa-users"></i> <span>Students</span>',
                    'url' => 'student/index',
                ],
            ],
        ];

        
        $itemsArray['setting'] = [
            'class' => '',
            'label' => '<i class="fa fa-gears"></i> <span>Site Configuration</span>',
            'url' => 'setting/index',
        ];

        $authAssig = AuthAssignments::find()->select('item_name')->where(['user_id' => Yii::$app->user->id])->one();

        if ($authAssig != null && ( $authAssig->item_name != 'superadmin' )) {
            $userAccess = UserAccess::find()->select('access')->where(['name' => $authAssig->item_name, 'is_admin' => '0'])->one();
            if ($userAccess != null) {

                $_itemsArray = [$itemsArray['dashboard']];

                if ($userAccess->access != '') {

                    $accessArr = json_decode($userAccess->access, 16);

                    if (is_array($accessArr)) {
                        foreach ($accessArr as $val) {
                            $_itemsArray[] = $itemsArray[$val['module']];
                        }
                    }
                }

                $itemsArray = $_itemsArray;
            }
        }
        ?>
        <ul class="sidebar-menu">

        <?php
        
        foreach ($itemsArray as $k => $v) {
            echo Html::beginTag('li', ['class' => $v['class']]);
            echo Html::a($v['label'], [$v['url']], []);
            if (isset($v['items'])) {
                echo Html::beginTag('ul', ['class' => 'treeview-menu main-module']);
                foreach ($v['items'] as $val) {
                    echo Html::beginTag('li', ['class' => '']);
                    echo Html::a($val['label'], [$val['url']], []);
                    echo Html::endTag('li');
                }
                echo Html::endTag('ul');
            }
            echo Html::endTag('li');
        }
        ?>

        </ul>
    </section>
   
</aside>

<?php } ?>