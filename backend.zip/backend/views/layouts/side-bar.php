<?php

use backend\components\CustController;
?>
<?php if (isset(Yii::$app->user->identity->id)) { ?>
<aside class="main-sidebar">    
    
    <section class="sidebar">
       

        <ul class="sidebar-menu">
            <li class="<?php echo (\Yii::$app->controller->id === "dashboard") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>">
                    <i class="fa fa-tachometer"></i> <span>Dashboard</span>
                </a>
            </li>
			
			<li class="<?php echo (\Yii::$app->controller->id === "admin") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("admin/index") ?>">
                    <i class="fa fa-user"></i> <span>Admin Management</span>
                </a>
            </li>
			
            <li class="<?php echo (\Yii::$app->controller->id === "user") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("user/index") ?>">
                    <i class="fa fa-users"></i> <span>User Management</span>
                </a>
            </li>
              <li class="<?php echo (\Yii::$app->controller->id === "cms") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("cms/index") ?>">
                    <i class="fa fa-file"></i> <span>Content Management</span>
                </a>
            </li>
              <li class="<?php echo (\Yii::$app->controller->id === "homeimage") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("homeimage/index") ?>">
                    <i class="fa fa-file"></i> <span>Home Slider Image</span>
                </a>
            </li>
            <li class="treeview <?php echo ( in_array( \Yii::$app->controller->id , ['vehicle-make-model','vehicle-type','vehicle-color','vehicle-space-size'] ) ) ? 'active' : '' ?>">
                <a href="#">
                    <i class="fa fa-car"></i>
                    <span>Vehicle Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu main-module">
                    <li class="<?php echo (\Yii::$app->controller->id === "vehicle-make-model") ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("vehicle-make-model/index") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Vehicle Make Model</span>
                        </a>
                    </li>
                    <li class="<?php echo (\Yii::$app->controller->id === "vehicle-type") ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("vehicle-type/index") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Vehicle Type</span>
                        </a>
                    </li>
                    <li class="<?php echo (\Yii::$app->controller->id === "vehicle-color") ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("vehicle-color/index") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Vehicle Color</span>
                        </a>
                    </li>
                    <li class="<?php echo (\Yii::$app->controller->id === "vehicle-space-size") ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("vehicle-space-size/index") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Vehicle Space Size</span>
                        </a>
                    </li>

                </ul>
            </li>
            <li class="treeview <?php echo ( in_array( \Yii::$app->controller->id , ['item-size','item-type'] ) ) ? 'active' : '' ?>">
                <a href="#">
                    <i class="fa fa-briefcase"></i>
                    <span>Items Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu main-module">
                    <li class="<?php echo (\Yii::$app->controller->id === "item-size") ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("item-size/index") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Item size</span>
                        </a>
                    </li>
                    <li class="<?php echo (\Yii::$app->controller->id === "item-type") ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("item-type/index") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Item Type</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="treeview <?php echo (\Yii::$app->controller->id === "post") ? 'active' : '' ?>">
                <a href="#">
                    <i class="fa fa-calendar"></i>
                    <span>Post Management</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu main-module">
                    <li class="<?php echo (\Yii::$app->controller->id === "post" && \Yii::$app->controller->action->id === "post-trip" ) ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-trip") ?>">
                            <i class="fa fa-car"></i> <span>Trip Management</span>
                        </a>
                    </li>
                    <li class="<?php echo (\Yii::$app->controller->id === "post" && \Yii::$app->controller->action->id === "post-request" ) ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("post/post-request") ?>">
                            <i class="fa fa-briefcase"></i> <span>Request Management</span>
                        </a>
                    </li>
                </ul>
            </li>
            
            <li class="<?php echo (\Yii::$app->controller->id === "order") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("order/post-order") ?>">
                    <i class="fa fa-truck"></i> <span>Order Management</span>
                </a>
            </li>

            <li class="treeview <?php echo (\Yii::$app->controller->id === "payment") ? 'active' : '' ?>">
                <a href="#">
                    <i class="fa fa-money"></i>
                    <span>Payment</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu main-module">
                    <li class="<?php echo (\Yii::$app->controller->id === "payment" && \Yii::$app->controller->action->id === "pending-payment" ) ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("payment/pending-payment") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Pending Payment</span>
                        </a>
                    </li>
                    <li class="<?php echo (\Yii::$app->controller->id === "payment" && \Yii::$app->controller->action->id === "archived-payment" ) ? 'active' : '' ?>">
                        <a href="<?php echo \Yii::$app->urlManager->createUrl("payment/archived-payment") ?>">
                            <i class="fa fa-arrow-right"></i> <span>Archived Payment</span>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="<?php echo (\Yii::$app->controller->id === "review") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("review/index") ?>">
                    <i class="fa fa-star"></i> <span>Review & Rating Management</span>
                </a>
            </li>
			
			<li class="<?php echo (\Yii::$app->controller->id === "notification") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("notification/index") ?>">
                    <i class="fa fa-bell-o"></i> <span>Notification Management</span>
                </a>
            </li>
			<li class="<?php echo (\Yii::$app->controller->id === "statistics") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("statistics/index?order") ?>">
                    <i class="fa fa-area-chart"></i> <span>Statistics Report</span>
                </a>
            </li>

            <li class="<?php echo (\Yii::$app->controller->id === "setting") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("setting/index") ?>">
                    <i class="fa fa-gears"></i> <span>Site Configuration</span>
                </a>
            </li>	

            <li class="<?php echo (\Yii::$app->controller->id === "site") ? 'active' : '' ?>">
                <a href="<?php echo \Yii::$app->urlManager->createUrl("site/logout") ?>">
                    <i class="fa fa-sign-out"></i> <span>Signout</span>
                </a>
            </li>

        </ul>
    </section>
    
</aside>
<?php } ?>
<?php
$this->registerJs("
    $('.multi-menu').click(function(){
      // $(this).addClass('active');
    });
");
