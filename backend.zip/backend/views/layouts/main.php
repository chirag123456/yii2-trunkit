<?php
/* @var $this \yii\web\View */
/* @var $content string */

use backend\assets\AppAsset;
use yii\helpers\Html;
use yii\helpers\Url;

AppAsset::register($this);
$this->title = 'Trunkit Management';
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>"> 
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
          <link rel="shortcut icon" href="<?= dirname(Url::base(true)) ?>/backend/web/favicon.ico" type="image/x-icon"> 
                    
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <script type="text/javascript"> var site_url = '<?= \Yii::$app->urlManager->createAbsoluteUrl(['/']) ?>';</script>
        <?php $this->head() ?>
    </head>

    <body class="hold-transition skin-blue sidebar-mini">
        <?php $this->beginBody() ?>

        <div class="wrapper">
            <?= $this->render('header'); ?>
            <?= $this->render('side-bar'); ?>
            <div class="content-wrapper">
                <?= $content ?>
            </div>

            <?= $this->render('footer'); ?>
        </div>

        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
