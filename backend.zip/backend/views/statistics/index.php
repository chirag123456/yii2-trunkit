<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ListView;
use yii\widgets\Pjax;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
use common\models\post\PostOrder;

$this->title = 'Trunk It Admin Portal';

?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">  
    <h1>
        Statistics Report
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Statistics</li>
    </ol>
</section>

<section class="content">

    <div class="row">
        <div class="col-xs-12">
            <ul class="pagination">
                <?php if (isset($_GET['order']) && $_GET['order'] == 'daily' || $_GET['order'] == '') { ?>
                    <li <?php if (isset($_GET['order']) && $_GET['order'] == 'daily'){ ?> class = "active" <?php } ?> ><?php echo Html::a('Daily', ['index?order=daily'], ['class' => 'btn btn-primary filter-reset']) ?></li>

                    <li><?php echo Html::a('Monthly', ['index?order=monthly'], ['class' => 'btn btn-primary filter-reset']) ?></li>

                    <li><?php echo Html::a('Yearly', ['index?order=yearly'], ['class' => 'btn btn-primary filter-reset']) ?></li>

                    <li><?= Html::a('Export CSV', ['export/export-data?order=daily/'], ['class' => 'btn btn-primary btn-export-click']) ?></li>

                <?php } elseif (isset($_GET['order']) && $_GET['order'] == 'monthly') { ?>
                    <li><?php echo Html::a('Daily', ['index?order=daily'], ['class' => 'btn btn-primary filter-reset']) ?></li>
                    <li class="active"><?php echo Html::a('Monthly', ['index?order=monthly'], ['class' => 'btn btn-primary filter-reset']) ?></li>
                    <li><?php echo Html::a('Yearly', ['index?order=yearly'], ['class' => 'btn btn-primary filter-reset']) ?></li>
                    <li><?= Html::a('Export CSV', ['export/export-data?order=monthly/'], ['class' => 'btn btn-primary btn-export-click']) ?></li>

                <?php } elseif (isset($_GET['order']) && $_GET['order'] == 'yearly') { ?>
                    <li><?php echo Html::a('Daily', ['index?order=daily'], ['class' => 'btn btn-primary filter-reset']) ?></li>
                    <li><?php echo Html::a('Monthly', ['index?order=monthly'], ['class' => 'btn btn-primary filter-reset']) ?></li>
                    <li class="active"><?php echo Html::a('Yearly', ['index?order=yearly'], ['class' => 'btn btn-primary filter-reset']) ?></li>
                    <li><?= Html::a('Export CSV', ['export/export-data?order=yearly/'], ['class' => 'btn btn-primary btn-export-click']) ?></li>

                <?php } ?>
                <p> </p>
            </ul>
            
            <div class="box box-primary">

                <div class="box-body">
                    <div class="user-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get',
                                    'action' => yii\helpers\Url::base() . '/statistics/index?order',
                                    'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                        ?>

                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,                          
                            'columns' => [
                                //['class' => 'yii\grid\SerialColumn'],
                                [   'attribute' => 'traking_number',
                                    'label' => 'Tracking No',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
                                [
                                    'label' => 'Origin',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                       return isset($model->post->origin)?$model->post->origin:'N\A';
                                    },
                                ],
                                 [
                                    'label' => 'Destination',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                       return isset($model->post->destination)?$model->post->destination:'N\A';
                                    },
                                ],
                                [
                                    'attribute' => 'order_date',
                                    'label' => 'Order Date',
                                    'format' => 'raw',
                                ],
                                [
                                    'attribute' => 'price',
                                    'label' => 'Total Amount',
                                    'format' => 'raw',
                                ],
                            ],
                        ]);
                        ?>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>

<?php
$this->title = 'Admin | Dashboard';
?>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
        var page_size = '" . $_GET['per-page'] . "';
        $('#pagination').val(page_size);
        $('#pagination option:selected',page_size).text();
    ");
}
?>
<?php
$this->registerJs("
    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
