
<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $model common\models\User */

$this->title = '';
$this->params['breadcrumbs'][] = ['label' => 'Post Trip', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>


<section class="content-header">
    <h1>
        Post Request's
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Post Request's</li>

    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border"> 
                    <a class="btn btn-primary" href="<?= Yii::$app->urlManager->createAbsoluteUrl(['/review/review']) ?>" >Reset Grid</a>
                </div>   
                <div class="box-body">
                    <div class="user-index">

                        <h1><?= Html::encode($this->title) ?></h1>

                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'columns' => [
                               [   'attribute' => 'id',
                                        'label' => '#ID',
                                        'contentOptions' => ['style' => 'width:40px;'],
                                     ],
                                [
                                    'attribute' => 'user_id',
                                    'label' => 'User',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                            return isset($model->user->first_name)?$model->user->first_name:'N\A';
                                    },
                                    'filterInputOptions' => [
                                        'class'=>'form-control',
                                        'placeholder' => 'Search by User'
                                    ],
                                ],

                                [
                                    'attribute' => 'comments',
                                    'label' => 'Comments',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class'=>'form-control',
                                        'placeholder' => 'Search by Comments'
                                    ],
                                ],                               
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{view} {delete}',
                                    'buttons' => [
                                        'status' => function ($url, $model) {
                                            if ($model->is_active == ACTIVE) {
                                                return Html::a('<span class="glyphicon glyphicon-remove-circle" style="color:#d9534f"></span>', $url, [
                                                            'class' => '',
                                                            'data-confirm' => INACTIVESTATUS, // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'InActive'
                                                ]);
                                            } else {
                                                return Html::a('<span class="glyphicon glyphicon-ok-circle" style="color:#5cb85c"></span>', $url, [
                                                            'data-confirm' => ACTIVESTATUS, // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Active'
                                                ]);
                                            }
                                        },
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                        'data-confirm' => DELETESTATUS, // <-- confirmation works...
                                                        'data-method' => 'post',
                                                        'class' => 'delete',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Delete',
                                            ]);
                                        },
                                        'update' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Edit',
                                            ]);
                                        },
                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', 
                                                    ['order/view/' . $model->id], [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'View',
                                            ]);
                                        }
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'status') {
                                            return \yii\helpers\Url::toRoute(['order/status/' . $key]);
                                        } else if ($action === 'update') {

                                            return \yii\helpers\Url::toRoute(['order/update/' . $key]);
                                        } else if ($action === 'delete') {
                                            return \yii\helpers\Url::toRoute(['order/delete/' . $key]);
                                        } else if ($action === 'change-password') {
                                            return \yii\helpers\Url::toRoute(['user/delete/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
