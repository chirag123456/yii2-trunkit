<?php

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
use common\models\review\Review;

$baseUrl = Url::base(true);

$this->title = 'Admin';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
     Review & Rating Management
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Review & Rating Management</li>
    </ol>
</section>
<section class="content">

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <div class="box-body">
                    <div class="user-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                        $settings = \common\models\Settings::find()->one();
                      
                        $pagesize = $settings['config_value'];
                        ?>


                        <?php // echo $this->render('_search', ['model' => $searchModel]);      ?>
                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                            <?php echo Html::a('Reset', ['/review/index'], ['class' => 'btn btn-primary filter-reset']) ?>
                        </p>
                        <?php Pjax::begin(['id' => 'users']) ?>  
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'columns' => [
                                [   'attribute' => 'id',
                                    'label' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
//                                'id',
                                [
                                    'label' => 'From User',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:150px;'],
                                    'format' => 'raw',
                                    'value' => 'fromUser.email',
                                ],
                                [
                                    'label' => 'To User',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:150px;'],
                                    'format' => 'raw',
                                    'value' => 'toUser.email',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by To User Email'
                                    ],
                                ],
                                [
                                    'attribute' => 'comments',
                                    'label' => 'Comments',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Comments'
                                    ],
                                ],
                                [
                                    'attribute' => 'rating',
                                    'label' => 'Rating',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return Review::getRatingHtml($model->rating);
                                    },
                                    'filter' => ['1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select'
                                    ],
                                ],
                                // [
                                //     'class' => 'yii\grid\ActionColumn',
                                //     'header' => 'Actions',
                                //     'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                //     'template' => '{delete} {approve}',
                                //     'buttons' => [
                                //         'delete' => function ($url, $model) {
                                //             return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                //                         'data-confirm' => DELETESTATUS, // <-- confirmation works...
                                //                         'data-method' => 'post',
                                //                         'class' => 'delete',
                                //                         'data-toggle' => 'tooltip',
                                //                         'title' => 'Delete',
                                //             ]);
                                //         },
                                //         'approve' => function ($url, $model) {
                                //             if ($model->is_approved == ACTIVE) {
                                //                 return Html::a('<span class="glyphicon glyphicon-ok" style="color:#5cb85c"></span>', $url, [
                                //                             'class' => '',
                                //                             'data-confirm' => NOTAPPROVEDSTATUS . " review?", // <-- confirmation works...
                                //                             'data-method' => 'post',
                                //                             'title' => Yii::t('app', 'Status'),
                                //                             'data-toggle' => 'tooltip',
                                //                             'title' => 'Not Approved'
                                //                 ]);
                                //             } else {
                                //                 return Html::a('<span class="glyphicon glyphicon-remove" style="color:#d9534f"></span>', $url, [
                                //                             'data-confirm' => APPROVESTATUS . " review?", // <-- confirmation works...
                                //                             'data-method' => 'post',
                                //                             'class' => '',
                                //                             'title' => Yii::t('app', 'Status'),
                                //                             'data-toggle' => 'tooltip',
                                //                             'title' => 'Approved'
                                //                 ]);
                                //             }
                                //         }
                                //     ],
                                //     'urlCreator' => function ($action, $model, $key, $index) {

                                //         if ($action === 'status') {
                                //             return \yii\helpers\Url::toRoute(['review/status/' . $key]);
                                //         } else if ($action === 'update') {

                                //             return \yii\helpers\Url::toRoute(['review/update/' . $key]);
                                //         } else if ($action === 'delete') {
                                //             return \yii\helpers\Url::toRoute(['review/delete/' . $key]);
                                //         } else if ($action === 'approve') {
                                //             return \yii\helpers\Url::toRoute(['review/approve/' . $key]);
                                //         } else if ($action === 'change-password') {
                                //             return \yii\helpers\Url::toRoute(['review/delete/' . $key]);
                                //         }
                                //     }
                                // ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
<?php
$this->registerJs("
   $(document).on('ready pjax:success', function () {
    $('.ajaxStatus').on('click', function (e) {
        e.preventDefault();
        var Url     = $(this).attr('status-url');
        var pjaxContainer = $(this).attr('pjax-container');
            $.ajax({
                    url:   Url,
                    type:  'post',
                }).done(function (data) {
                  $.pjax.reload({container: '#' + $.trim(pjaxContainer)});
                });

    });
});
");
?>