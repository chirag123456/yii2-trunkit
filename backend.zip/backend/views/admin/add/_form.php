<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>


<!-- /.box-header -->
<!-- form start -->
<div class="box-body"> 

    <div class="user-form">

        <?php
        $form = ActiveForm::begin([
                    'id' => 'user-form',
                    'enableAjaxValidation' => true,
                    'enableClientValidation' => true,
                    'options' => ['enctype' => 'multipart/form-data']
        ]);
        ?>

        <div class="row">
            <div class="col-md-12">
                <div class="col-md-4">
                    <?= $form->field($model, 'first_name')->textInput(['autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter First Name']) ?>
                </div>
                <div class="col-md-4">
                    <?= $form->field($model, 'last_name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Last Name']) ?>
                </div> 
                <div class="col-md-4">
                    <?= $form->field($model, 'email')->textInput(['maxlength' => 100, 'id' => 'email', 'placeholder' => 'Enter Email Address']) ?>
                </div>
            </div>


            <?php if (isset($_GET['id']) && !empty($_GET['id'])) { ?>
            <?php } else { ?>
                <div class="col-md-12">
                    <div class=" col-md-6">
                        <?= $form->field($model, 'password')->passwordInput(['autofocus' => true, 'placeholder' => 'Enter Password']) ?>
                    </div>
                    <div class=" col-md-6">
                        <?= $form->field($model, 'confirm_password')->passwordInput(['placeholder' => 'Enter Confirm Password']) ?>
                    </div>
                </div> 
            <?php } ?>



            <div class="col-md-12">
                <div class="col-md-4">
                    <?= $form->field($model, 'contact_number')->textInput(['maxlength' => 20, 'maxlength' => 16, 'minlength' => 10, 'id' => 'user_contact', 'placeholder' => 'Enter Contact Number']) ?>
                </div>
                <div class="col-md-4">
                    <?= $form->field($model, 'date_of_birth')->textInput(['placeholder' => 'Select Date Of Birth',
					'id' => 'datepicker']) ?>
                </div>

                <div class=" col-md-4">
                    <?= $form->field($model, 'age')->textInput(['maxlength' => 3, 'placeholder' => 'Enter Age', 'readOnly' => true]) ?>
                </div> 
            </div>

            <div class="col-md-12">

                <div class=" col-md-4">
                    <?= $form->field($model, 'description')->textarea(['maxlength' => 100, 'id' => 'user_email', 'placeholder' => 'Enter Description']) ?>
                </div>
            </div>


            <div class="col-md-12 image-sections">
<!--                <div class="col-md-3">
                    <div class="col-md-12">
                        <div class="image-label1"><label>Driver License Image</label></div>
                    </div>
                    <div class=" col-md-12"> 
                        <div class="cropme" id="client_image" style="width: 200px; height: 200px;" data-image="true"></div>
                        <input type="hidden" name="UserForm[image_name]" id="set_client_img">
                        <input type="hidden" name="imageRemove" id="imgRemove1" value="0">
                        <button type="button" id="remove" class="pull-right btn btn-default user-remove-img-btn">
                            <span class="fa fa-remove"></span>
                        </button>
                    </div>
                    <div  style="display:none; color: red;margin-top: 5px; margin-left: 30px; margin-bottom: 10px;" 
                          class="image-error1">Image cannot be blank.</div>
                </div>-->
                <div class="col-md-3">
                    <div class="col-md-12">
                        <div class="image-label2"><label>Select Profile Image</label></div>
                    </div>
                    <div class=" col-md-12"> 
                        <div class="cropme" id="image" style="width: 200px; height: 200px;" data-image="true"></div>
                        <input type="hidden" name="UserForm[image]" id="set_img">
                        <input type="hidden" name="imageRemove" id="imgRemove2" value="0">
                        <button type="button" id="remove-image" class="pull-right btn btn-default user-remove-img-btn">
                            <span class="fa fa-remove"></span>
                        </button>
                    </div>
                    <div  style="display:none; color: red;margin-top: 5px; margin-left: 30px; margin-bottom: 10px;" 
                          class="image-error2">Image cannot be blank.</div>
                </div>
            </div>
        </div>
        <div class=" col-md-12">
            <div class="col-md-6 col-md-offset-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                }
                ?>
                <?php 
				$url = 'admin/index';
				if( isset( $profile ) ){
					$url = 'admin/view-profile';
				}
				echo Html::a('Cancel', [$url], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>

    </div>
    <?php ActiveForm::end(); ?>

</div>                        


<?php
$this->registerJs("
    $('#datepicker').on('changeDate', function(e) {
        var currentDate = new Date();
        var selectedDate = new Date(e.date.toString());
        var age = currentDate.getFullYear() - selectedDate.getFullYear();
        var m = currentDate.getMonth() - selectedDate.getMonth();

        if (m < 0 || (m === 0 && currentDate.getDate() < selectedDate.getDate())) {
            age--;
        }
        $('#userform-age').val(age);
    });
");

$this->registerJs("
    $(document).ready(function() {
        var dt = new Date();
        dt.setFullYear(new Date().getFullYear()-18);
        var today = new Date();
        $('#datepicker').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            endDate: dt,
            maxDate: today
        });
});
");


if (isset($model->driver_licence) && !empty($model->driver_licence)) {
    $mediaFileUrl = dirname(\yii\helpers\Url::base(true)) . '/backend/web/uploads/users/driver_licence/' . $model->driver_licence;

    $this->registerJs("
        $(document).ready(function() {
            var client_image_url = 'url($mediaFileUrl)';
            $('#client_image').css('background-image', client_image_url);
        });
    ");
}
$default_img = Yii::$app->urlManager->createAbsoluteUrl("/web/uploads/UploadLight.png");

if (isset($model->image) && !empty($model->image)) {

    $mediaFileUrl2 = dirname(\yii\helpers\Url::base(true)) . '/backend/web/uploads/users/image/' . $model->image;

    $this->registerJs("
        $(document).ready(function() {
            var user_image_url = 'url($mediaFileUrl2)';
            $('#image').css('background-image', user_image_url);
        });
    ");
}

$default_img = Yii::$app->request->hostInfo . USER_PROFILE_PATH . "UploadLight.png";
$this->registerJs("

 $('.cropme').simpleCropper();  
 
 $('#img').click(function() {
     var client_img_src =  $('#client_image').children().attr('src');
     var client_img_src2 =  $('#image').children().attr('src');
     
     $('#set_client_img').val(client_img_src);
     $('#set_img').val(client_img_src2);
 });
");

if (!isset($_GET['id']) && empty($_GET['id'])) {

    $this->registerJs("
               
    $('#remove').click(function() {
        $('#client_image img').remove();
        $('#client_image').css('background-image', 'url($default_img)');
    });
    $('#remove-image').click(function() {alert();
        $('#client_img_src img').remove();
        $('#client_img_src').css('background-image', 'url($default_img)');
    });
    
    $('#user-form').on('submit', function() {  
        
        if ($('#image img').length == 0 || $('#vehicle_photo_remove').val() == 1) {
            $('#image').css('border', '1px solid red');
            $('.image-labe12').css('color', '#dd4b39');
            $('.image-error2').show();
            var b = 1;
        } else {
            $('#image').css('border', '1px solid green');
            $('.image-labe12').css('color', '#00a65a');
            $('.image-error2').hide();
            var b = 2;
        } 
        
        if ( b == '1') {
            return false;
        } else {
            return true;
        }
    });
  
    ");
} else {
    $this->registerJs("
        $('#remove').click(function() {
           $('#client_image img').remove();
           $('#client_image').css('background-image', 'url($default_img)');
           $('#imgRemove1').val(1);
        });
        $('#remove-image').click(function() {
           $('#image img').remove();
           $('#image').css('background-image', 'url($default_img)');
           $('#imgRemove2').val(1);
        });
        
        $('#user-form').on('submit', function() {
        
            
            if($('#image img').length == 0 ) {
                if( $('#image').data('image') == 'false'  || $('#imgRemove2').val() == 1 ) {
                    $('#image').css('border', '1px solid red');
                    $('.image-labe12').css('color', '#dd4b39');
                    $('.image-error2').show();
                   var b = 1; 
                } else {
                    $('#image').css('border', '1px solid green');
                    $('.image-labe12').css('color', '#00a65a');
                    $('.image-error2').hide();
                    var b = 2;
                }
            } else {
                $('#image').css('border', '1px solid green');
                $('.image-label2').css('color', '#00a65a');
                $('.image-error2').hide();
                var b = 2;
            }
            if (b == '1') {
                return false;
            } else {
                return true;
            }
        });
     

");
}

if (isset($model->id) && !empty($model->id)) {

    $this->registerJs("
        $(document).ready(function() {
            $( '#email' ).prop( 'disabled', true );
            $( '#user_contact' ).prop( 'disabled', true );
        });
    ");
}
?>