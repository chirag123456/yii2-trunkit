<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>
<div class="state-form">

    <?php
    $form = ActiveForm::begin([
                'id' => 'state-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
    ]);
    ?>
    <div class="row box-body">
       <div class="col-md-12">
            <div class="col-md-4">
            <?php
            echo $form->field($model, 'country_id')->widget(
                    Select2::classname(), [
                'data' => ArrayHelper::map(\common\models\Country::find()->where(['is_active'=>ACTIVE])->andWhere(['is_delete'=>NOT_DELETED])->asArray()->all(), 'id', 'country_name'),
                'options' => ['placeholder' => 'Select Country'],
            ])->label();
            ?>
            </div>
       </div>
 <div class="col-md-12">
            <div class="col-md-4">
            <?= $form->field($model, 'state_name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter State']) ?>
            </div>
 </div>


             <div class="col-md-12">
            <div class="col-md-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right']);
                }
                ?>  
                <?php echo Html::a('Cancel', ['state/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>                       
             </div>
 
        </div>

        <?php ActiveForm::end(); ?>
    </div>
</div>

