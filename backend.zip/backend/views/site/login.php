<?php 
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;
$this->title = 'Admin';

?> 
  <div class="login-box-body">
    <div class="login-logo">
      <a href="../../index2.html"><b><span class="logo-mini"><img src="<?= dirname(Url::base(true)).ADMIN_LOGO ?>" class="img-responsive" alt="User Image"></span></b></a>
    </div>
  <!-- /.login-logo -->
    <?php $form = \yii\widgets\ActiveForm::begin([
         'id'=>"change-password",
       'enableAjaxValidation' => true,
        'enableClientValidation' => true,

    ]); ?>
      <div class="form-group has-feedback">
                <?= $form->field($model, 'email')->textInput(['maxlength' => true,'placeholder'=>'Enter Email',
               'inputTemplate' => 'glyphicon glyphicon-envelope form-control-feedback'
                    ]) ?>
     </div>
      <div class="form-group has-feedback">
                        <?= $form->field($model, 'password')->passwordInput(['placeholder'=>'Enter Password']) ?>
      </div>
      <div class="row">
<!--        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
                <?= $form->field($model, 'rememberMe')->checkbox(['value' => '0']) ?>
            </label>
          </div>
        </div>-->
        <!-- /.col -->
        <div class="col-xs-12 text-center">
          <button type="submit" class="btn btn-primary text-uppercase btn-login">Login</button>
          <div class="clearfix"></div>
        </div>
        <!-- /.col -->
      </div>
            <?php \yii\widgets\ActiveForm::end(); ?>

    
    <!-- /.social-auth-links -->

    <a href="<?= Url::to(['site/forgot-password']) ?>">Forgot Password?</a> <br>

  </div>
  <!-- /.login-box-body -->

