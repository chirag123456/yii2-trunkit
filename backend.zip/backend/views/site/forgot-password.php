<?php 
use yii\helpers\Url;
use yii\widgets\ActiveForm;
$this->title = 'Trunkit';

?> 
  <div class="login-box-body">
    <div class="login-logo">
      <a href="../../index2.html"><b><span class="logo-mini"><img src="<?= dirname(Url::base(true)).ADMIN_LOGO ?>" class="img-responsive" alt="User Image"></span></b></a>
    </div>
  
    <?php 
	if( isset($_GET['sendmail']) && $_GET['sendmail'] == true ){ ?>
		<div class="row">
			<div class="col-xs-12 text-center">
			  <p style="color:green;"><b>Your request received successfully.For more information check your email.</b></p>
			  <a href="<?= Url::to(['site/login']) ?>">Back to Login?</a>
			</div>
		</div>
		
	<?php 
	}else{
		$form = ActiveForm::begin([
			 'id'=>"forgot-password",
		]); ?>
		  <div class="form-group has-feedback">
					<?= $form->field($model, 'email')->textInput(['maxlength' => true,'placeholder'=>'Enter Email',
				   'inputTemplate' => 'glyphicon glyphicon-envelope form-control-feedback'
						]) ?>
		  </div>
		  
		  <div class="row">
			<div class="col-xs-12 text-center">
			  <button type="submit" class="btn btn-primary text-uppercase btn-login">Submit</button>
			  <div class="clearfix"></div>
			</div>
		  </div>
		  <?php ActiveForm::end(); ?>
			<a href="<?= Url::to(['site/login']) ?>">Back to Login?</a>
    <?php } ?>

  </div>
  
