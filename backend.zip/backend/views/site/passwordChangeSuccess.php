<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\PasswordResetRequestForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Forgot Password';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="login-logo">
    <a href="../../index2.html"><b>Admin</b></a>
</div>
  <!-- /.login-logo -->

  <!-- /.login-logo -->
      <div class="login-box-body">

        <div class="site-request-password-reset">
            <h1><?= Html::encode($this->title) ?></h1>

            <p>Your password has been change successfully.</p>
            <a href="<?= yii\helpers\Url::to(['site/login']) ?>"> Click here to go back to the login page</a>
            
        </div>
      </div>
   