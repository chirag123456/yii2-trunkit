<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\PasswordResetRequestForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Forgot Password';
$this->params['breadcrumbs'][] = $this->title;
?>
 <div class="login-logo">
    <a href="#"><b>Admin</b></a>
  </div>
  <!-- /.login-logo -->
      <div class="login-box-body">

        <div class="site-request-password-reset">
            <h1><?= Html::encode($this->title) ?></h1>

            <p>The access token provid is expired.</p>
            <a href="<?= yii\helpers\Url::to(['site/login']) ?>"> Check here to GoBack to Login page</a>
            
        </div>
      </div>