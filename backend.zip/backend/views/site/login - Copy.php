<?php 
use yii\helpers\Url;
$this->title = 'NCAA Management';

?>

  
  <div class="login-box-body">
    <div class="login-logo">
      <a href="../../index2.html"><b><span class="logo-mini"><img src="<?= dirname(Url::base(true)).ADMIN_LOGO ?>" class="img-responsive" alt="User Image"></span></b></a>
    </div>
  <!-- /.login-logo -->
    <?php $form = \yii\widgets\ActiveForm::begin([
         'id'=>"change-password",
    ]); ?>
		<div class="form-group has-feedback">
                <?= $form->field($model, 'email')->textInput(['maxlength' => true,'placeholder'=>'Email',
               'inputTemplate' => 'glyphicon glyphicon-envelope form-control-feedback'
                    ]) ?>
		</div>
      
      <div class="row">
        <div class="col-xs-12 text-center">
			<a href="<?php echo \yii\helpers\Url::to(['site/login']);?>" class="btn btn-primary text-uppercase btn-login">Submit</button>
			<button type="submit" class="btn btn-primary text-uppercase btn-login">Submit</button>
			<div class="clearfix"></div>
        </div>
        <!-- /.col -->
      </div>
            <?php \yii\widgets\ActiveForm::end(); ?>

    
    <!-- /.social-auth-links -->

    <?php /*<a href="<?= Url::to(['site/request-password-reset']) ?>">Forgot Password?</a>*/ ?> <br>

  </div>
  <!-- /.login-box-body -->

