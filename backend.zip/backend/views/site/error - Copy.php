<?php 

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

use yii\helpers\Html;

$this->title = 'Error!';
if( $error != null && $error->statusCode != null ){
	$code = $error->statusCode;
}else if( isset( $_GET['code'] ) ){
	$code = $_GET['code'];
}else{
	$code = 500;
}
?>
<div class="col-md-12" style="color: white !important;">
    <div class="col-middle">
        <div class="text-center text-center">
			<?php if($code == 404){ ?>
                <h1 style="color: white !important;" class="error-number">Error 404</h1>
                <h2 style="color: white !important;">Sorry but we could not find this page</h2>
                <p style="color: white !important;">This page you are looking for does not exist.
                </p>
				<?php if(!isset(Yii::$app->user->identity->id))
                    { ?>
                    <a href="<?= yii\helpers\Url::to(['site/login']) ?>"> Go to Login</a>                        
                   <?php } else { ?>
					<a href="<?= yii\helpers\Url::to(['dashboard/index']) ?>"> Go to Dashboard</a>   
				   <?php } ?>
			<?php }?>
            <?php if( in_array( $code , [403,503] ) ){?>
                <h1 class="error-number"><?= $code?></h1>
                <h2>Unauthorized Access</h2>
                <p>you are unauthorized for this page, but if you think it is problem then feel free to contact us. In the meantime, try refreshing.
                </p>
			 <?php }?>
             <?php if($code == 500){?>
                <h1 class="error-number">500</h1>
                <h2>Internal Server Error</h2>
                <p>We track these errors automatically, but if the problem persists feel free to contact us. In the meantime, try refreshing.
                </p>
            <?php }?>
        </div>
    </div>
</div>
