<div class="product-list-sec">
	<div class="container">
		<div class="category-list-sec">
			<div class="col-md-3 col-lg-3 col-sm-4 col-xs-4 left">
				<div class="product-image-sections-left">
					<img src="images/product.png">
				</div>
			</div>
			
			<div class="col-md-7 col-lg-7 col-sm-6 col-xs-6 middle">
				<div class="product-image-sections-middle">
					<h4>Pace Ready Meals</h4>
					<p>$10</p>
					<p class="stock">In stock</p>
					<div class="inner-product-data">
						<img src="images/product-l.png" class="inner-img">
						<h5>Lorem Ipsum</h5>
					</div>
				</div>
			</div>
			
			<div class="col-md-2 col-lg-2 col-sm-2 col-xs-2 right">
				<div class="product-image-sections-right">
					<img src="images/wishlist.png">
				</div>
			</div>
		</div>	
	</div>
</div>

<!-- Product List-->
<!-- Product List-two-->
<div class="product-list-sec">
	<div class="container">
		<div class="category-list-sec">
			<div class="col-md-3 col-lg-3 col-sm-4 col-xs-4 left">
				<div class="product-image-sections-left">
					<img src="images/product.png">
				</div>
			</div>
			
			<div class="col-md-7 col-lg-7 col-sm-6 col-xs-6 middle">
				<div class="product-image-sections-middle">
					<h4>Pace Ready Meals</h4>
					<p>$10</p>
					<p class="stock">In stock</p>
					<div class="inner-product-data">
						<img src="images/product-l.png" class="inner-img">
						<h5>Lorem Ipsum</h5>
					</div>
				</div>
			</div>
			
			<div class="col-md-2 col-lg-2 col-sm-2 col-xs-2 right">
				<div class="product-image-sections-right">
					<img src="images/wishlist.png">
				</div>
			</div>
		</div>	
	</div>
</div>

<!-- Product List-->
<!-- Product List-Three-->
<div class="product-list-sec">
	<div class="container">
		<div class="category-list-sec">
			<div class="col-md-3 col-lg-3 col-sm-4 col-xs-4 left">
				<div class="product-image-sections-left">
					<img src="images/product.png">
				</div>
			</div>
			
			<div class="col-md-7 col-lg-7 col-sm-6 col-xs-6 middle">
				<div class="product-image-sections-middle">
					<h4>Pace Ready Meals</h4>
					<p>$10</p>
					<p class="stock">In stock</p>
					<div class="inner-product-data">
						<img src="images/product-l.png" class="inner-img">
						<h5>Lorem Ipsum</h5>
					</div>
				</div>
			</div>
			
			<div class="col-md-2 col-lg-2 col-sm-2 col-xs-2 right">
				<div class="product-image-sections-right">
					<img src="images/wishlist.png">
				</div>
			</div>
		</div>	
	</div>
</div>

<!-- Product List-->
<!-- Product List-four-->
<div class="product-list-sec">
	<div class="container">
		<div class="category-list-sec">
			<div class="col-md-3 col-lg-3 col-sm-4 col-xs-4 left">
				<div class="product-image-sections-left">
					<img src="images/product.png">
				</div>
			</div>
			
			<div class="col-md-7 col-lg-7 col-sm-6 col-xs-6 middle">
				<div class="product-image-sections-middle">
					<h4>Pace Ready Meals</h4>
					<p>$10</p>
					<p class="stock">In stock</p>
					<div class="inner-product-data">
						<img src="images/product-l.png" class="inner-img">
						<h5>Lorem Ipsum</h5>
					</div>
				</div>
			</div>
			
			<div class="col-md-2 col-lg-2 col-sm-2 col-xs-2 right">
				<div class="product-image-sections-right">
					<img src="images/wishlist.png">
				</div>
			</div>
		</div>	
	</div>
</div>

<!-- Product List-->
<!-- Product List-Five-->
<div class="product-list-sec">
	<div class="container">
		<div class="category-list-sec">
			<div class="col-md-3 col-lg-3 col-sm-4 col-xs-4 left">
				<div class="product-image-sections-left">
					<img src="images/product.png">
				</div>
			</div>
			
			<div class="col-md-7 col-lg-7 col-sm-6 col-xs-6 middle">
				<div class="product-image-sections-middle">
					<h4>Pace Ready Meals</h4>
					<p>$10</p>
					<p class="stock">In stock</p>
					<div class="inner-product-data">
						<img src="images/product-l.png" class="inner-img">
						<h5>Lorem Ipsum</h5>
					</div>
				</div>
			</div>
			
			<div class="col-md-2 col-lg-2 col-sm-2 col-xs-2 right">
				<div class="product-image-sections-right">
					<img src="images/wishlist.png">
				</div>
			</div>
		</div>	
	</div>
</div>