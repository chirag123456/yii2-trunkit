<?php

use yii\helpers\Html;

?>

<section class="content-header">
      <h1>
        Notification
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
       <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("notification/index") ?>" >Notification</a></li>
        <li class="active">Edit Notification</li>
      </ol>
  </section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
         
            <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Edit Notification</h3>
                  <a href="<?= yii\helpers\Url::to(['notification/index'])?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>
                  <div class="country-create">

                        <?= $this->render('_edit_form', [
                            'model' => $model,
                        ]) ?>

                    </div>
            </div></div></div></section>
