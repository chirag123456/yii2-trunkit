<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

$this->title = 'Admin| Add Notification';
?>

<div class="state-form">
    <?php
    $form = ActiveForm::begin([
                'id' => 'notification-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
    ]);
    ?>
    <div class="row box-body">
        <div class="col-md-12">
            <div class="col-md-6">
                <?= $form->field($model, 'title')->textInput(['maxlength' => true, 'placeholder' => 'Enter Title']) ?>
            </div>
            <div class="col-md-6">
                <?= $form->field($model, 'description')->textInput(['maxlength' => true, 'placeholder' => 'Enter Description']) ?>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-12"> 
                <?php
                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                        echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                    } else {
                        echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right']);
                    }
                ?>
                <?php echo Html::a('Cancel', ['notification/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>
