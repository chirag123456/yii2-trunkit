<?php

use yii\helpers\Url;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;


$this->title = 'Trunkit';
?>        
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
        Notification Management
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Notification Management</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

               
                <div class="box-body">
                    <div class="city-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                       
                        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                        ?>

                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>                                    
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>
                        <div class="city-index">
                            <p>
                            <?php echo Html::a('Reset Grid', ['notification/index'], ['class' => 'btn btn-primary filter-reset']) ?>
                            </p>
                            <?php Pjax::begin(['id' => 'notification']) ?>  

                            <?=
                            GridView::widget([
                                'dataProvider' => $dataProvider,
                                'filterModel' => $searchModel,
                                'columns' => [
                                   [   'attribute' => 'id',
                                       'label' => '#ID',
                                       'contentOptions' => ['style' => 'width:40px;'],
                                    ],
                                    [
                                        'attribute' => 'from_user_id',
                                        'format' => 'raw',
                                        'value' => function ($model) {
                                            $mediaFileUrl = Yii::$app->request->hostInfo . USER_PROFILE_PATH . (isset($model->fromuser->image) ? $model->fromuser->image : 'default_user.png');
                                            //$imgUrl = dirname(Url::base(true)) . '/uploads/user/' . (isset($model->fromuser->image) ? $model->fromuser->image : 'default_user.png');
                                            $name = (isset($model->fromuser->first_name) ? $model->fromuser->first_name : $model->fromuser->username);

                                            return '<img data-toggle="tooltip" src="' . $mediaFileUrl . '" title="' . $name . '" alt="User Image" style="width:50px;height:50px;border-radius: 25px;">';
                                        },
                                        'filter' => false,
                                    ],
                                    [
                                        'attribute' => 'to_user_id',
                                        'format' => 'raw',
                                        'value' => function ($model) {
                                            $mediaFileUrl2 = Yii::$app->request->hostInfo . USER_PROFILE_PATH . (isset($model->touser->image) ? $model->touser->image : 'default_user.png');

                                            //$imgUrl = dirname(Url::base(true)) . '/uploads/user/' . (isset($model->touser->image) ? $model->touser->image : 'default_user.png');
                                            $name = (isset($model->touser->first_name) ? $model->touser->first_name : $model->touser->username);

                                            return '<img data-toggle="tooltip" src="' . $mediaFileUrl2 . '" title="' . $name . '" alt="User Image" style="width:50px;height:50px;border-radius: 25px;">';
                                        },
                                        'filter' => false,
                                    ],
                                    [
                                        'label' => 'Origin',
                                        'format' => 'raw',
                                        'value' => function ($model) {
                                            return $model->post->origin;
                                        },
                                        'filter' => false,
                                    ],
                                    [
                                        'label' => 'Destination',
                                        'format' => 'raw',
                                        'value' => function ($model) {
                                            return $model->post->destination;
                                        },
                                        'filter' => false,
                                    ],
                                    [
                                        'attribute' => 'title',
                                        'format' => 'raw',
                                        'filterInputOptions' => [
                                            'class' => 'form-control',
                                            'placeholder' => 'Search By Title'
                                        ],
                                    ],
                                    [
                                        'attribute' => 'description',
                                        'format' => 'raw',
                                        'filterInputOptions' => [
                                            'class' => 'form-control',
                                            'placeholder' => 'Search By Description'
                                        ],
                                    ],
                                    /*[
                                        'attribute' => 'type',
                                        'format' => 'raw',
                                        'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                        'filterInputOptions' => [
                                            'class' => 'form-control',
                                            'prompt' => 'Select'
                                        ],
                                        'filter' => ['TRIP' => 'TRIP', 'REQUEST' => 'REQUEST'],
                                    ],*/
                                    /*[
                                        'attribute' => 'is_active',
                                        'format' => 'raw',
                                        'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                        'filterInputOptions' => [
                                            'class' => 'form-control',
                                            'prompt' => 'Select'
                                        ],
                                        'filter' => [ACTIVE => "Active", INACTIVE => "Inactive"],
                                        'value' => function ($model) {
                                           
                                            if ($model->is_active == ACTIVE) {
                                                return Html::tag('span', 'Active', ['class' => ['label', 'label-success']]);
                                            } elseif ($model->is_active == INACTIVE) {
                                                return Html::tag('span', 'Inactive', ['class' => ['label', 'label-danger']]);
                                            }
                                        },
                                    ],*/
                                    [
                                        'attribute' => 'is_seen',
                                        'format' => 'raw',
                                        'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                        'filterInputOptions' => [
                                            'class' => 'form-control',
                                            'prompt' => 'Select'
                                        ],
                                        'filter' => [SEEN => "Seen", UNSEEN => "Unseen"],
                                        'value' => function ($model) {
                                           
                                            if ($model->is_seen == SEEN) {
                                                return Html::tag('span', 'Seen', ['class' => ['label', 'label-success']]);
                                            } elseif ($model->is_seen == UNSEEN) {
                                                return Html::tag('span', 'Unseen', ['class' => ['label', 'label-danger']]);
                                            }
                                        },
                                    ],
                                    [
                                        'class' => 'yii\grid\ActionColumn',
                                        'header' => 'Actions',
                                        'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                        'template' => '{seen}', //{delete}
                                        'buttons' => [
                                            'seen' => function ($url, $model) {
                                                $seen = '<i class="fa fa-eye-slash" title="UnSeen" data-toggle="tooltip"></i>';
                                                if ($model->is_seen == ACTIVE) {
                                                    $seen = '<i class="fa fa-eye" title="Seen" data-toggle="tooltip"></i>';
                                                }
                                                return $seen;
                                            },
                                            'delete' => function ($url, $model) {
                                                return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                            'data-confirm' => DELETESTATUS . " notification?", // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Delete',
                                                ]);
                                            },
                                        ],
                                        'urlCreator' => function ($action, $model, $key, $index) {

                                            if ($action === 'delete') {
                                                return \yii\helpers\Url::toRoute(['notification/delete/' . $key]);
                                            }
                                        }
                                    ],
                                ],
                            ]);
                            ?>
<?php Pjax::end() ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>