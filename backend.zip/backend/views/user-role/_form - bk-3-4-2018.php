<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'NCAA | Add Role';
?>

<div class="state-form">
    <?php
    $form = ActiveForm::begin([
                'id' => 'userrole-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
    ]);
    ?>
    <div class="row box-body">
	<div class="col-md-12" id="role-name">
            <div class="col-md-6">
                <?= $form->field($model, 'name')->textInput(['maxlength' => true, 'placeholder' => 'Enter Role Name', 'id'=>'name']) ?>
                <div class="help-block-name" style="display:none;color: #dd4b39;">Role Name cannot be blank.</div>
            </div>
            <div class="col-md-6">
                <?php
                    /*$data = ['1' => 'Super Admin', '2' => 'Admin', '3' => 'Principle', '4' => 'Teacher', '5' =>'Clerk', '6' => 'Student'];
                    echo $form->field($model, 'type')->widget(
                                    Select2::classname(), [
                            'data' => $data,
                            'options' => ['placeholder' => 'Select Role Type'],
                    ])->label();*/
                    //echo $form->field( $model, 'is_admin')->dropDownList( ['0'=>'No','1'=>'Yes'] , ['class' =>'form-control input-medium' ] );
                ?>
            </div>
        </div>
        <div class="col-md-12 add-module" style="display: none;">
            <?php
                //echo Html::button('Check All ', ['class' => 'btn btn-primary check-module pull-left', 'id'=>'check-all-mod']);
            ?>
            <?php //echo $form->field($model, 'description')->textArea(['maxlength' => true, 'placeholder' => 'Enter Description'])
                $selectArray = ['user' => 'User Management', 'university' => 'University/Board', 'location' => 'Location', 'standard-group' => 'Standard Group', 'standard' => 'Standard',
				   'academic-year' => 'Academic Year', 'student-group' => 'Student Group', 'student' => 'Student',
				 'subject' => 'Subject', 'subject-group' => 'Subject Group', 'site-configuration' => 'Site Configuration', 'school' => 'School'];
                    echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                    echo Html::label('Modules List'); ?>
                    <p><label><input type="checkbox" id="check-all-mod"/> All Modules</label></p>
            <?php   echo Html::Tag('div' ,
                                    Html::checkboxList(
                                                    'access_role' , [] , $selectArray ,
                                                    [ 'class' => 'icheck-inline icheck-inline-custom lbl_modules' , 'itemOptions' => [ 'class' => 'icheck ascascaj' ] ], ['separator'=>'br']
                                    ) . Html::tag( 'div' , 'Note : Above all are list of Menu(Left Side). Select from list to access it.' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                    );
                    echo Html::endTag('div');
                
                    //echo $form->field( $model , 'description')->textarea();
                ?>
                <div class="help-block-mod" style="display:none;color: #dd4b39;">Please select Module.</div>
        </div>
        <div class="add-action" style="display:none;">
            <div class="col-md-12" id="div_user" style="display: none;">
                <input type="hidden" name="user">
                <p><label><input type="checkbox" id="check-all-action"/> All Actions</label></p>
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('User Management');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_user' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_university" style="display: none;">
                <input type="hidden" name="university">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('University / Board');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_university' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_location" style="display: none;">
                <input type="hidden" name="location">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Location');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_location' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_standard-group" style="display: none;">
                <input type="hidden" name="standard-group">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Standard Group');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_standard-group' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_standard" style="display: none;">
                <input type="hidden" name="standard">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Standard');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_standard' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_academic-year" style="display: none;">
                <input type="hidden" name="academic-year">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Academic Year');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_academic-year' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_student-group" style="display: none;">
                <input type="hidden" name="student-group">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Action List');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_student-group' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_student" style="display: none;">
                <input type="hidden" name="student">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Student');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_student' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_subject" style="display: none;">
                <input type="hidden" name="subject">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Subject');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_subject' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_subject-group" style="display: none;">
                <input type="hidden" name="subject-group">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Subject Group');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_subject-group' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_site-configuration" style="display: none;">
                <input type="hidden" name="site-configuration">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Site Configuration');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_site-configuration' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-12" id="div_school" style="display: none;">
                <input type="hidden" name="school">
                <?php 
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('School');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_school' , [] , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
        </div>
        
        <div class="col-md-12">
            <div class="col-md-8"></div>
            <div class="col-md-4"> 
                <?php
                    if (isset($_GET['id']) && !empty($_GET['id'])) {
                        echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                    } else {
                        
                        echo Html::button('Next', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'add-button']);
                        
                        echo Html::button('Previous', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'back-button1', 'style'=>'display:none;']);
                        echo Html::button('Next', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'add-button2', 'style'=>'display:none;']);
                        
                        //echo Html::button('Next', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'add-button3', 'style'=>'display:none;']);
                        
                        echo Html::button('Previous', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'back-button2', 'style'=>'display:none;']);
                        echo Html::submitButton('Submit', ['class' => 'btn btn-primary pull-right', 'id'=>'add-button-sub', 'style'=>'display:none;']);
                        //echo Html::button('Previous', ['class' => 'btn btn-primary back-button pull-right']);
                    }
                ?>
                <?php  echo Html::a('Cancel', ['user-role/index'], ['class' => 'btn btn-primary pull-right cancel-button back1', 'style' => 'margin-right: 5px;']);
                    //echo Html::button('Back', ['class' => 'btn btn-primary pull-right cancel-button back1', 'style' => 'margin-right: 5px;display:none;']);
                ?>
            </div>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>
<?php
$this->registerJs("
    //$('#check-all-mod').on('click', function (e) {
        //$('input:checkbox').attr('checked','checked');
    //});
    
    $('#check-all-mod').change(function () {
        $('.icheck').prop('checked', $(this).prop('checked'));
    });
    
    $('#check-all-action').change(function () {
        $('.actioncheck').prop('checked', $(this).prop('checked'));
    });
");
$this->registerJs("
    $('#add-button').on('click', function (e) {
        var role = $('#name').val();
        
            if(role==''){
                $('.help-block-name').show();
                return false;
            } else {
                $('.add-module').show();
                $('#role-name').hide();
                $(this).hide();
                $('#add-button2').show();
                //$('.back1').show();
                $('#back-button1').show();
            }
        });
        
    $('#back-button1').on('click', function (e) {
            $('.add-module').hide();
            $('#role-name').show();
            $(this).hide();
            $('#add-button2').hide();
            $('#add-button').show();
    });    
        
    $('#add-button2').on('click', function (e) {
            var con = [];
            $('.icheck:checkbox:checked').each(function(i){
              con[i] = $(this).val();
              $('#div_'+con[i]).show();
            });
        
            if(con==''){
                $('.help-block-mod').show();
                return false;
            } else {
                $('.add-module').hide();
                $('.add-action').show();
                $(this).hide();
                $('#back-button1').hide();
                $('#add-button-sub').show();
                $('#back-button2').show();
            }
                
    });
    
    $('#back-button2').on('click', function (e) {
            $('.add-module').show();
            $('#add-button-sub').hide();
            $(this).hide();
            $('.add-action').hide();
            $('#add-button2').show();
            $('#back-button2').hide();
            $('#back-button1').show();
    });
    
    $('#add-button-sub').on('click', function (e) {
        var action = [];
        $('input:checkbox[class=actioncheck]:checked').each(function () {
            action[i] = $(this).val();
        });
       
        if(action==''){
            $('.help-block-mod').show();
            return false;
        } else {
            //$('#add-action').hide();
            $(this).hide();
            //$('#add-button-sub').show();
        }
                
    });
        
");

$this->registerCss("
    .lbl_modules label{
        display: inherit;
    }
    .lbl_actions label{
        display: inherit;
    }
");
?>