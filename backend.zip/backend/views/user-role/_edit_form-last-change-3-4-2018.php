<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use common\models\userrole\UserAccess;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'NCAA | Edit User Role';
?>

<div class="city-form">
    <?php
    $form = ActiveForm::begin([
                'id' => 'userrole-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
    ]);
    ?>
    <div class="box-body">
        <div class="col-md-12" id="role-name">
            <div class="col-md-6">
                <?= $form->field($model, 'name')->textInput(['maxlength' => true, 'placeholder' => 'Enter User Role Name']) ?>
            </div>
            <div class="col-md-6">
                <?php
                        
                ?>
            </div>
        </div>
        <?php $userAccess = UserAccess::find()->where(['name' => $model->name])->one();
            $json_arr = json_decode($userAccess->access);
            $module = [];
            $act = '';
            if(!empty($json_arr)){
                foreach($json_arr as $k=>$v){
                    $module[$v->module] = $v->module;

                    foreach ($v->act as $ak=>$av){
                        $act['access_'.$v->module][$av] = $av;
                    }
                }
            }
        ?>
        <div class="col-md-12 add-module" style="display: none;">
            <?php 
            //echo $form->field($model, 'description')->textArea(['maxlength' => true, 'placeholder' => 'Enter Description'])
                $selectArray = ['user' => 'User Management', 'university' => 'University/Board', 'location' => 'Location', 'standard-group' => 'Standard Group', 'standard' => 'Standard',
				   'academic-year' => 'Academic Year', 'student-group' => 'Student Group', 'student' => 'Student',
				 'subject' => 'Subject', 'subject-group' => 'Subject Group', 'site-configuration' => 'Site Configuration', 'school' => 'School'];
                    echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                    echo Html::label('Modules List');
            ?>        
                <p><label><input type="checkbox" id="check-all-mod"/> All Modules</label></p>
            <?php   echo Html::Tag('div' ,
                                    Html::checkboxList(
                                                    'access_role' , $module , $selectArray ,
                                                    [ 'class' => 'icheck-inline icheck-inline-custom lbl_modules custom-add-role-check ' , 'itemOptions' => [ 'class' => 'icheck' ] ], ['separator'=>'br']
                                    ) . Html::tag( 'div' , 'Note : Above all are list of Menu(Left Side). Select from list to access it.' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                    );
                    echo Html::endTag('div');
                
                    //echo $form->field( $model , 'description')->textarea();
                ?>
                <div class="help-block-mod" style="display:none;color: #dd4b39;">Please select Module.</div>
        </div>
        <div class="add-action user-role-access-tab" style="display:none;">
            <div class="role-access-tab" id="div_user" style="display: none;">
                <input type="hidden" name="user">
                <?php 
                    if(!isset($act['access_user']))
                        $acc_user = '[]';
                    else
                        $acc_user = $act['access_user'];
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('User Management');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_user' , $acc_user , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_university" style="display: none;">
                <input type="hidden" name="university">
                <?php 
                    if(!isset($act['access_university']))
                        $acc_university = '[]';
                    else
                        $acc_university = $act['access_university'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('University / Board');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_university' , $acc_university , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_location" style="display: none;">
                <input type="hidden" name="location">
                <?php 
                    if(!isset($act['access_location']))
                        $acc_location = '[]';
                    else
                        $acc_location = $act['access_location'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Location');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_location' , $acc_location , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_standard-group" style="display: none;">
                <input type="hidden" name="standard-group">
                <?php 
                    if(!isset($act['access_standard-group']))
                        $acc_standardgrp = '[]';
                    else
                        $acc_standardgrp = $act['access_standard-group'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Standard Group');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_standard-group' , $acc_standardgrp , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_standard" style="display: none;">
                <input type="hidden" name="standard">
                <?php 
                    if(!isset($act['access_standard']))
                        $acc_standard = '[]';
                    else
                        $acc_standard = $act['access_standard'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Standard');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_standard' , $acc_standard , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_academic-year" style="display: none;">
                <input type="hidden" name="academic-year">
                <?php 
                    if(!isset($act['access_academic-year']))
                        $acc_academicyr = '[]';
                    else
                        $acc_academicyr = $act['access_academic-year'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Academic Year');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_academic-year' , $acc_academicyr , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_student-group" style="display: none;">
                <input type="hidden" name="student-group">
                <?php 
                    if(!isset($act['access_student-group']))
                        $acc_studentgrp = '[]';
                    else
                        $acc_studentgrp = $act['access_student-group'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Action List');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_student-group' , $acc_studentgrp , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_student" style="display: none;">
                <input type="hidden" name="student">
                <?php 
                    if(!isset($act['access_student']))
                        $acc_student = '[]';
                    else
                        $acc_student = $act['access_student'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Student');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_student' , $acc_student , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_subject" style="display: none;">
                <input type="hidden" name="subject">
                <?php 
                    if(!isset($act['access_subject']))
                        $acc_subject = '[]';
                    else
                        $acc_subject = $act['access_subject'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Subject');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_subject' , $acc_subject , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_subject-group" style="display: none;">
                <input type="hidden" name="subject-group">
                <?php 
                    if(!isset($act['access_subject-group']))
                        $acc_subjectgrp = '[]';
                    else
                        $acc_subjectgrp = $act['access_subject-group'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Subject Group');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_subject-group' , $acc_subjectgrp , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_site-configuration" style="display: none;">
                <input type="hidden" name="site-configuration">
                <?php 
                    if(!isset($act['access_site-configuration']))
                        $acc_siteconf = '[]';
                    else
                        $acc_siteconf = $act['access_site-configuration'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('Site Configuration');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_site-configuration' , $acc_siteconf , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
            <div class="role-access-tab" id="div_school" style="display: none;">
                <input type="hidden" name="school">
                <?php 
                    if(!isset($act['access_school']))
                        $acc_school = '[]';
                    else
                        $acc_school = $act['access_school'];
                    
                    $selectActionArray = ['index' => 'List', 'add' => 'Add', 'update' => 'Update', 'delete' => 'Delete'];
                        echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                        echo Html::label('School');
                        echo Html::Tag('div' ,
                                        Html::checkboxList(
                                                        'access_school' , $acc_school , $selectActionArray ,
                                                        [ 'class' => 'icheck-inline icheck-inline-custom lbl_actions' , 'itemOptions' => [ 'class' => 'actioncheck' ] ], ['separator'=>'br']
                                        ) . Html::tag( 'div' , '' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                        );
                        echo Html::endTag('div');
                ?>
            </div>
        </div>
    </div>
        <div class="box-footer clearfix">
                <?php
                //if (isset($_GET['id']) && !empty($_GET['id'])) {
                    //echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                //} else {
                    //echo Html::submitButton('Create', ['class' => 'btn btn-primary pull-right']);
                    echo Html::button('Next', ['class' => 'btn btn-primary add-button pull-right m-r-5', 'id'=>'add-button']);
                    
                    echo Html::button('Next', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'add-button2', 'style'=>'display:none;']);
                    echo Html::button('Previous', ['class' => 'btn btn-primary add-button pull-right m-r-5', 'id'=>'back-button1', 'style'=>'display:none;']);
                    
                    
                    //echo Html::button('Next', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'add-button3', 'style'=>'display:none;']);
                    
                    echo Html::button('Previous', ['class' => 'btn btn-primary add-button pull-right', 'id'=>'back-button2', 'style'=>'display:none;']);
                    echo Html::submitButton('Submit', ['class' => 'btn btn-primary pull-right', 'id'=>'add-button-sub', 'style'=>'display:none;']);
                //}
                ?>
                <?php echo Html::a('Cancel', ['user-role/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>
<?php
$this->registerJs("
    //$('#check-all-mod').on('click', function (e) {
        //$('input:checkbox').attr('checked','checked');
    //});
    
    $('#check-all-mod').change(function () {
        //$('.icheck').prop('checked', $(this).prop('checked'));
        $('.icheck').attr('checked', this.checked);
    });
");

$this->registerJs("
    $('#add-button').on('click', function (e) {
        var role = $('#name').val();
        
            if(role==''){
                $('.help-block-name').show();
                return false;
            } else {
                $('.add-module').show();
                $('#role-name').hide();
                $(this).hide();
                $('#add-button2').show();
                $('.back1').show();
                $('#back-button1').show();
            }
        });
        
    $('#back-button1').on('click', function (e) {
            $('.add-module').hide();
            $('#role-name').show();
            $(this).hide();
            $('#add-button2').hide();
            $('#add-button').show();
    });
    
    $('#add-button2').on('click', function (e) {
            var con = [];
            $(':checkbox:checked').each(function(i){
              con[i] = $(this).val();
              $('#div_'+con[i]).show();
            });
     
            if(con==''){
                $('.help-block-mod').show();
                return false;
            } else {
                $('.add-module').hide();
                $('.add-action').show();
                $(this).hide();
                $('#back-button1').hide();
                $('#add-button-sub').show();
                $('#back-button2').show();
            }
                
    });
    
    $('#back-button2').on('click', function (e) {
            $('.add-module').show();
            $('#add-button-sub').hide();
            $(this).hide();
            $('.add-action').hide();
            $('#add-button2').show();
            $('#back-button2').hide();
            $('#back-button1').show();
    });
    
    $('#add-button-sub').on('click', function (e) {
        var action = [];
        $('input:checkbox[class=actioncheck]:checked').each(function () {
            action[i] = $(this).val();
        });
       
        if(action==''){
            $('.help-block-mod').show();
            return false;
        } else {
            //$('#add-action').hide();
            $(this).hide();
            //$('#add-button-sub').show();
        }
                
    });
        
");

$this->registerCss("
    .lbl_modules label{
        display: inherit;
    }
    .lbl_actions label{
        display: inherit;
    }
");
?>