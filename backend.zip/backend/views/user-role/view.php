<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
?>

<section class="content-header">
      <h1>
        Role Access View
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-dashboard"></i> Home</a></li>
         <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("user-role/index") ?>" >User Role</a></li>
        <li class="active">Role Access View</li>
      </ol>
  </section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
          <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">View Role Access</h3>
                   <a href="<?= yii\helpers\Url::to(['user-role/index'])?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>
                <div class="box-body">
                <?php //echo '<pre>'; print_r($data); die; ?>
                <!-- <div>
                    <lable><b>Role Name: </b></lable>
                    <span><?php //echo $data['role_name']; ?></span>
                </div> -->
                <div class="box">
                <div class="box-header with-border">
                    <h4 class="box-title"><b>Role Name:</b> <span><?php echo $data['role_name']; ?></span></h4>
                </div>
                <div class="box-body"> 
                    <table class="table table-bordered">
                        <thead>
                            <th>Modules Name</th>

                            <th class="text-center">List</th>
                            <th class="text-center">Add</th>
                            <th class="text-center">Update</th>
                            <th class="text-center">Delete</th>
                            <!--<th class="text-center">Import</th>
                            <th class="text-center">Export</th>

                            <th>List</th>
                            <th>Add</th>
                            <th>Update</th>
                            <th>Delete</th>

                            <th class="text-center">List</th>
                            <th class="text-center">Add</th>
                            <th class="text-center">Update</th>
                            <th class="text-center">Delete</th>
                            <th class="text-center">Set State</th>
                            <th class="text-center">Set City</th>-->

                        </thead>
                        <?php
            //echo '<pre>'; print_r($data); //die;
    //echo count($data['modules']); die;
                            $cnt_mode = count($data['modules']);
                            $i=0;
                            foreach ($data as $key => $value) { ?>
                             <tr>
                                <td>
                                    <?php if($i<$cnt_mode)
                                        {  
                                            echo $data['modules'][$i]; 
                                        } ?>
                                </td>
                                 <?php if(isset($data['actions']) && !empty($data['actions'])){
                                 foreach ($data['actions'] as $k => $val) { //echo $k; 
                    //echo $k.'<pre>'; print_r($val);
                                 //echo $data['actions'][$i][$k]; ?>
                                        <?php //if($k<$i){  //echo $data['actions'][$i];
                                            //if(isset($data['actions'][$i][$k]) && $data['actions'][$i][$k]!=''){

                                            foreach($data['actions'][$k] as $ke=>$va){ //echo $k; 

                        //echo '<pre>'; print_r($data['actions'][$k]);
                                               
                                                ?>

                                                <td>
                                                     <?php //if(isset($val[$k]) && $val[$k]!=''){
                                                        //echo $val[$k]; } ?>
                                                </td>
                                        <?php  }
                                        ?>
                                                
                                        <?php //} 
                                    //} ?>
                                 <?php } //die;
                                 } //die; ?>
                             </tr>   
                                
                        <?php  $i++; } //die;

                        ?>

                        <?php /*if(isset($data['modules']) && $data['modules']!=''){
                            foreach($data['modules'] as $key=>$val){ ?>
                            <tr>
                                <td><?php echo $val; ?></td>

                                    <?php //echo '<pre>'; print_r($data['actions']); 
                                    
                                    $data_arr = [];
                                    $i=0;
                                    foreach($data['actions'] as $v){
									
                                        if( $v[0] == 'index' && in_array($val,['university','student','result','staff','standard','academic-year'])){
                                                echo '<td class="text-center">true</td>';
                                        }

                                        else if(isset($v[1]) &&  $v[1] == 'add' && in_array($val,['university','student','result','staff','standard','academic-year'])){
                                                echo '<td class="text-center">true</td>';
                                        }

                                        else if(isset($v[2]) &&  $v[2] == 'update' && in_array($val,['university','student','result','staff','standard','academic-year'])){
                                                echo '<td class="text-center">true</td>';
                                        }

                                        else if(isset($v[3]) && $v[3] == 'delete' && in_array($val,['university','student','result','staff','standard','academic-year'])){
                                                echo '<td class="text-center">true</td>';
                                        }else{
                                                echo '<td class="text-center">false</td>';
                                        }*/
									
									
									//echo '<pre>'; print_r($v);
                                        //$data_arr[$data['actions'][$k]] = 
                                        //$i++;
                                    //} die;
                                        //$i = 0;
                                        //foreach($data['actions'] as $k=>$v){ //echo $v; 
                                        //echo $k.'<pre>'; print_r($v);  
                                        //echo '<pre>'; print_r($data['actions'][$i][$k]); //echo $i.'<br>'; ?>
                                            <?php /*if(isset($data['actions'][$i][$k]) && $data['actions'][$i][$k]=='index'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger"></i></td>
                                            <?php } ?>
                                            <?php if(isset($data['actions'][$i][$k]) && $data['actions'][$i][$k]=='add'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>

                                            <?php if(isset($data['actions'][$i][$k]) && $data['actions'][$i][$k]=='update'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>

                                            <?php if(isset($data['actions'][$i][$k]) && $data['actions'][$i][$k]=='delete'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>
                                                
                                            <?php if(isset($data['actions'][$i][$k]) && $data['actions'][$i][$k]=='set-state'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>

                                            <?php if(isset($data['actions'][$i][$k]) && $data['actions'][$i][$k]=='set-city'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php }*/
                                            
                                            /*if(isset($v[$key][$k]) && $v[$key][$k]=='index'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>
                                
                                            <?php if(isset($v[$key][$k]) && $v[$key][$k]=='add'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php } else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php }
                                            if(isset($v[$key][$k]) && $v[$key][$k]=='update'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php } else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } if(isset($v[$key][$k]) && $v[$key][$k]=='delete'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php } else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php }*/ /*if(isset($v[$k]) && $v[$k]=='set-state'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php }
                                            if(isset($v[$k]) && $v[$k]=='set-city'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php }*/ ?>   
                                       
                                
                                    <?php //if(isset($v[$k]) && $v[$k]!=''){
                                        
                                        //echo $v[$k].'<br>';
                                    //}
                                    
                                            //$i++; } //die;  ?>
                                
                                    

                                    <?php /*foreach($data['actions'] as $k=>$v){ ?>
                                            <?php if(!isset($data['actions'][$key][$k])){ ?>
                                                <td>&nbsp;</td>
                                            <?php } else { ?>
                                            <td><?php echo $data['actions'][$key][$k]; ?></td>
                                            <?php } ?>    
                                    <?php }*/ ?>

                                    <?php //echo '<pre>'; print_r($data); die;
                                        /*foreach($data['actions'] as $k=>$v){ ?>
                                            <?php if($data['actions'][$key][$k]=='index'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger"></i></td>
                                            <?php } ?>


                                            <?php if($data['actions'][$key][$k]=='add'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>

                                            <?php if($data['actions'][$key][$k]=='update'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>

                                            <?php if($data['actions'][$key][$k]=='delete'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>
                                                
                                            <?php if($data['actions'][$key][$k]=='set-state'){ ?>
                                                <td class="text-center"><i class="fa fa-check text-success text-center"></i></td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>

                                            <?php if($data['actions'][$key][$k]=='set-city'){ ?>
                                                <td class="text-center">right</td>
                                            <?php }else{ ?>
                                                <td class="text-center"><i class="fa fa-times text-danger text-center"></i></td>
                                            <?php } ?>    
                                    <?php } ?>

                            </tr>
                            <?php } //die;
                        } else { ?>
                            <tr><td>No Records found.</td></tr>
                        <?php }*/ ?>
                    </table>
                </div>
                </div>
                
            </div></div></div></div></section>