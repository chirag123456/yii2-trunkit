<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use common\models\userrole\UserAccess;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'NCAA | Edit User Role';
?>

<div class="city-form">
    <?php
    $form = ActiveForm::begin([
                'id' => 'userrole-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
    ]);
    ?>
    <div class="row box-body">
        <div class="col-md-12">
            <div class="col-md-6">
                <?= $form->field($model, 'name')->textInput(['maxlength' => true, 'placeholder' => 'Enter User Role Name']) ?>
            </div>
            <div class="col-md-6">
                <?php
                        /*echo $form->field($model, 'school_id')->widget(
                                        Select2::classname(), [
                                'data' => ArrayHelper::map(\common\models\school\School::find()
                                ->where(['is_active'=>ACTIVE,'is_delete'=>NOT_DELETED ])->asArray()->all(), 'id', 'school_name'),
                                'options' => ['placeholder' => 'Select School'],
                        ])->label();*/
                    echo $form->field($model, 'is_admin')->dropDownList( ['0'=>'No','1'=>'Yes'] , ['class' =>'form-control input-medium']);
                ?>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-6">
                <?php //echo $form->field($model, 'description')->textArea(['maxlength' => true, 'placeholder' => 'Enter Description'])
                $selectArray = ['user' => 'User Management', 'university' => 'University/Board', 'location' => 'Location', 'standard-group' => 'Standard Group', 'standard' => 'Standard',
				   'academic-year' => 'Academic Year', 'student-group' => 'Student Group', 'student' => 'Student',
				 'subject' => 'Subject', 'subject-group' => 'Subject Group', 'site-configuration' => 'Site Configuration'];
                $access = [];
                $model_user_access = UserAccess::findOne( [ 'name' => $model->name ] );
                if( $model_user_access != null ){
                        if( $model_user_access->access != '' ){
                                $access = explode(',', $model_user_access->access);
                        }
                }
                    echo Html::beginTag('div' , [ 'class' => 'form-group' ]);
                    echo Html::label('Access Menu');
                    echo Html::Tag('div' ,
                                    Html::checkboxList(
                                                    'access_role' , $access , $selectArray ,
                                                    [ 'class' => 'icheck-inline icheck-inline-custom' , 'itemOptions' => [ 'class' => 'icheck' ] ]
                                    ) . Html::tag( 'div' , 'Note : Above all are list of Menu(Left Side). Select from list to access it.' , [ 'help-block-custom' ] ), [ 'class' => 'input-group' , 'style' => 'margin-bottom:10px' ]
                    );
                    echo Html::endTag('div');
                ?>
            </div>
            <div class="col-md-6">
                <?php echo $form->field( $model , 'description')->textarea(); ?>
            </div>
        </div>
        <div class="col-md-12">
            <div class="col-md-8">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {

                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                } else {
                    echo Html::submitButton('Create', ['class' => 'btn btn-primary pull-right']);
                }
                ?>
                <?php echo Html::a('Cancel', ['user-role/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
</div>