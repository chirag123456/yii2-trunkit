<?php

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;


$this->title = 'Admin | Vehicle Color Model';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Vehicle Color</h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Vehicle Color</li>
    </ol>
</section>
<section class="content">
   
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">
                <?php if (isset($_GET['id']) && !empty($_GET['id'])) { ?>
                    <div class="box-body edit-custom-popup-form" style="border: 1px solid #ddd;margin: 10px;">
                        <?php echo $this->render('_form/_edit', ['model' => $model]); ?>
                    </div>
                <?php } else { ?>
                    <div class="box-body add-custom-popup-form" style="display: none;border: 1px solid #ddd;margin: 10px;">
                        <?php echo $this->render('_form/_add', ['model' => $model]); ?>
                    </div>
                <?php } ?>
             
                <div class="box-body">
                    <div class="user-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get',
                                    'action' => yii\helpers\Url::base() . '/vehicle-color/index',
                                    'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                        $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                        ?>
                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                            <?php echo Html::button('Add Vehicle Color', ['class' => 'btn btn-primary add-button']); ?>
                            <?php echo Html::a('Reset', ['vehicle-color/index'], ['class' => 'btn btn-primary filter-reset']) ?>
                        </p>
                        <?php
                        echo
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'filterModel' => $searchModel,
                            'showOnEmpty' => true,
                            'columns' => [
                                [   'attribute' => 'id',
                                    'label' => '#ID',
                                    'contentOptions' => ['style' => 'width:40px;'],
                                ],
                             
                                [
                                    'attribute' => 'name',
                                    'label' => 'Vehicle Color',
                                    'headerOptions' => ['title' => 'sort by'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Vehicle Color'
                                    ],
                                ],
                                [
                                    'attribute' => 'is_active',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:150px;'],
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select status'
                                    ],
                                    'format' => 'raw',
                                    'label' => 'Status',
                                    'filter' => [ACTIVE => "Active", INACTIVE => "InActive"],
                                    'value' => function ($model) {
                                        if ($model->is_active == ACTIVE) {
                                            return Html::tag('span', 'Active', ['class' => ['label', 'label-success']]);
                                        } elseif ($model->is_active == INACTIVE) {
                                            return Html::tag('span', 'InActive', ['class' => ['label', 'label-danger']]);
                                        }
                                    },
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{update} {status} {delete}',
                                    'buttons' => [
                                        'status' => function ($url, $model) {
                                            if ($model->is_active == ACTIVE) {
                                                return Html::a('<span class="glyphicon glyphicon-remove-circle" style="color:#d9534f"></span>', $url, [
                                                            'class' => '',
                                                            'data-confirm' => INACTIVESTATUS, // <-- confirmation works...
                                                            'data-method' => 'post',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'InActive'
                                                ]);
                                            } else {
                                                return Html::a('<span class="glyphicon glyphicon-ok-circle" style="color:#5cb85c"></span>', $url, [
                                                            'data-confirm' => ACTIVESTATUS, 
                                                            'data-method' => 'post',
                                                            'class' => '',
                                                            'title' => Yii::t('app', 'Status'),
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Active'
                                                ]);
                                            }
                                        },
                                        'delete' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-trash" style="color:#3c8dbc;"></span>', $url, [
                                                        'data-confirm' => DELETESTATUS, 
                                                        'data-method' => 'post',
                                                        'class' => 'delete',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Delete',
                                            ]);
                                        },
                                        'update' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                       
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'Edit',
                                            ]);
                                        }
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'status') {
                                            return \yii\helpers\Url::toRoute(['vehicle-color/status/' . $key]);
                                        } else if ($action === 'update') {
                                            return \yii\helpers\Url::toRoute(['vehicle-color/index/' . $key]);
                                        } else if ($action === 'delete') {
                                            return \yii\helpers\Url::toRoute(['vehicle-color/delete/' . $key]);
                                        }
                                    }
                                ],
                            ],
                        ]);
                        ?>
                   
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $this->registerJs("
       $('.add-button').hide();
");
}
?>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
        var page_size = '" . $_GET['per-page'] . "';
        $('#pagination').val(page_size);
        $('#pagination option:selected',page_size).text();
    ");
}
?>
<?php
$this->registerJs("
    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
<?php
$this->registerJs("
    $('.add-button').on('click', function (e) {
        $(this).hide();
        $('.add-custom-popup-form').show();
    });
    $('.remove').on('click', function (e) {
        $('.add-custom-popup-form').hide();
        $('.add-button').show();
    });
");
?>
