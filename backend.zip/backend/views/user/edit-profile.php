<?php
use yii\helpers\Html;
?>
<section class="content-header">
      <h1>
        Admin Profile
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index")?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("user/admin-profile") ?>" >Admin Profile</a></li>
        <li class="active">Edit</li>
      </ol>
  </section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
          <!-- general form elements -->
            <div class="box box-primary">
				<div class="box-header with-border">
                  <h3 class="box-title">Edit Profile</h3> 
                    <a href="<?= yii\helpers\Url::to(['user/admin-profile'])?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>
                <!-- /.box-header -->
                <!-- form start -->

                    <div class="user-create"> 

                        <?= $this->render('_edit_profile_form', [
                            'model' => $model,
                        ]) ?>

                    </div>
            </div>
        </div>
    </div>
</section>