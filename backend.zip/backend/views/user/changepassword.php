<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
?>

<section class="content-header">
    <h1>
        Change Password
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("user/admin-profile") ?>" >Admin Profile</a></li>
        <li class="active">Change Password</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Change Password</h3> 
                    <a href="<?php echo yii\helpers\Url::to(['user/admin-profile']) ?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>
                <section class="content">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- general form elements -->

                            <!-- /.box-header -->
                            <!-- form start -->

                            <div class="user-create"> 

                                <?php
                                $form = ActiveForm::begin([
                                            'id' => "change-password",
                                            'enableAjaxValidation' => true,
                                            'enableClientValidation' => true]);
                                ?>         
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class=" col-md-6">
                                            <?php echo $form->field($model, 'old_password')->passwordInput(['maxlength' => true, 'placeholder' => 'Enter Old Password']) ?>
                                        </div>
                                        <div class=" col-md-6">
                                            <?php echo $form->field($model, 'new_password')->passwordInput(['maxlength' => 15, 'minlength' => 6, 'placeholder' => 'Enter New Password']) ?>
                                        </div>
                                        <div class=" col-md-6">
                                        <?php echo $form->field($model, 'confirm_password')->passwordInput(['maxlength' => 15, 'minlength' => 6, 'placeholder' => 'Enter Confirm Password']) ?>
                                        </div>
                                    </div>
                                    <div class=" col-md-12">
                                <?php echo Html::submitButton("Change Password", ['class' => 'btn btn-primary submit pull-right']); ?>
                                <?php echo Html::a('Cancel', ['user/admin-profile'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
                                    </div>
                                </div>

                            <?php ActiveForm::end(); ?>

                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
</section>