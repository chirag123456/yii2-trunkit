<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php');
?>
<section class="content-header">
    <h1>
        Admin Profile
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Admin Profile</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title">Profile: <?= $model->first_name ?></h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class=" col-md-6 col-lg-6 "> 
                                <table class="table table-user-information">
                                    <tbody>
                                        <tr>
                                            <td>Email</td>
                                            <td class="fa fa-envelope-o"> <a href="mailto:info@support.com"><?= $model->email ?></a></td>
                                        </tr>
                                        <tr>
                                            <td>Username</td>
                                            <td> <?= $model->first_name ?></td>
                                        </tr>

                                        <tr>
                                            <td>Last Name</td>
                                            <td> <?= $model->last_name ?></td>
                                        </tr>

                                    </tbody>
                                </table>

                                <a href="<?= \Yii::$app->getUrlManager()->createUrl(['user/profile/' . Yii::$app->user->identity->id]) ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Edit Profile</a>

                                <a href="<?= \Yii::$app->getUrlManager()->createUrl(['user/change-password']) ?>" class="btn btn-primary"><i class="fa fa-key"></i> Change Password</a>

                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</section>