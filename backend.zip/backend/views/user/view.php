<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
?>

<section class="content-header">
    <h1>
        Restaurant
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active"><a href="<?php echo \Yii::$app->urlManager->createUrl("user/restaurant") ?>" >Restaurant</a></li>
        <li class="active">View Restaurant</li>

    </ol>
</section>
<section class="content">

    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">View Restaurant</h3>
                    <a href="<?= yii\helpers\Url::to(['user/restaurant']) ?>" class="btn btn-default pull-right"><span class="glyphicon glyphicon-hand-left black"></span> Back</a>
                </div>

                <?php
                echo
                DetailView::widget([
                    'model' => $model,
                    'attributes' => [
                        [
                            'attribute' => 'area_id',
                            'format' => 'html',
                            'value' => ($model->getAreaName($model->area_id))
                        ],
                        [
                            'attribute' => 'username',
                            'label' => 'Username',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'email',
                            'label' => 'Email Address',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'restaurant_name',
                            'label' => 'Restaurant Name',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'company_registration_details',
                            'label' => 'Company Registration Number',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'primary_contact_number',
                            'label' => 'Primary contact number',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'secondary_contact_number',
                            'label' => 'Secondary contact number',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'address',
                            'label' => 'Address',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'city',
                            'label' => 'City',
                            'format' => 'raw',
                        ],
                        [
                            'attribute' => 'postal_code',
                            'label' => 'Postal Code',
                            'format' => 'raw',
                        ],
                    ],
                ]);
                ?>

            </div></div></div></section>