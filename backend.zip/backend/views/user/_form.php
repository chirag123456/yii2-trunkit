<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;

$this->title = 'Admin';
?>

<!-- /.box-header -->
<!-- form start -->
<div class="box-body"> 

    <div class="user-form">

        <?php
        $form = ActiveForm::begin([
                'id' => 'user-form',
                'enableAjaxValidation' => true,
                'enableClientValidation' => true,
                'options' => ['enctype' => 'multipart/form-data']
        ]);
        ?>

        <div class="row">
            <div class="col-md-12">
                <div class="col-md-4">
                    <?= $form->field($model, 'first_name')->textInput(['autofocus' => true, 'maxlength' => 50, 'placeholder' => 'Enter First Name']) ?>
                </div>
                <div class="col-md-4">
                    <?= $form->field($model, 'last_name')->textInput(['maxlength' => 50, 'placeholder' => 'Enter Last Name']) ?>
                </div> 
                <div class="col-md-4">
                    <?= $form->field($model, 'email')->textInput(['maxlength' => 100, 'id' => 'email', 'placeholder' => 'Enter Email Address']) ?>
                </div>
            </div>

            <?php if (isset($_GET['id']) && !empty($_GET['id'])) { ?>
            <?php } else { ?>
                <div class="col-md-12">
                    <div class=" col-md-6">
                        <?= $form->field($model, 'password')->passwordInput(['autofocus' => true, 'placeholder' => 'Enter Password']) ?>
                    </div>
                    <div class=" col-md-6">
                        <?= $form->field($model, 'confirm_password')->passwordInput(['placeholder' => 'Enter Confirm Password']) ?>
                    </div>
                </div> 
            <?php } ?>

            <div class="col-md-12">
                <div class="col-md-4">
                    <?= $form->field($model, 'contact_number')->textInput(['maxlength' => 12, 'minlength' => 10, 'minlength' => 10, 'id' => 'user_contact', 'placeholder' => 'Ex: +148785xxxx']) ?>
                </div>
                <div class="col-md-4">
                    <?= $form->field($model, 'date_of_birth')->textInput(['placeholder' => 'Select Date Of Birth', 'id' => 'datepicker']) ?>
                </div>

                <div class=" col-md-4">
                    <?= $form->field($model, 'age')->textInput(['maxlength' => 3, 'placeholder' => 'Enter Age', 'readOnly' => true]) ?>
                </div> 
            </div>

            <div class="col-md-12">
                <div class="col-md-4">
                                <?php echo $form->field($model, 'gender')->dropDownList(['Male' => 'Male', 'Female' => 'Female'], ['prompt' => 'Select Gender']); ?>
                            </div>
                <div class="col-md-4">
                    <?= $form->field($model, 'description')->textarea(['maxlength' => 100, 'id' => 'user_email', 'placeholder' => 'Enter Description']) ?>
                </div>
                <?php 
                    if(isset($model->driver_licence) && !empty($model->driver_licence) || isset($model->driver_licence2) && !empty($model->driver_licence2))
                    { 
                ?>
                    <div class="col-md-4">
                        <?= $form->field($model, 'is_driver_licence_approved')->checkbox(array('label'=>false))->label('Approve Driver Licence'); ?>
                    </div>
                <?php        
                    }
                    if(isset($model->insurance_number) && !empty($model->insurance_number))
                    {
                ?>
                    <div class="col-md-4">
                        <?= $form->field($model, 'is_insurance_number_approved')->checkbox(array('label'=>false))
                         ->label('Approve Insurance Number'); ?>
                    </div>
                <?php        
                    }
                ?>
                
                
            </div>


            <div class="col-md-12 image-sections">                
                <div class="col-md-3">
                    
                    <div class=" col-md-12"> 
                         <label class="lbl-usr-img">Select User Image</label>
                              <div class="cropme" id="user_image" style="     margin-top: 30px; width: 200px; height: 200px;" data-image="true"></div>
                                    <input type="hidden" name="UserForm[user_image]" id="set_user_img">
                                    <input type="hidden" name="imageRemove" id="imgRemove" value="0">

                                    <button class="img-usr-btn" type="button" id="remove" class="btn btn-default"> 
                                        <span class="fa fa-remove"></span>
                                    </button>
                            </div>
                          </div>
                          <div  style="display:none; color: red;margin-top: 5px; margin-left: 575px; margin-bottom: 10px;" 
                          class="image-error">Image cannot be blank.</div>
                </div>
                <?php 
                    if(isset($model->driver_licence) && !empty($model->driver_licence))
                    {
                ?>
                    <div class="col-md-3">
                        <div class="col-md-12">
                            <div class="image-label2"><label>Driver Licence Image 1</label></div>
                        </div>
                        <div class=" col-md-12"> 
                            <?php $path = Yii::$app->request->hostInfo . USER_LICENCE_PATH .$model->driver_licence; ?>
                            <a href="<?php echo $path; ?>" target="_blank">
                                    <div class="" id="image" style="width: 200px; height: 200px; background-image: url('<?php echo $path; ?>');" data-image="true"></div>
                            </a>
                        </div>                    
                    </div>
                <?php        
                    }
                ?>
                
                 <?php 
                    if(isset($model->driver_licence2) && !empty($model->driver_licence2))
                    {
                ?>
                    <div class="col-md-3">
                        <div class="col-md-12">
                            <div class="image-label2"><label>Driver Licence Image 2</label></div>
                        </div>
                        <div class=" col-md-12"> 
                            <?php $path = Yii::$app->request->hostInfo . USER_LICENCE_PATH .$model->driver_licence2; ?>
                            <a href="<?php echo $path; ?>" target="_blank">
                                    <div class="" id="image" style="width: 200px; height: 200px; background-image: url('<?php echo $path; ?>');" data-image="true"></div>
                            </a>
                        </div>                    
                    </div>
                <?php        
                    }
                ?>

                 <?php 
                    if(isset($model->insurance_number) && !empty($model->insurance_number))
                    {
                ?>
                    <div class="col-md-3">
                        <div class="col-md-12">
                            <div class="image-label2"><label>Insurance Number Image </label></div>
                        </div>
                        <div class=" col-md-12"> 
                            <?php $path = Yii::$app->request->hostInfo . USER_CAR_INS_PATH .$model->insurance_number; ?>
                            <a href="<?php echo $path; ?>" target="_blank">
                                    <div class="" id="image" style="width: 200px; height: 200px; background-image: url('<?php echo $path; ?>');" data-image="true"></div>
                            </a>
                        </div>                    
                    </div>
                <?php        
                    }
                ?>             
            </div>
        </div>
        <div class=" col-md-12">
            <div class="col-md-6 col-md-offset-6">
                <?php
                if (isset($_GET['id']) && !empty($_GET['id'])) {
                    echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                } else {
                    echo Html::submitButton('Add', ['class' => 'btn btn-primary pull-right', 'id' => 'img']);
                }
                ?>
                <?php echo Html::a('Cancel', ['user/index'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
            </div>
        </div>

    </div>
    <?php ActiveForm::end(); ?>

</div>                        

<?php
$this->registerJs("
    $('#datepicker').on('changeDate', function(e) {
        var currentDate = new Date();
        var selectedDate = new Date(e.date.toString());
        var age = currentDate.getFullYear() - selectedDate.getFullYear();
        var m = currentDate.getMonth() - selectedDate.getMonth();

        if (m < 0 || (m === 0 && currentDate.getDate() < selectedDate.getDate())) {
            age--;
        }
        $('#userform-age').val(age);
    });
    $('#img').click(function() {
       var user_img_src =  $('#user_image').children().attr('src');
       $('#set_user_img').val(user_img_src);
    });
");

$this->registerJs("
    $(document).ready(function() {
        var today = new Date();
        var dt = new Date();
        dt.setFullYear(new Date().getFullYear()-18);
        $('#datepicker').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            endDate: dt,
            maxDate: today
        });
});
");


/*if (isset($model->driver_licence) && !empty($model->driver_licence)) {
    $mediaFileUrl = Yii::$app->request->hostInfo .USER_LICENCE_PATH. $model->driver_licence;

    $this->registerJs("
        $(document).ready(function() {
            var client_image_url = 'url($mediaFileUrl)';
            $('#client_image').css('background-image', client_image_url);
        });
    ");
}*/
$default_img = Yii::$app->urlManager->createAbsoluteUrl("/web/uploads/UploadLight.png");

if (isset($model->image) && !empty($model->image)) {

    $mediaFileUrl2 = Yii::$app->request->hostInfo . USER_PROFILE_PATH . $model->image;

    $this->registerJs("
        $(document).ready(function() {
            var user_image_url = 'url($mediaFileUrl2)';
            $('#user_image').css('background-image', user_image_url);
        });
    ");
}

$default_img = Yii::$app->request->hostInfo . USER_PROFILE_PATH . "UploadLight.png";
$this->registerJs("

 $('.cropme').simpleCropper();  
 
 $('#img').click(function() {
     var client_img_src =  $('#client_image').children().attr('src');
     var client_img_src2 =  $('#image').children().attr('src');
     
     $('#set_client_img').val(client_img_src);
     $('#set_img').val(client_img_src2);
 });
");

if (!isset($_GET['id']) && empty($_GET['id'])) {

    $this->registerJs("
        $('.ok').click(function() {      
            $('#user_image').css('border', '1px solid green');
            $('.image-label').css('color', '#00a65a');
             $('#user_image').css('background-image', 'none');
            $('.image-error').hide();
        });
        $('#user-form').on('submit', function() {        
            if( $('#user_image img').length == 0  || $('#imgRemove').val() == 1  ) {
                 $('#user_image').css('border', '1px solid red');
                 $('.image-label').css('color', '#dd4b39');
                 $('.image-error').show();
                  return false;
            } else {
                $('#user_image').css('border', '1px solid green');
                $('.image-label').css('color', '#00a65a');
                $('.image-error').hide();
            }
        });
        $('#remove').click(function() {
            $('#user_image img').remove();
            $('#user_image').css('background-image', 'url($default_img)');
        });
    ");
} else {
    $this->registerJs("
        $('#remove').click(function() {
            $('#user_image img').remove();
            $('#user_image').css('background-image', 'url($default_img)');
            $('#imgRemove').val(1);
            $('#user_image').attr('data-image', 'false');
        });
        $('.ok').click(function() {
            $('#user_image').css('border', '1px solid green');
            $('.image-label').css('color', '#00a65a');
            $('#user_image').css('background-image', 'none'); 
            $('.image-error').hide();
        });
        $('#user-form').on('submit', function() {
            if($('#user_image img').length == 0) {
                if( $('#user_image').data('image') == 'true'  || $('#imgRemove').val() == 0  ) {
                    var a = 2;
                } else {
                    $('#user_image').css('border', '1px solid red');
                    $('.image-label').css('color', '#dd4b39');
                    $('.image-error').show();
                    var a = 1;     
                } 
            } else {
                var a = 3;
            }
            if(a == 2 || a == 3) {
                return true;
            } else {
                return false;
            }

        });
         
    ");
}

if (isset($model->id) && !empty($model->id)) {

    $this->registerJs("
        $(document).ready(function() {
            $( '#email' ).prop( 'disabled', true );
            $( '#user_contact' ).prop( 'disabled', true );
        });
    ");
}
?>