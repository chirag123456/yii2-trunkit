<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use common\models\State;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model common\models\User */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin | Profile';
?>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- general form elements -->

            <!-- /.box-header -->
            <!-- form start -->

            <div class="user-form">

                <?php
                $form = ActiveForm::begin([
                            'id' => 'user-form',
                            'enableAjaxValidation' => true,
                            'enableClientValidation' => true,
                            'options' => ['enctype' => 'multipart/form-data']
                ]);
                ?>

                <div class="row">

                    <div class="col-md-12">
                        <div class=" col-md-6">
                            <?= $form->field($model, 'first_name')->textInput(['placeholder' => 'Enter Firstname']) ?>
                        </div>
                        <div class=" col-md-6">
                            <?= $form->field($model, 'email')->textInput(['readonly' => true, 'placeholder' => 'Enter Email']) ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class=" col-md-6">
                            <?= $form->field($model, 'last_name')->textInput(['maxlength' => 100, 'placeholder' => 'Enter Last Name']) ?>
                        </div>
                        <!-- <div class=" col-md-6">
                        <?= $form->field($model, 'contact_number')->textInput(['maxlength' => 20, 'minlength' => 10, 'placeholder' => 'Enter Contact Number']) ?>
                        </div> -->
                    </div>

                    <div class=" col-md-12"> 
                        <?php
                        if (isset($_GET['id']) && !empty($_GET['id'])) {
                            echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right']);
                        } else {
                            echo Html::submitButton('Create', ['class' => 'btn btn-primary pull-right']);
                        }
                        ?>
                        <?php echo Html::a('Cancel', ['user/admin-profile'], ['class' => 'btn btn-primary pull-right cancel-button remove', 'style' => 'margin-right: 5px;']); ?>
                    </div>
                </div>
                <?php ActiveForm::end(); ?>

            </div>                        

        </div>
    </div>

</section>