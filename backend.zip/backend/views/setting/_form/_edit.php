<?php
use yii\widgets\ActiveForm;
use yii\bootstrap\Html;
?>
<div class="box-header with-border">
    <h3 class="box-title">Update Site Configuration</h3>
</div>
<?php
$form = ActiveForm::begin([
            'id' => 'site-configuration-form',
            'enableAjaxValidation' => true,
            'enableClientValidation' => true,
            'action' => \yii\helpers\Url::to(['setting/update/' . $_GET['id']]),
        ]);
?>
<div class="row" style="margin-top: 10px;">
    <div class="col-md-12">
        <div class="col-md-4">
            <?php echo $form->field($model, 'config_key')->textInput(['disabled' => 'true', 'maxlength' => true, 'placeholder' => 'Enter Config key']) ?>
        </div>
        <div class="col-md-4">
            <?php echo $form->field($model, 'config_value')->textInput(['maxlength' => true, 'placeholder' => 'Enter Config Value']) ?>
        </div>
        <div class="col-md-4">
            <?php
            echo Html::submitButton('Update', ['class' => 'btn btn-primary pull-right create-button','style' => 'margin-left: 5px;     margin-top: 5px;

']);
            echo Html::a('Cancel', ['index'], ['class' => 'btn btn-primary pull-right cancel-button remove','style' =>   'margin-top: 5px;']);
            ?>                              
        </div>
        
    </div>
    <?php ActiveForm::end(); ?>
</div>