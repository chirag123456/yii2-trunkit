<?php
/* @var $this yii\web\View */

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $searchModel common\models\search\UserSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$this->title = 'Admin | Site Configuration';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1> Site Configuration </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Site Configuration</li>
    </ol>
</section>
<section class="content">
    <!-- Small boxes (Stat box) -->

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <?php if (isset($_GET['id']) && !empty($_GET['id'])) { ?>
                    <div class="box-body edit-site-configuration">
                        <?php echo $this->render('_form/_edit', ['model' => $model]); ?>
                    </div>
                <?php }else{ ?>
                    <div class="box-body add-site-configuration" style="display: none;">
                        <?php echo $this->render('_form/_add', ['model' => $model]); ?>
                    </div>   
                <?php } ?>
                <!-- /.box-header -->
                <div class="box-body">
                    
                        <div class="user-index">
                            <?php
                            $form = ActiveForm::begin([
                                        'method' => 'get',
                                        'action' => Url::base().'/setting/index',
                                        'id' => 'super'
                            ]);
                            ?>
                            <input type="hidden" value="5" id="per_page" name="per-page">

                            <?php
                            ActiveForm::end();

                            ?>
                            <?php
                            $pagesize = \backend\components\CommonFunctions::getConfigureValueByKey('DEFAULT_PAGESIZE');
                            ?>
                            <?php // echo $this->render('_search', ['model' => $searchModel]);      ?>
                            <div id="sample_1_length" class="pull-right ">
                                <label>
                                    <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                        <?php
                                        $sel10 = '';
                                        $sel20 = '';
                                        $sel50 = '';
                                        $sel100 = '';
                                         if ($pagesize == '10') {
                                            $sel10 = 'selected="selected"';
                                        } else if ($pagesize == '20') {
                                            $sel20 = 'selected="selected"';
                                        } else if ($pagesize == '50') {
                                            $sel50 = 'selected="selected"';
                                        } else if ($pagesize == '100') {
                                            $sel100 = 'selected="selected"';
                                        }
                                        ?>
                                        <option value="10" <?php echo $sel10; ?>>10</option>
                                        <option value="20" <?php echo $sel20; ?>>20</option>
                                        <option value="50" <?php echo $sel50; ?>>50</option>
                                        <option value="100" <?php echo $sel100; ?>>100</option>
                                    </select>
                                    records per page</label>
                            </div>

                            <p>
                                <?php echo Html::button('Add Site Configuration', ['class' => 'btn btn-primary add-button']); ?>
                                <?php echo Html::a('Reset', ['setting/index'], ['class' => 'btn btn-primary filter-reset']) ?>
                            </p>
                            <?php
                            echo GridView::widget([
                                'dataProvider' => $dataProvider,
                                'filterModel' => $searchModel,
                                'showOnEmpty' => true,
                                'columns' => [
                                    [   'attribute' => 'id',
                                        'label' => '#ID',
                                        'contentOptions' => ['style' => 'width:40px;'],
                                     ],
                                    
                                    [
                                        'attribute' => 'config_key',
                                        'headerOptions' => ['title' => 'sort by'],
                                        'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search by Config Key'
                                        ],
                                    ],
                                    [
                                        'attribute' => 'config_value',
                                        'headerOptions' => ['title' => 'sort by'],
                                        'filterInputOptions' => [
                                            'class'=>'form-control',
                                            'placeholder' => 'Search by Config Value'
                                        ],
                                    ],
                                    
                                   
                                    [
                                        'class' => 'yii\grid\ActionColumn',
                                        'header' => 'Actions',
                                        'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                        'template' => '{update}',
                                        'buttons' => [
                                            'update' => function ($url, $model) {
                                                return Html::a('<span class="glyphicon glyphicon-pencil" style="color:#3c8dbc;"></span>', $url, [
                                                            'class' => '',
                                                            'data-toggle' => 'tooltip',
                                                            'title' => 'Edit',
                                                ]);
                                            }
                                        ],
                                        'urlCreator' => function ($action, $model, $key, $index) {

                                            if ($action === 'update') {
                                                return \yii\helpers\Url::toRoute(['setting/index/' . $key]);
                                            }
                                        }
                                    ],
                                ],
                            ]);
                            ?>
                          
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['id']) && !empty($_GET['id'])) {

    $this->registerJs("
       $('.add-button').hide();
");
}
?>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
        var page_size = '" . $_GET['per-page'] . "';
        $('#pagination').val(page_size);
        $('#pagination option:selected',page_size).text();
    ");
}
?>
<?php
$this->registerJs("
    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
<?php
$this->registerJs("
$('.add-button').on('click', function (e) {
        $('.add-site-configuration').show();
        $(this).hide();
    });
    $('.remove').on('click', function (e) {
        $('.add-site-configuration').hide();
        $('.add-button').show();
    });
");
?>