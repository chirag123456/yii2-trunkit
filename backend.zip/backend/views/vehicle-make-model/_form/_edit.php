<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use common\models\vehiclemakemodel\VehicleMakeModel;

/* @var $this yii\web\View */
/* @var $model common\models\Country */
/* @var $form yii\widgets\ActiveForm */
$this->title = 'Admin';
?>
<div class="box-header with-border">
    <h3 class="box-title">Update Vehicle Make/Model</h3>
</div>
<?php
$form = ActiveForm::begin([
            'id' => 'vehicle-make-model-form',
            'enableAjaxValidation' => true,
            'enableClientValidation' => true,
            'action' => \yii\helpers\Url::to(['vehicle-make-model/update/' . $_GET['id']])
        ]);
?>
<div class="row">
    <div class="col-md-12">
        <div class="col-md-4">
            <?php echo $form->field($model, 'make_model_name')->textInput(['maxlength' => 100, 'placeholder' => 'Enter Vehicle Make/Model Name']) ?>
        </div>

        <?php
        $id = $_GET['id'];
        $makeModelList = ArrayHelper::map(VehicleMakeModel::find()->where(['is_active' => ACTIVE])->andWhere(['is_delete' => NOT_DELETED])->andWhere(['<>', 'id', $id])->asArray()->all(), 'id', 'make_model_name');
        ?>
        <div class="col-md-4">
            <?php
            echo $form->field($model, 'parent_id')->widget(
                    Select2::classname(), [
                'data' => $makeModelList,
                'options' => ['placeholder' => 'Select Parent Category'],
            ])->label();
            ?>
        </div>
        <div class="col-md-4">
			<div class="form-group" style="margin-top: 15px;">
				<?php
				echo Html::submitButton('Update ', ['class' => 'btn btn-primary pull-right  create-button','style'=>'margin-left: 5px;']);
				echo Html::a(' Cancel', ['index'], ['class' => 'btn btn-default pull-right  cancel-button']);
				?>                                
			</div>
        </div>
    </div>
</div>
<?php ActiveForm::end(); ?>

