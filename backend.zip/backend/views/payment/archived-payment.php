<?php

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;

$this->title = 'Admin';
?>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>

<section class="content-header">
    <h1>
     Archived Payment
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Archived Payment</li>
    </ol>
</section>
<section class="content">

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <div class="box-body">
                    <div class="user-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                        $settings = \common\models\Settings::find()->one();
                      
                        $pagesize = $settings['config_value'];
                        ?>


                        <?php // echo $this->render('_search', ['model' => $searchModel]);      ?>
                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>

                        <p>
                            <?php echo Html::a('Reset', ['payment/archived-payment'], ['class' => 'btn btn-primary filter-reset']) ?>
                            <?php echo Html::a('Export CSV', ['export'], ['class' => 'btn btn-primary btn-export-click', 'id' => 'export_file']) ?>
                        </p>
                        <?php Pjax::begin(['id' => 'users']) ?>  
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'id' => 'gridcheck',
                            'filterModel' => $searchModel,
                            'columns' => [
                                [
                                    'class' => 'yii\grid\CheckboxColumn',
                                    // you may configure additional properties here
                                ],
                                [
                                    'attribute' => 'id',
                                    'label' => 'ID',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by ID'
                                    ],
                                ],
                                /*[
                                    'attribute' => 'from_user_id',
                                    'label' => 'From User Id',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->user->first_name) ? $model->user->first_name : 'N\A';
                                    },
                                    'filter' => false,
                                ],*/
                                /*[
                                    'attribute' => 'to_user_id',
                                    'label' => 'To User Id',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        //print_r($model); //die;
                                        return isset($model->touser->first_name) ? $model->touser->first_name : 'N\A';
                                    },
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Origin'
                                    ],
                                ],*/
                                /*[
                                    'attribute' => 'destination',
                                    'label' => 'Destination',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->post->destination) ? $model->post->destination : 'N\A';
                                    },
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Destination'
                                    ],
                                ],*/
                                [
                                    'attribute' => 'admin_user_amt',
                                    'label' => 'Admin Amt.',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->admin_user_amt) ? $model->admin_user_amt : 'N\A';
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        //'placeholder' => 'Search by ID'
                                    ],
                                ],
                                [
                                    'attribute' => 'to_user_amt',
                                    'label' => 'Receiver Amt.',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by ID'
                                    ],
                                ],
                                [
                                    'attribute' => 'transaction_datetime',
                                    'label' => 'Transaction Date',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        //return isset($model->order_date) ? date('M j, Y g:ia', strtotime($model->order_date)) : 'N/A';
                                        //return isset($model->transaction_datetime) ? date('M j, Y g:ia', strtotime($model->transaction_datetime)) : 'N/A';
                                        return isset($model->transaction_datetime)?date('Y-m-d', strtotime($model->transaction_datetime)):'N\A';
                                    },
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Order Date'
                                    ],
                                ],
                                /*[
                                    'attribute' => 'total_price',
                                    'format' => 'raw',
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Price'
                                    ],
                                ],*/
                                [
                                    'attribute' => 'transaction_id',
                                    'label' => 'Transaction Id',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->transaction_id) ? $model->transaction_id : 'N\A';
                                    },
                                    'filter' => false,

                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select Order Status'
                                    ],
                                    /*'filter' => ['INITILISED' => 'INITILISED', 'ACCEPT' => 'ACCEPT', 'IN_TRIP' => 'IN_TRIP',
                                        'DELIVERED' => 'DELIVERED', 'PAID' => 'PAID', 'RATED' => 'RATED', 'FINISHED' => 'FINISHED'],*/
                                ],
                                [
                                    'attribute' => 'exported_date',
                                    'label' => 'CSV Exported Date',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        //return isset($model->order_date) ? date('M j, Y g:ia', strtotime($model->order_date)) : 'N/A';
                                        return isset($model->exported_date) ? date('Y-m-d', strtotime($model->exported_date)) : 'N/A';
                                    },
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Exported Date'
                                    ],
                                ],
                                [
                                    'attribute' => 'is_exported',
                                    'label' => 'CSV Exported',
                                    'format' => 'raw',
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control'
                                        //'prompt' => 'Select is_exported'
                                    ],
                                    //'filter' => ['FAIL' => 'FAIL', 'PENDING' => 'PENDING', 'COMPLETED' => 'COMPLETED'],
                                ],
                                [
                                    'attribute' => 'payment_status',
                                    'label' => 'Payment Status',
                                    'format' => 'raw',
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select Payment Status'
                                    ],
                                    //'filter' => ['FAIL' => 'FAIL', 'PENDING' => 'PENDING', 'COMPLETED' => 'COMPLETED'],
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{view}', //{delete}
                                    'buttons' => [
                                        
                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', ['payment/view/' . $model->id.'?is_archived=1'], [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'View',
                                            ]);
                                        }
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'view') {
                                            return \yii\helpers\Url::toRoute(['payment/view/' . $key]);
                                        } 
                                    }
                                ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("

    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
<?php
$this->registerJs("
   $(document).on('ready pjax:success', function () {
    $('.ajaxStatus').on('click', function (e) {
        e.preventDefault();
        var Url     = $(this).attr('status-url');
        var pjaxContainer = $(this).attr('pjax-container');
            $.ajax({
                    url:   Url,
                    type:  'post',
                }).done(function (data) {
                  $.pjax.reload({container: '#' + $.trim(pjaxContainer)});
                });

    });
});

    $('#export_file').click(function(){
        var keys = $('#gridcheck').yiiGridView('getSelectedRows');
        if(keys==''){
            alert('Please select Transaction');
            return false;
        }else{
            var href = $('#export_file').attr('href');
            newhref = href+'?id='+keys+'&is_archived=1';
            $('#export_file').attr('href', newhref);    
        }
    });

");
?>