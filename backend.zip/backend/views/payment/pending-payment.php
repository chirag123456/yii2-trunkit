<?php

use yii\widgets\Pjax;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use kartik\daterange\DateRangePicker;
use kartik\date\DatePicker;

//print_r($post['PostOrderSearch']['transaction_datetime']); exit();
$this->title = 'Admin';

?>
<style type="text/css">
    #gridcheck-filters{
        display: none;
    }
</style>
<?php echo \Yii::$app->view->renderFile('@backend/views/layouts/message_panel.php'); ?>
<section class="content-header">
    <h1>
     Pending Payment
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Pending Payment</li>
    </ol>
</section>
<section class="content">

    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary">

                <div class="box-body">
                    <div class="user-index">
                        <?php
                        $form = \yii\widgets\ActiveForm::begin([
                                    'method' => 'get', 'id' => 'super'
                        ]);
                        ?>
                        <input type="hidden" value="5" id="per_page" name="per-page">

                        <?php ActiveForm::end();
                        ?>
                        <?php
                        $settings = \common\models\Settings::find()->one();
                      
                        $pagesize = $settings['config_value'];
                        ?>


                        <?php // echo $this->render('_search', ['model' => $searchModel]);      ?>
                        <div id="sample_1_length" class="pull-right ">
                            <label>
                                <select size="1" name="sample_1_length" id="pagination" aria-controls="sample_1" class="form-control">
                                    <?php
                                    $sel10 = '';
                                    $sel20 = '';
                                    $sel50 = '';
                                    $sel100 = '';
                                    if ($pagesize == '10') {
                                        $sel10 = 'selected="selected"';
                                    } else if ($pagesize == '20') {
                                        $sel20 = 'selected="selected"';
                                    } else if ($pagesize == '50') {
                                        $sel50 = 'selected="selected"';
                                    } else if ($pagesize == '100') {
                                        $sel100 = 'selected="selected"';
                                    }
                                    ?>
                                    <option value="10" <?php echo $sel10; ?>>10</option>
                                    <option value="20" <?php echo $sel20; ?>>20</option>
                                    <option value="50" <?php echo $sel50; ?>>50</option>
                                    <option value="100" <?php echo $sel100; ?>>100</option>
                                </select>
                                records per page</label>
                        </div>
                        <?php echo Html::a('Reset', ['payment/pending-payment'], ['class' => 'btn btn-primary filter-reset']) ?>
                        <?php
                            $form = \yii\widgets\ActiveForm::begin([
                                        'method' => 'post', 'id' => 'frmpay'
                            ]);
                            //echo 'rrr<pre>';print_r($_POST); die;
                        ?>
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <?php $list = ['1'=>'Time Period','2'=>'Monthly','3'=>'Yearly'];
                                $sel_transdate = '';
                                if(isset($_POST['PostOrderSearch']['transaction_datetime']) && $_POST['PostOrderSearch']['transaction_datetime']!='')
                                {
                                    $sel_transdate = $_POST['PostOrderSearch']['transaction_datetime'];
                                }?>
                                <label class="control-label" for="transaction_datetime">Time Period</label>
                                   <?php echo $form->field($searchModel, 'transaction_datetime')->widget(
                                            Select2::classname(), [
                                        'data' => $list,
                                        'options' => ['placeholder' => 'Select Time Period','autofocus'=>true, 'value' => $sel_transdate, 'id' => 'transaction_datetime'],
                                    ])->label(false);
                                ?>
                            </div>
                             <?php 
                              $sel_date ='';
                              if(isset($_POST['PostOrderSearch']['transaction_datetime']) && !empty($_POST['PostOrderSearch']['transaction_datetime']) && $_POST['PostOrderSearch']['transaction_datetime'] == 1)
                              {
                                if(isset($_POST['PostOrderSearch']['sale_by_date']) && $_POST['PostOrderSearch']['sale_by_date']!=''){
                                        $sel_date = $_POST['PostOrderSearch']['sale_by_date'];
                                    }
                              }
                              else
                              {
                                unset($_POST['PostOrderSearch']['sale_by_date']);
                              }
                                    
//echo $sel_date.'dd';
                                ?>
                            <div class="col-md-3" id="div_sale_by_date" style="<?php if(isset($sel_date) && $sel_date != '') {echo "display: block;";} else{ echo "display: none;"; }  ?>">
                               
                                <label class="control-label" for="transaction_datetime">Select Time Period Date</label>
                                <?php  
                                    echo DateRangePicker::widget([
                                        'model'=>$searchModel,
                                        'attribute'=>'sale_by_date',
                                        'convertFormat'=>true,
                                        'options' => [
                                            'value' => isset($_POST['PostOrderSearch']['sale_by_date']) && !empty($_POST['PostOrderSearch']['sale_by_date']) ? $_POST['PostOrderSearch']['sale_by_date'] : '', 
                                            'class'=>'form-control','placeholder' => Yii::t('app', 'Select Time Period Date')],
                                        'pluginOptions'=>[
                                            'timePicker'=>true,
                                            'timePickerIncrement'=>30,
                                            'locale'=>[
                                                'format'=>'Y-m-d'
                                            ]
                                        ]
                                    ]);
                                ?>
                            </div>
                            <?php
                             $sel_month='';

                             if(isset($_POST['PostOrderSearch']['transaction_datetime']) && !empty($_POST['PostOrderSearch']['transaction_datetime']) && $_POST['PostOrderSearch']['transaction_datetime'] == 2)
                              {
                                if(isset($_POST['PostOrderSearch']['sale_by_month']) && $_POST['PostOrderSearch']['sale_by_month']!=''){
                                        $sel_month = $_POST['PostOrderSearch']['sale_by_month'];
                                    }
                              }
                              else
                              {
                                unset($_POST['PostOrderSearch']['sale_by_month']);
                              }
                                    
                                ?>
                            <div class=" col-md-3" id="div_sale_by_month" style="<?php if(isset($sel_month) && $sel_month != '') {echo "display: block;";} else{ echo "display: none;"; }  ?>">
                                
                                <?= $form->field($searchModel, 'sale_by_month')->widget(DatePicker::classname(), [
                                    'options' => [
                                        'value' => isset($_POST['PostOrderSearch']['sale_by_month']) && !empty($_POST['PostOrderSearch']['sale_by_month']) ? $_POST['PostOrderSearch']['sale_by_month'] : '',
                                        'placeholder' => Yii::t('app', 'Select Month')],
                                    //'attribute2'=>'to_date',
                                    //'type' => DatePicker::TYPE_RANGE,
                                    'pluginOptions' => [
                                        'autoclose' => true,
                                        'startView'=>'year',
                                        'minViewMode'=>'months',
                                        'format' => 'yyyy-mm',
                                        'required' => true
                                    ]
                                ]) ?>
                            </div>
                            <?php 
                                $sel_year=''; 
                                if(isset($_POST['PostOrderSearch']['transaction_datetime']) && !empty($_POST['PostOrderSearch']['transaction_datetime']) && $_POST['PostOrderSearch']['transaction_datetime'] == 3)
                               {
                                   if(isset($_POST['PostOrderSearch']['sale_by_year']) && $_POST['PostOrderSearch']['sale_by_year']!=''){
                                        $sel_year = $_POST['PostOrderSearch']['sale_by_year'];
                                    }
                               }
                              else
                              {
                                unset($_POST['PostOrderSearch']['sale_by_year']);
                              }
                                   
                            ?>
                            <div class=" col-md-3" id="div_sale_by_year" style="<?php if(isset($sel_year) && $sel_year != '') {echo "display: block;";} else{ echo "display: none;"; }  ?>">
                                
                                <?= $form->field($searchModel, 'sale_by_year')->widget(DatePicker::classname(), [
                                    'options' => [
                                        'value' => isset($_POST['PostOrderSearch']['sale_by_year']) && !empty($_POST['PostOrderSearch']['sale_by_year']) ? $_POST['PostOrderSearch']['sale_by_year'] : '',
                                        'placeholder' => Yii::t('app', 'Select Year')],
                                    //'attribute2'=>'to_date',
                                    //'type' => DatePicker::TYPE_RANGE,
                                    'pluginOptions' => [
                                        'autoclose' => true,
                                        'startView'=>'year',
                                        'minViewMode'=>'years',
                                        'format' => 'yyyy'
                                    ]
                                ]) ?>
                            </div>
                            <div class="col-md-2">
                                <?php echo Html::submitButton('Submit', ['class' => 'btn btn-primary pull-right custom-search-date', 'id' => 'search_date']); ?>
                            </div>
                            <div class="col-md-2">
                                <?php echo Html::a('Export CSV', ['export'], ['class' => 'btn btn-primary btn-export-click pull-right custom-search-date', 'id' => 'export_file']) ?>
                            </div>
                        </div>
                        <?php ActiveForm::end(); ?>
                        <?php /*<p>
                            <?php echo Html::a('Reset', ['payment/pending-payment'], ['class' => 'btn btn-primary filter-reset']) ?>
                            <?php echo Html::a('Export CSV', ['export'], ['class' => 'btn btn-primary btn-export-click', 'id' => 'export_file']) ?>
                        </p>*/ ?>
                        <?php Pjax::begin(['id' => 'users']) ?>  
                        <?=
                        GridView::widget([
                            'dataProvider' => $dataProvider,
                            'id' => 'gridcheck',
                            'filterModel' => $searchModel,
                            'columns' => [
                                [
                                    'class' => 'yii\grid\CheckboxColumn',
                                    // you may configure additional properties here
                                ],
                                [
                                    'attribute' => 'id',
                                    'label' => 'ID',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by ID'
                                    ],
                                ],
                                /*[
                                    'attribute' => 'from_user_id',
                                    'label' => 'From User Id',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->user->first_name) ? $model->user->first_name : 'N\A';
                                    },
                                    'filter' => false,
                                ],*/
                                /*[
                                    'attribute' => 'to_user_id',
                                    'label' => 'To User Id',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        //print_r($model); //die;
                                        return isset($model->touser->first_name) ? $model->touser->first_name : 'N\A';
                                    },
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Origin'
                                    ],
                                ],*/
                                /*[
                                    'attribute' => 'destination',
                                    'label' => 'Destination',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->post->destination) ? $model->post->destination : 'N\A';
                                    },
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Destination'
                                    ],
                                ],*/
                                [
                                    'attribute' => 'admin_user_amt',
                                    'label' => 'Admin Amt.',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->admin_user_amt) ? $model->admin_user_amt : 'N\A';
                                    },
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        //'placeholder' => 'Search by ID'
                                    ],
                                ],
                                [
                                    'attribute' => 'to_user_amt',
                                    'label' => 'Receiver Amt.',
                                    'format' => 'raw',
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by ID'
                                    ],
                                ],
                                [
                                    'attribute' => 'transaction_datetime',
                                    'label' => 'Transaction Date',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        //return isset($model->transaction_datetime) ? date('M j, Y g:ia', strtotime($model->transaction_datetime)) : 'N/A';
                                        return isset($model->transaction_datetime) ? date('Y-m-d', strtotime($model->transaction_datetime)) : 'N/A';
                                        
                                    },
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Order Date'
                                    ],
                                ],
                                /*[
                                    'attribute' => 'total_price',
                                    'format' => 'raw',
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'placeholder' => 'Search by Price'
                                    ],
                                ],*/
                                [
                                    'attribute' => 'transaction_id',
                                    'label' => 'Transaction Id',
                                    'format' => 'raw',
                                    'value' => function ($model) {
                                        return isset($model->transaction_id) ? $model->transaction_id : 'N\A';
                                    },
                                    'filter' => false,

                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select Order Status'
                                    ],
                                    /*'filter' => ['INITILISED' => 'INITILISED', 'ACCEPT' => 'ACCEPT', 'IN_TRIP' => 'IN_TRIP',
                                        'DELIVERED' => 'DELIVERED', 'PAID' => 'PAID', 'RATED' => 'RATED', 'FINISHED' => 'FINISHED'],*/
                                ],
                                [
                                    'attribute' => 'payment_status',
                                    'label' => 'Payment Status',
                                    'format' => 'raw',
                                    'filter' => false,
                                    'filterInputOptions' => [
                                        'class' => 'form-control',
                                        'prompt' => 'Select Payment Status'
                                    ],
                                    //'filter' => ['FAIL' => 'FAIL', 'PENDING' => 'PENDING', 'COMPLETED' => 'COMPLETED'],
                                ],
                                [
                                    'class' => 'yii\grid\ActionColumn',
                                    'header' => 'Actions',
                                    'headerOptions' => ['style' => 'color:#3C8DBC;width:100px;'],
                                    'template' => '{view}', //{delete}
                                    'buttons' => [
                                        
                                        'view' => function ($url, $model) {
                                            return Html::a('<span class="glyphicon glyphicon-eye-open" style="color:#3c8dbc;"></span>', ['payment/view/' . $model->id], [
                                                        'class' => '',
                                                        'data-toggle' => 'tooltip',
                                                        'title' => 'View',
                                            ]);
                                        }
                                    ],
                                    'urlCreator' => function ($action, $model, $key, $index) {

                                        if ($action === 'view') {
                                            return \yii\helpers\Url::toRoute(['payment/view/' . $key]);
                                        } 
                                    }
                                ],
                            ],
                        ]);
                        ?>
                        <?php Pjax::end() ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
if (isset($_GET['per-page'])) {
    $this->registerJs("
    var page_size = '" . $_GET['per-page'] . "';
    $('#pagination').val(page_size);
    $('#pagination option:selected',page_size).text();
");
}
?>
<?php
$this->registerJs("
    
    $('#pagination').change(function() {
      var pageSize = $(this).val();
       $('#per_page').val(pageSize);
       $('#super').submit();
    });

");
?>
<?php
$this->registerJs("
   $(document).on('ready pjax:success', function () {
    $('.ajaxStatus').on('click', function (e) {
        e.preventDefault();
        var Url     = $(this).attr('status-url');
        var pjaxContainer = $(this).attr('pjax-container');
            $.ajax({
                    url:   Url,
                    type:  'post',
                }).done(function (data) {
                  $.pjax.reload({container: '#' + $.trim(pjaxContainer)});
                });

    });
});

    $('#export_file').click(function(){
        var keys = $('#gridcheck').yiiGridView('getSelectedRows');
        if(keys==''){
            alert('Please select Transaction');
            return false;
        }else{
            var href = $('#export_file').attr('href');
            newhref = href+'?id='+keys;
            $('#export_file').attr('href', newhref);    
        }
    });

");

$this->registerJs("
    $( '#frmpay' ).submit(function( event ) {
        var transDate = $('#transaction_datetime').val();
        if(transDate==''){
            alert('Please select Time Period');
            return false;
            $('#frmpay').unbind('submit').submit();
            return false;

        }
        else if(transDate == 1)
        {
            var data = $('#postordersearch-sale_by_date').val();
            if(data == '')
            { 
                alert('Please select Time Period');
                return false;
            }
        }
        else if(transDate == 2)
        {
            var data = $('#postordersearch-sale_by_month').val();
            if(data == '')
            {
                alert('Please select Month');
                return false;
                //$('#frmpay').unbind('submit').submit();
            }
        }
        else if(transDate == 3)
        {
            var data = $('#postordersearch-sale_by_year').val();
            if(data == '')
            {
                alert('Please select Year');
                return false;
                //$('#frmpay').unbind('submit').submit();
            }
        }
    });
");

$this->registerJs("
    //var sel_mon = '".$sel_month."';
    //var sel_yr = '".$sel_year."';    
      
    $('#transaction_datetime').change(function() {
      var saletype = $(this).val();
        if(saletype==1){
          $('#div_sale_by_date').show();
        } else {
            $('#div_sale_by_date').hide();
        }
        if(saletype==2){
           $('#div_sale_by_month').show(); 
        } else {
            $('#div_sale_by_month').hide();
        }
        if(saletype==3){
           $('#div_sale_by_year').show(); 
        } else {
            $('#div_sale_by_year').hide();
        }
    });
    
");

?>