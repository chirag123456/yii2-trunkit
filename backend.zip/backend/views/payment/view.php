<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;
use yii\grid\GridView;
//echo $_REQUEST['pending-payment'];

?>

<div class="order-create">
    <section class="content-header">
        <h1> Payment Detail </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo \Yii::$app->urlManager->createUrl("dashboard/index") ?>"><i class="fa fa-home"></i> Home</a></li>
            <li><a href="<?php echo \Yii::$app->urlManager->createUrl("payment/index") ?>" >Payment</a></li>
            <li class="active">View</li>
        </ol>
    </section>
    <section class="content">

        <div class="row">
            <div class="col-md-12">

                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Transaction Detail</h3>
                        <?php 
                            if(isset($_GET['is_archived']) && !empty(isset($_GET['is_archived'])) && $_GET['is_archived'] == 1)
                            { ?>
                                    <a href="<?php echo yii\helpers\Url::to(['payment/archived-payment']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                        <?php  }
                            else
                            {   ?>
                                    <a href="<?php echo yii\helpers\Url::to(['payment/pending-payment']) ?>" class="btn btn-default pull-right"><span class="glyphimage glyphimage-hand-left black"></span> Back</a>
                            <?php }
                        ?>
                    </div>

                    <div class="box-body">
                        <div class="order-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <table id="w0" class="table table-striped table-bordered detail-view">
                                        <tbody>
                                            <tr>
                                                <th>Sender Name</th>
                                                <td><?php print_r($model['from_user_name']) ?></td>
                                            </tr>
                                            <tr>
                                                <th>Reciver Name</th>
                                                <td><?php print_r($model['to_user_name']) ?></td>
                                            </tr>
                                            <tr>
                                                <th>Reciver Paypal Email</th>
                                                <td><?php print_r($model['to_user_paypal_email_id']) ?></td>
                                            </tr>
                                            <tr>
                                                <th>Total Amount</th>
                                                <td><?php print_r($model['total_amount']) ?></td>
                                            </tr>
                                            <tr>
                                                <th>Reciver Amount</th>
                                                <td><?php print_r($model['to_user_amt']) ?></td>
                                            </tr>
                                            <tr>
                                                <th>Admin Commision</th>
                                                <td><?php print_r($model['admin_user_amt']) ?></td>
                                            </tr>
                                            
                                            <tr>
                                                <th>Transaction Id</th>
                                                <td><?php print_r($model['transaction_id']) ?></td>
                                            </tr>     
                                            <tr>
                                                <th>Transaction Date</th>
                                                <td><?php print_r($model['transaction_datetime']) ?></td>
                                            </tr>                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>   		
                    </div>        
                </div>
            </div>
        </div> 
    </section> 
</div>
<?php
$map_api_key = \backend\components\CommonFunctions::getConfigureValueByKey('MAP_API_KEY');
$this->registerJsFile(Yii::$app->homeUrl . 'resource/post/view-tripdetail.js', ['depends' => 'yii\web\JqueryAsset']);
$this->registerJsFile('https://maps.googleapis.com/maps/api/js?key='.$map_api_key.'&region=CA&libraries=places&callback=initMap', ['depends' => 'yii\web\JqueryAsset']);
?>