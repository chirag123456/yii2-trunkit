<?php
namespace backend\behaviors;

use yii;

use yii\filters\AccessControl;

use backend\models\user\AuthAssignments;
use backend\models\user\UserAccess;

use yii\base\Exception;
use yii\web\BadRequestHttpException;
use yii\web\UnauthorizedHttpException;

trait AccessBehavior{
	/**
   * @inheritdoc
   */
  public function behaviors()
  {
		return [
				'access' => [
				'class' => AccessControl::className(),
					'rules' => [ [ 'allow' => true , 'roles' => $this->accessByRoles() ] ],
						'denyCallback' => function(){
							
							if(Yii::$app->user->isGuest){
								return $this->redirect(['site/login']);
							}else{
                                                            echo '<p class="err"><center>You have no permission to access this page. Please contact Administrator</center></p>';
                                                            echo '<button onclick="history.back();">Go back</button>';
                                                            exit();
								//return $this->redirect(['site/error?code=503']);
								//throw new UnauthorizedHttpException( '503 - Unathorized Access !' , 503 );
								//$this->unauthorizedAccessRedirect();
							}
							
						}
					],
			];
  }
  
	/**
	 * unauthorizedAccessRedirect
	 
	public function unauthorizedAccessRedirect() {
		Yii::$app->getSession()->setFlash('success', [
			'type' => 'danger',
			'duration' => 12000,
			'icon' => 'glyphicon glyphicon-remove-sign',
			'message' => '503 - Unathorized Access !',
			'title' => 'Error: Unathorized Access',
			'positonY' => 'top',
			'positonX' => 'right'
		]);
		return $this->redirect(['/dashboard']);
	}*/
  
  public function accessByRoles()
  {
  	$access_auth = \Yii::$app->authManager->getRolesByUser( \Yii::$app->user->id );
  	
  	if( \Yii::$app->controller->id == 'dashboard' ){
  		foreach ( ( array ) $access_auth as $role ){
  			return [ $role->name ];
  		}
  	}
  	
  	if( $access_auth != null ){
  		$module = Yii::$app->controller->id;
		$act = Yii::$app->controller->action->id;
  		foreach ( ( array ) $access_auth as $role ){
			
	  		$user_access = UserAccess::findOne([ 'name' => $role->name ]);
			
	  		if( $user_access != null ){
				
				$accessArr = json_decode( $user_access->access , 16 );
				
				if( is_array( $accessArr ) ){
					foreach( $accessArr as $val ){
						if( $module == $val['module'] ){
							if( in_array( $act , $val['act'] ) || $act == 'status'){
								return [ $role->name ];
							}
						}
					}
				}
				
	  		}
  		}
  	}
  	return [ 'superadmin' ];
  }
  
  /*
  public function accessByRoles()
  {
  	$access_auth = \Yii::$app->authManager->getRolesByUser( \Yii::$app->user->id );
  	
  	if( \Yii::$app->controller->id == 'dashboard' ){
  		foreach ( ( array ) $access_auth as $role ){
  			return [ $role->name ];
  		}
  	}
  	
  	if( $access_auth != null ){
  		$module = Yii::$app->controller->id;
  		foreach ( ( array ) $access_auth as $role ){
	  		$user_access = UserAccess::findOne([ 'name' => $role->name ]);
	
	  		if( $user_access != null ){
	  			if( in_array( $module , explode( ',' , $user_access->access ) ) ){
	  				return [ $role->name ];
	  			}
	  		}else{
	  			return [ $role->name ];
	  		}
  		}
  	}
  	return [ 'admin' ];
  }
  */
  
  
  public function debugRoleCheck(){
  	$module = Yii::$app->controller->id;
  	echo '<pre>';
  	
  	echo 'Module ' . $module .'<br/>';
  	
  	$access_auth = \Yii::$app->authManager->getRolesByUser( \Yii::$app->user->id );
  	
  	echo 'User Access Roles : '; print_r( $access_auth );
  	
  	echo 'Access Roles In DB : ';
  	
  	foreach ( ( array ) $access_auth as $role ){
  		$user_access = UserAccess::findOne([ 'name' => $role->name ]);
  		print_r( $user_access );
  		
  		print_r( explode( ',' , $user_access->access ) );
  		
  		if( in_array( $module , explode( ',' , $user_access->access ) ) ){
  			print_r( [ $role->name ] );
  		}
  	}
  	
  	exit;
  }
}