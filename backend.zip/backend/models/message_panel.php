<?php

namespace backend\models;

use yii\base\Model;
use yii\base\InvalidParamException;
use common\models\user\User;
use yii\helpers\Url;

/**
 * Password reset form
 */
class ResetPasswordForm extends Model {

    public $password;
    public $confirm_password;

    /**
     * @var \common\models\User
     */
    private $_user;

    /**
     * Creates a form model given a token.
     *
     * @param string $token
     * @param array $config name-value pairs that will be used to initialize the object properties
     * @throws \yii\base\InvalidParamException if token is empty or not valid
     */
    public function __construct($token, $config = []) {
        if (empty($token) || !is_string($token)) {
            throw new InvalidParamException('Password reset token cannot be blank.');
        }
        $this->_user = User::findByPasswordResetToken($token);
        if (!$this->_user) {
            return $this->redirect(\Yii::$app->urlManager->createUrl("site/token-exception"));
        }
        parent::__construct($config);
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['password', 'confirm_password'], 'required'],
            ['password', 'string', 'min' => 6],
            ['confirm_password', 'compare', 'compareAttribute' => 'password', 'message' => 'Confirm Password must be equal to new password'],
            
    }

    public function attributeLabels() {
        return [
           
            'password' => 'New Password',
            'confirm_password' => 'Confirm Password',
        ];
    }

    /**
     * Resets password.
     *
     * @return bool if password was reset.
     */
    public function resetPassword() {
        if ($_GET['token'] == $this->_user['password_reset_token']) {
            $user = $this->_user;
            $user->setPassword($this->password);
            $user->removePasswordResetToken();
            return $user->save(false);
        } else {
            return $this->redirect(\Yii::$app->urlManager->createUrl("site/token-exception"));
        }
    }

    /**
     * 
     * redirect() not found that 
     * why we can create function
     */
    public function redirect($url, $statusCode = 302) {
        return \Yii::$app->getResponse()->redirect(Url::to($url), $statusCode);
    }

    public function successMail($email) {
        $user = User::findOne([
                    'is_active' => User::STATUS_ACTIVE,
                    'email' => $email,
        ]);

        $from = $this->getConfigureValueByKey('EMAIL_FROM');
        return \Yii::$app->mailer
                        ->compose(['html' => 'passwordChangeSuccessEmail'], ['user' => $user])
                        ->setFrom($from)
                        ->setTo($email)
                        ->setSubject('Trunkit | Password reset successfully!')
                        ->send();
    }

    public function getConfigureValueByKey($key) {

        $model = \common\models\SiteConfiguration::findOne(['config_key' => $key]);
        if ($model != null) {
            return $model->config_value;
        } else {
            return 'Undefine Key';
        }
    }

}
