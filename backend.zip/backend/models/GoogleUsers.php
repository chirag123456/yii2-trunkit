<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "google_users".
 *
 * @property string $google_id
 * @property string $google_name
 * @property string $google_email
 * @property string $google_link
 * @property string $google_picture_link
 */
class GoogleUsers extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'google_users';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['google_id', 'google_name', 'google_email', 'google_link', 'google_picture_link'], 'required'],
            [['google_id'], 'number'],
            [['google_name', 'google_email'], 'string', 'max' => 100],
            [['google_link', 'google_picture_link'], 'string', 'max' => 500],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'google_id' => 'Google ID',
            'google_name' => 'Google Name',
            'google_email' => 'Google Email',
            'google_link' => 'Google Link',
            'google_picture_link' => 'Google Picture Link',
        ];
    }
}
