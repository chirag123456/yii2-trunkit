<?php

namespace backend\models\user;

use Yii;
use yii\db\Expression;
use yii\db\ActiveRecord;

use yii\helpers\Html;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "tbl_users_group".
 *
 * 
 * @property string $name
 * @property integer $status
 */
class UserAccess extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%user_access}}';
    }
    
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
           [ [ 'name' , 'access' , 'is_admin' , 'status' ], 'safe' ],	 
        ];
    }
}
