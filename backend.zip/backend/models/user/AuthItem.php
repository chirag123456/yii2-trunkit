<?php

namespace backend\models\user;

use Yii;

use yii\behaviors\TimestampBehavior;

use yii\db\Expression;
use yii\db\ActiveRecord;

use yii\helpers\Html;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "auth_item".
 *
 * @property integer $group_id
 * @property string $name
 * @property integer $status
 * @property string $created_at
 * @property string $updated_at
 */
class AuthItem extends \yii\db\ActiveRecord
{
	public $access_role;
	public $is_admin;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%auth_item}}';
    }

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
    	return [
    			TimestampBehavior::className(),
    	];
    }
    
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [ [ 'name' ] , 'required' ],
            [ [ 'type' ] , 'integer' ],
            [ [ 'description' , 'created_at' , 'updated_at' , 'access_role','is_admin' ], 'safe' ],
            [ [ 'name' ], 'string' , 'max' => 64 ],
        	['name', 'unique', 'targetClass' => '\backend\models\user\AuthItem', 'message' => 'This name has already been taken.'],
        		 
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'name' => 'Name',
            'description' => 'Description',
            'created_at' => 'Created Date',
            'updated_at' => 'Updated Date',
        ];
    }
}
