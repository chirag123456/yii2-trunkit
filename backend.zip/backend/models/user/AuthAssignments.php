<?php

namespace backend\models\user;

use Yii;

use yii\behaviors\TimestampBehavior;

use yii\db\Expression;
use yii\db\ActiveRecord;

use yii\helpers\Html;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "auth_assignment".
 *
 * @property integer $group_id
 * @property string $name
 * @property integer $status
 * @property string $created_at
 * @property string $updated_at
 */
class AuthAssignments extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%auth_assignment}}';
    }
		
    public static function getUserByRole( $role ){
    	$table_1 	= 'auth_assignment'; $table_2 = 'users';
    	$select 	= $table_2 . '.id as id , ' . $table_2 . '.username as name , '. $table_1 .'.* ';
    	
    	$model = self::find()->select( $select )
    		->where( [ $table_1 . '.item_name' => $role ] )
    		->leftJoin( $table_2 , $table_2 . '.id = ' . $table_1 . '.user_id' )
    		->asArray()->all();

    	if( $model != null )
    		return ArrayHelper::map( $model , 'id', 'name' );
    	else
    		return [ '' => 'No USer'];
    }
}
