<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use common\models\user\User;

/**
 * Forgot Password Form
 */
class ForgotPasswordForm extends Model {

    public $email;
    
    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['email'], 'required'],
            ['email', 'email', 'message' => 'Please enter valid email address.'],
			['email', 'exist',
                'targetClass' => '\common\models\user\User',
				'filter' => ['is_active' => ACTIVE],
                'message' => 'There is no user with this email address.'
            ],
            ['email', 'validateEmail'],
            
        ];
    }

    public function validateEmail($attribute, $params) {
        if (!$this->hasErrors()) {
            $email = $this->$attribute;
            $check = User::find()->where(['email' => trim($this->$attribute)])->andWhere(['is_delete' => NOT_DELETED,'is_active' => ACTIVE ])->andWhere(['role' => 1])->one();
        
            if (!$check) {
                return $this->addError($attribute, 'Please enter admin email address.');
            }
        }
    }
	
	public function rendomStringGenrator($length){

		$chars = array_merge(range(0,9), range('a','z'), range('A','Z'));
		shuffle($chars);
		$string = implode(array_slice($chars, 0, $length));
                return $string;
	}
	
	public function sendEmail($user) {
        $from = 'demo.xceltec4@gmail.com';//$this->getConfigureValueByKey('EMAIL_FROM');
        return \Yii::$app->mailer
                        ->compose(['html' => 'passwordReset-html'], ['user' => $user])
                        ->setFrom($from)
                        ->setTo($user['email'])
                        ->setSubject('Trunkit | Password reset successfully!')
                        ->send();
    }

}
