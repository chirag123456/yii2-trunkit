<?php

/**
 * Created by PhpStorm.
 * User: rohan
 * Date: 16/2/16
 * Time: 4:30 PM
 */

namespace backend\components;

use Yii;
use common\models\Menus;
use common\models\Campaign;
use common\models\Charity;
use common\models\CharityDonation;
use common\models\Devices;
use common\models\user\User; 
use common\models\post\Post;
use common\models\post\PostOrder;
use common\models\Order;
use yii\base\Component;
use yii\base\InvalidConfigException;
use yii\helpers\Html;
use yii\helpers\Url;

class CommonFunctions extends Component {

    public function welcome() {
        echo "Hello..Welcome to MyComponent";
    }

    public static function base64ToImage($data, $output_file_without_extentnion, $path) {
        $full_path = dirname(\Yii::$app->basePath).'/media/' . $path; 
        $splited = explode(',', substr($data, 5), 2);
        $data = str_replace('data:image/png;base64,', '', $data);
        $mime = $splited[0];
        $data = $splited[1];
        $mime_split_without_base64 = explode(';', $mime, 2);
        $mime_split = explode('/', $mime_split_without_base64[0], 2);
        $extension = $mime_split[1];
        $output_file = str_replace(' ', '_', $output_file_without_extentnion) . '.' . $extension;
        $final_file = $full_path . $output_file;
        $success = file_put_contents($final_file, base64_decode($data));
        if ($success) {
            $media = [$final_file, $path];
            return $media;
        } else {
            return false;
        }
    }

    public static function returnExtension($icon) {
        $splited = explode(',', substr($icon, 5), 2);
        $icon = str_replace('data:image/png;base64,', '', $icon);
        $mime = $splited[0];
        $icon = $splited[1];

        $mime_split_without_base64 = explode(';', $mime, 2);
        $mime_split = explode('/', $mime_split_without_base64[0], 2);
        $extension = $mime_split[1];
        return '.' . $extension;
    }

    public function getConfigureValueByKey($key) {

        $model = \common\models\siteconfiguration\SiteConfiguration::findOne(['config_key' => $key]);
        if ($model != null) {
            return $model->config_value;
        } else {
            return 'Undefine Key';
        }
    }

    public function getDashboardDetails() {

        $daily_user = User::find()->where(['role' => '2'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','created_date',date("Y-m-d")])
        ->count('id');

        $daily_request = Post::find()->where(['post_type' => 'REQUEST'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','post_date',date("Y-m-d")])
        ->count('id');

        $daily_trip = Post::find()->where(['post_type' => 'TRIP'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','post_date',date("Y-m-d")])
        ->count('id');

        $daily_income = PostOrder::find()->where(['order_status' => 'FINISHED'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','order_date',date("Y-m-d")])
        ->sum('price');
        
        $weekly_user = User::find()->where(['role' => '2'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','DAY(created_date)',date('d') -7])
        ->andWhere(['>=','MONTH(created_date)',date('m')])
        ->count('id');

        $weekly_request = Post::find()->where(['post_type' => 'REQUEST'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['<=','DAY(post_date)',date('d') -7])
        ->andWhere(['>=','MONTH(post_date)',date('m')])
        ->count('id');

        $weekly_trip = Post::find()->where(['post_type' => 'TRIP'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['<=','DAY(post_date)',date('d') -7])
        ->andWhere(['>=','MONTH(post_date)',date('m')])
        ->count('id');

        $weekly_income = PostOrder::find()->where(['order_status' => 'FINISHED'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','DAY(order_date)',date('d')-7])
        ->andWhere(['>=','MONTH(order_date)',date('m')])
        ->sum('price');

        $monthly_user = User::find()->where(['role' => '2'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','MONTH(created_date)',date('m')])
        ->count('id');

        $monthly_request = Post::find()->where(['post_type' => 'REQUEST'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','MONTH(post_date)',date('m')])
        ->count('id');

        $monthly_trip = Post::find()->where(['post_type' => 'TRIP'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','MONTH(post_date)',date('m')])
        ->count('id');

        $monthly_income = PostOrder::find()->where(['order_status' => 'FINISHED'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','MONTH(order_date)',date('m')])
        ->sum('price');

        $yearly_user = User::find()->where(['role' => '2'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','YEAR(created_date)',date('Y')])
        ->count('id');

        $yearly_request = Post::find()->where(['post_type' => 'REQUEST'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','YEAR(post_date)',date('Y')])
        ->count('id');

        $yearly_trip = Post::find()->where(['post_type' => 'TRIP'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','YEAR(post_date)',date('Y')])
        ->count('id');

        $yearly_income = PostOrder::find()->where(['order_status' => 'FINISHED'])
        ->andWhere(['is_delete' => NOT_DELETED])
        ->andWhere(['>=','YEAR(order_date)',date('Y')])
        ->sum('price');

        $total_User = User::find()->where(['role' => '2'])->andWhere(['is_delete' => NOT_DELETED])->count('id'); 
        $total_Request_post = Post::find()->where(['post_type' => 'REQUEST'])->andWhere(['is_delete' => NOT_DELETED])->count('id');
        $total_intrip_post = Post::find()->where(['post_type' => 'TRIP'])->andWhere(['is_delete' => NOT_DELETED])->count('id');
		$total_income = PostOrder::find()->where(['order_status' => 'FINISHED'])->andWhere(['is_delete' => NOT_DELETED])->sum('price');
        
        return [
            'details' => [
                'daily_user' => isset($daily_user) ? $daily_user : '0',
                'daily_request' => isset($daily_request) ? $daily_request : '0',
                'daily_trip' => isset($daily_trip) ? $daily_trip : '0',
                'daily_income' => isset($daily_income) ? $daily_income : '0',
                'weekly_user' => isset($weekly_user) ? $weekly_user : '0',
                'weekly_request' => isset($weekly_request) ? $weekly_request : '0',
                'weekly_trip' => isset($weekly_trip) ? $weekly_trip : '0',
                'weekly_income' => isset($weekly_income) ? $weekly_income : '0',
                'monthly_user' => isset($monthly_user) ? $monthly_user : '0',
                'monthly_request' => isset($monthly_request) ? $monthly_request : '0',
                'monthly_trip' => isset($monthly_trip) ? $monthly_trip : '0',
                'monthly_income' => isset($monthly_income) ? $monthly_income : '0',
                'yearly_user' => isset($yearly_user) ? $yearly_user : '0',
                'yearly_request' => isset($yearly_request) ? $yearly_request : '0',
                'yearly_trip' => isset($yearly_trip) ? $yearly_trip : '0',
                'yearly_income' => isset($yearly_income) ? $yearly_income : '0',
                'total_User' => isset($total_User) ? $total_User : '0',
                'total_Request_post' => isset($total_Request_post) ? $total_Request_post : '0',
                'total_intrip_post' => isset($total_intrip_post) ? $total_intrip_post : '0',
				'total_income' => isset($total_income) ? $total_income : '0',
            ]
        ];
    }

        /*
    *OneSingle Notifications
    */
    
    public function sendPushNotification($message = NULL,$uid = NULL){
        
        //$message = $this->input->post("message");
        //$user_id = $this->input->post("user_id");
        $content = array(
            "en" => "$message"
        );

        $fields = array(
            'app_id' => "a64c82b0-6c7e-4255-85b4-9ea3f53143cb",            
            'filters' => array(array("field" => "tag", "key" => "uid", "relation" => "=", "value" => "$uid")),
            'contents' => $content
        );

        $fields = json_encode($fields);
        print("\nJSON sent:\n");
        print($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
            'Authorization: Basic MzMyMGI3NzEtNzlkNy00MjMwLTlhMWMtMGM0MmM4ZDExNWMx'));//NGM0Mzk5YjMtNTQzMi00OTkwLTkyY2EtMTI1MzNhODBmZjgz
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

        $response = curl_exec($ch);
        curl_close($ch);
       return $response;
    }

}
